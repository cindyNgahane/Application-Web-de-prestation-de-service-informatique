<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nos Réalisations - Entreprise Design</title>
  <style>
    /* Style de base */
    :root {
      --primary-color: #3498db;
      --secondary-color: #2c3e50;
      --light-color: #ecf0f1;
      --dark-color: #2c3e50;
      --success-color: #2ecc71;
      --sky-blue: #87CEEB;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      line-height: 1.6;
      color: #333;
      margin: 0;
      padding: 0;
    }
    
    .container {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 15px;
    }
    
    /* Header */
    header {
      background-color: white;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1000;
    }
    
    .header-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 0;
    }
    
    /* Navigation */
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        background: white;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        z-index: 1000;
        padding: 20px 0;
    }

    .navbar .container {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .logo img {
        height: 40px;
    }

    .logo span {
        font-size: 1.8rem;
        font-weight: 700;
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
    }

    .nav-links {
        display: flex;
        gap: 20px;
        align-items: center;
    }

    .nav-links a {
        color: var(--dark-color);
        font-weight: 500;
        transition: all 0.3s;
        text-decoration: none;
    }

    .nav-links a:hover {
        color: var(--primary-color);
    }

    .nav-links a.active {
        color: var(--primary-color);
        font-weight: 600;
        position: relative;
    }

    .nav-links a.active::after {
        content: '';
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 100%;
        height: 2px;
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    }

    .auth-buttons {
        display: flex;
        gap: 15px;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        border-radius: 4px;
        text-decoration: none;
        font-weight: 500;
        transition: all 0.3s;
        border: 2px solid transparent;
    }

    .btn-outline {
        background: transparent;
        color: var(--primary-color);
        border: 2px solid var(--primary-color);
    }

    .btn-outline:hover {
        background: var(--primary-color);
        color: white;
    }

    .btn-primary {
        background: var(--primary-color);
        color: white;
        border: 2px solid var(--primary-color);
    }

    .btn-primary:hover {
        background: transparent;
        color: var(--primary-color);
    }
    
    .btn-getstarted {
      background-color: var(--primary-color);
      color: white;
      padding: 8px 20px;
      border-radius: 4px;
      text-decoration: none;
      font-weight: 500;
      transition: background-color 0.3s;
    }
    
    .btn-getstarted:hover {
      background-color: #2980b9;
    }
    
    /* Hero Section */
    .page-title {
      background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://source.unsplash.com/random/1920x1080/?design,creative') no-repeat center center/cover;
      color: white;
      padding: 120px 0 60px;
      text-align: center;
      margin-top: 60px;
    }
    
    .page-title h1 {
      font-size: 48px;
      margin-bottom: 15px;
    }
    
    /* Services Section avec fond bleu ciel */
    .section {
      padding: 80px 0;
      background: linear-gradient(135deg, var(--sky-blue) 0%, #B0E0E6 100%);
    }
    
    .text-center {
      text-align: center;
    }
    
    .service-categories {
      display: flex;
      justify-content: center;
      margin-bottom: 40px;
      flex-wrap: wrap;
    }
    
    .category-tab {
      padding: 12px 25px;
      margin: 0 10px;
      background: rgba(255,255,255,0.9);
      border-radius: 30px;
      cursor: pointer;
      transition: all 0.3s;
      font-weight: 500;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    .category-tab:hover,
    .category-tab.active {
      background: var(--primary-color);
      color: white;
      transform: translateY(-2px);
    }
    
    .design-gallery {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 30px;
      margin-top: 40px;
    }
    
    .design-item {
      background: white;
      border-radius: 15px;
      overflow: hidden;
      box-shadow: 0 8px 25px rgba(0,0,0,0.15);
      transition: all 0.3s;
      position: relative;
    }
    
    .design-item:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    }
    
    .design-preview {
      height: 250px;
      overflow: hidden;
      position: relative;
    }
    
    .design-preview img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.5s;
    }
    
    .design-item:hover .design-preview img {
      transform: scale(1.05);
    }
    
    .design-badge {
      position: absolute;
      top: 15px;
      right: 15px;
      background: var(--primary-color);
      color: white;
      padding: 5px 15px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 500;
      z-index: 2;
    }
    
    .design-info {
      padding: 25px;
    }
    
    .design-info h3 {
      margin: 0 0 10px;
      font-size: 20px;
      color: var(--dark-color);
    }
    
    .design-info p {
      margin: 0 0 20px;
      color: #666;
      font-size: 14px;
      line-height: 1.6;
    }
    
    .design-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 13px;
      color: #888;
      margin-bottom: 20px;
    }
    
    .design-actions {
      display: flex;
      gap: 10px;
      justify-content: space-between;
      align-items: center;
    }
    
    .btn-info {
      background: var(--success-color);
      color: white;
      padding: 8px 15px;
      border-radius: 6px;
      text-decoration: none;
      font-size: 12px;
      font-weight: 600;
      transition: all 0.3s;
      display: flex;
      align-items: center;
      gap: 5px;
    }
    
    .btn-info:hover {
      background: #27ae60;
      transform: scale(1.05);
    }
    
    .download-btn {
      background: var(--primary-color);
      color: white;
      padding: 8px 15px;
      border-radius: 6px;
      text-decoration: none;
      font-size: 12px;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 5px;
      transition: all 0.3s;
    }
    
    .download-btn:hover {
      background: #2980b9;
      transform: scale(1.05);
    }
    
    /* Style spécifique pour chaque catégorie */
    .design-badge.web { background: #3498db; }
    .design-badge.branding { background: #e74c3c; }
    .design-badge.print { background: #2ecc71; }
    .design-badge.digital { background: #9b59b6; }
    .design-badge.consulting { background: #f39c12; }
    
    /* Modal */
    .modal {
      display: none;
      position: fixed;
      z-index: 1001;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.8);
      overflow: auto;
    }
    
    .modal-content {
      background-color: white;
      margin: 5% auto;
      padding: 30px;
      border-radius: 8px;
      width: 80%;
      max-width: 700px;
      position: relative;
    }
    
    .close-modal {
      position: absolute;
      top: 15px;
      right: 25px;
      font-size: 28px;
      font-weight: bold;
      color: #aaa;
      cursor: pointer;
    }
    
    .close-modal:hover {
      color: var(--dark-color);
    }
    
    .download-options {
      margin-top: 20px;
    }
    
    .download-option {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px;
      border: 1px solid #eee;
      border-radius: 4px;
      margin-bottom: 10px;
    }
    
    .download-option:hover {
      background: #f9f9f9;
    }
    
    .download-link {
      background: var(--primary-color);
      color: white;
      padding: 8px 15px;
      border-radius: 4px;
      text-decoration: none;
      font-size: 14px;
    }
    
    .download-link:hover {
      background: #2980b9;
    }
    
    /* CTA Section */
    .cta-box {
      background: rgba(255,255,255,0.9);
      padding: 40px;
      border-radius: 15px;
      margin-top: 60px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    .cta-content h3 {
      margin-top: 0;
      color: var(--dark-color);
    }
    
    .cta-content p {
      color: #666;
      margin-bottom: 25px;
    }
    
    /* Footer */
    footer {
      background: var(--dark-color);
      color: white;
      padding: 60px 0 20px;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .nav-links {
        display: none;
      }
      
      .page-title h1 {
        font-size: 36px;
      }
      
      .design-gallery {
        grid-template-columns: 1fr;
      }
      
      .category-tab {
        margin: 5px;
        padding: 8px 15px;
      }
      
      .modal-content {
        width: 90%;
        margin: 10% auto;
        padding: 20px;
      }
      
      .design-actions {
        flex-direction: column;
        gap: 10px;
      }
      
      .btn-info, .download-btn {
        width: 100%;
        justify-content: center;
      }
    }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>

  <header id="header" class="header">
    <nav class="navbar">
        <div class="container">
            <a href="index.html" class="logo">
                <img src="images/logo.jpg" alt="EUREKA Logo">
            </a>
            <div class="nav-links">
                <a href="index.php">Accueil</a>
                <a href="services.php" class="active">Services</a>
                <a href="#about">À propos</a>
                
                <div class="auth-buttons">
                    <a href="login.php" class="btn btn-outline">Connexion</a>
                    <a href="inscription.php" class="btn btn-primary">S'inscrire</a>
                    <a class="btn-getstarted" href="devis.php">Demander un devis</a>
                </div>
            </div>
        </div>
    </nav>
  </header>

  <main class="main">
    <!-- Page Title -->
    <div class="page-title">
      <div class="container">
        <h1>Nos Réalisations</h1>
        <p>Découvrez et téléchargez nos créations et solutions concrètes</p>
      </div>
    </div>

    <!-- Services Section -->
    <section id="portfolio" class="section">
      <div class="container">
        <div class="text-center">
          <h2>Nos Créations par Catégorie</h2>
          <p>Explorez et téléchargez nos différents travaux</p>
        </div>

        <div class="service-categories">
          <div class="category-tab active" data-category="all">Tous nos travaux</div>
          <div class="category-tab" data-category="web">Design Web</div>
          <div class="category-tab" data-category="branding">Identité Visuelle</div>
          <div class="category-tab" data-category="print">Design Print</div>
          <div class="category-tab" data-category="digital">Stratégie Digitale</div>
          <div class="category-tab" data-category="consulting">Consulting</div>
        </div>

        <div class="design-gallery">
          <!-- Design Web 1 -->
          <div class="design-item" data-category="web">
            <div class="design-preview">
              <img src="https://source.unsplash.com/random/600x400/?website,design" alt="Site Web Corporate">
              <span class="design-badge web">Web Design</span>
            </div>
            <div class="design-info">
              <h3>Site Web Corporate</h3>
              <p>Refonte complète du site web d'une entreprise de consulting financier avec interface moderne et responsive.</p>
              <div class="design-meta">
                <span>Client: FinExpert</span>
                <span>2023</span>
              </div>
              <div class="design-actions">
                <a href="projet-detail.php?id=site-web-corporate" class="btn-info">
                  <i class="fas fa-eye"></i> En savoir plus
                </a>
                <a href="#" class="download-btn" data-project="site-web-corporate">
                  <i class="fas fa-download"></i> Télécharger
                </a>
              </div>
            </div>
          </div>

          <!-- Branding 1 -->
          <div class="design-item" data-category="branding">
            <div class="design-preview">
              <img src="https://source.unsplash.com/random/600x400/?logo,branding" alt="Identité Visuelle">
              <span class="design-badge branding">Branding</span>
            </div>
            <div class="design-info">
              <h3>Identité Visuelle</h3>
              <p>Création de l'identité complète pour une startup technologique incluant logo, charte graphique et supports.</p>
              <div class="design-meta">
                <span>Client: TechNova</span>
                <span>2022</span>
              </div>
              <div class="design-actions">
                <a href="projet-detail.php?id=identite-visuelle" class="btn-info">
                  <i class="fas fa-eye"></i> En savoir plus
                </a>
                <a href="#" class="download-btn" data-project="identite-visuelle">
                  <i class="fas fa-download"></i> Télécharger
                </a>
              </div>
            </div>
          </div>

          <!-- Print 1 -->
          <div class="design-item" data-category="print">
            <div class="design-preview">
              <img src="https://source.unsplash.com/random/600x400/?brochure,design" alt="Brochure Corporate">
              <span class="design-badge print">Print</span>
            </div>
            <div class="design-info">
              <h3>Brochure Corporate</h3>
              <p>Conception et réalisation d'une brochure haut de gamme pour un groupe hôtelier de luxe.</p>
              <div class="design-meta">
                <span>Client: LuxeHotels</span>
                <span>2023</span>
              </div>
              <div class="design-actions">
                <a href="projet-detail.php?id=brochure-corporate" class="btn-info">
                  <i class="fas fa-eye"></i> En savoir plus
                </a>
                <a href="#" class="download-btn" data-project="brochure-corporate">
                  <i class="fas fa-download"></i> Télécharger
                </a>
              </div>
            </div>
          </div>

          <!-- Digital 1 -->
          <div class="design-item" data-category="digital">
            <div class="design-preview">
              <img src="https://source.unsplash.com/random/600x400/?social,media" alt="Stratégie Réseaux Sociaux">
              <span class="design-badge digital">Digital</span>
            </div>
            <div class="design-info">
              <h3>Stratégie Réseaux Sociaux</h3>
              <p>Campagne digitale complète pour une marque de cosmétiques naturels avec création de contenu.</p>
              <div class="design-meta">
                <span>Client: BioBeauty</span>
                <span>2022</span>
              </div>
              <div class="design-actions">
                <a href="projet-detail.php?id=strategie-reseaux" class="btn-info">
                  <i class="fas fa-eye"></i> En savoir plus
                </a>
                <a href="#" class="download-btn" data-project="strategie-reseaux">
                  <i class="fas fa-download"></i> Télécharger
                </a>
              </div>
            </div>
          </div>

          <!-- Consulting 1 -->
          <div class="design-item" data-category="consulting">
            <div class="design-preview">
              <img src="https://source.unsplash.com/random/600x400/?office,meeting" alt="Transformation Digitale">
              <span class="design-badge consulting">Consulting</span>
            </div>
            <div class="design-info">
              <h3>Transformation Digitale</h3>
              <p>Accompagnement dans la digitalisation des processus d'une PME manufacturière traditionnelle.</p>
              <div class="design-meta">
                <span>Client: ManufacturePlus</span>
                <span>2023</span>
              </div>
              <div class="design-actions">
                <a href="projet-detail.php?id=transformation-digitale" class="btn-info">
                  <i class="fas fa-eye"></i> En savoir plus
                </a>
                <a href="#" class="download-btn" data-project="transformation-digitale">
                  <i class="fas fa-download"></i> Télécharger
                </a>
              </div>
            </div>
          </div>

          <!-- Web 2 -->
          <div class="design-item" data-category="web">
            <div class="design-preview">
              <img src="https://source.unsplash.com/random/600x400/?ecommerce,website" alt="Boutique en ligne">
              <span class="design-badge web">Web Design</span>
            </div>
            <div class="design-info">
              <h3>Boutique en ligne</h3>
              <p>Création d'une plateforme e-commerce complète pour une marque de prêt-à-porter urbain.</p>
              <div class="design-meta">
                <span>Client: UrbanStyle</span>
                <span>2023</span>
              </div>
              <div class="design-actions">
                <a href="projet-detail.php?id=boutique-en-ligne" class="btn-info">
                  <i class="fas fa-eye"></i> En savoir plus
                </a>
                <a href="#" class="download-btn" data-project="boutique-en-ligne">
                  <i class="fas fa-download"></i> Télécharger
                </a>
              </div>
            </div>
          </div>

          <!-- Branding 2 -->
          <div class="design-item" data-category="branding">
            <div class="design-preview">
              <img src="https://source.unsplash.com/random/600x400/?packaging,design" alt="Packaging Produit">
              <span class="design-badge branding">Branding</span>
            </div>
            <div class="design-info">
              <h3>Packaging Produit</h3>
              <p>Design d'emballage innovant pour une gamme de produits alimentaires biologiques et écologiques.</p>
              <div class="design-meta">
                <span>Client: GreenFood</span>
                <span>2022</span>
              </div>
              <div class="design-actions">
                <a href="projet-detail.php?id=packaging-produit" class="btn-info">
                  <i class="fas fa-eye"></i> En savoir plus
                </a>
                <a href="#" class="download-btn" data-project="packaging-produit">
                  <i class="fas fa-download"></i> Télécharger
                </a>
              </div>
            </div>
          </div>

          <!-- Print 2 -->
          <div class="design-item" data-category="print">
            <div class="design-preview">
              <img src="https://source.unsplash.com/random/600x400/?poster,design" alt="Affiche Événementielle">
              <span class="design-badge print">Print</span>
            </div>
            <div class="design-info">
              <h3>Affiche Événementielle</h3>
              <p>Création d'affiches artistiques pour un festival culturel international avec impact visuel fort.</p>
              <div class="design-meta">
                <span>Client: ArtWorld Festival</span>
                <span>2021</span>
              </div>
              <div class="design-actions">
                <a href="projet-detail.php?id=affiche-evenementielle" class="btn-info">
                  <i class="fas fa-eye"></i> En savoir plus
                </a>
                <a href="#" class="download-btn" data-project="affiche-evenementielle">
                  <i class="fas fa-download"></i> Télécharger
                </a>
              </div>
            </div>
          </div>
        </div>

        <div class="text-center">
          <div class="cta-box">
            <div class="cta-content">
              <h3>Vous souhaitez des créations similaires pour votre entreprise ?</h3>
              <p>Nos designers et consultants sont à votre écoute pour discuter de votre projet et créer des solutions sur mesure.</p>
              <div class="cta-actions">
                <a href="contact.html" class="btn btn-primary">Contactez-nous</a>
                <a class="btn-getstarted" href="contact.html">Ajouter un projet</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <!-- Modal de téléchargement -->
  <div id="downloadModal" class="modal">
    <div class="modal-content">
      <span class="close-modal">&times;</span>
      <h3>Télécharger les fichiers</h3>
      <p id="modalProjectTitle"></p>
      
      <div class="download-options">
        <div class="download-option">
          <span>Version PDF (Haute qualité)</span>
          <a href="#" class="download-link" data-format="pdf"><i class="fas fa-file-pdf"></i> Télécharger</a>
        </div>
        <div class="download-option">
          <span>Version JPG (Web)</span>
          <a href="#" class="download-link" data-format="jpg"><i class="fas fa-file-image"></i> Télécharger</a>
        </div>
        <div class="download-option">
          <span>Fichiers sources (ZIP)</span>
          <a href="#" class="download-link" data-format="zip"><i class="fas fa-file-archive"></i> Télécharger</a>
        </div>
      </div>
    </div>
  </div>

  <footer>
    <div class="container text-center">
      <p>&copy; 2025 DesignConsult. Tous droits réservés.</p>
    </div>
  </footer>

  <script>
    // Filtrage des réalisations
    document.addEventListener('DOMContentLoaded', function() {
      const categoryTabs = document.querySelectorAll('.category-tab');
      const designItems = document.querySelectorAll('.design-item');
      
      categoryTabs.forEach(tab => {
        tab.addEventListener('click', function() {
          // Active l'onglet cliqué
          categoryTabs.forEach(t => t.classList.remove('active'));
          this.classList.add('active');
          
          const category = this.getAttribute('data-category');
          
          // Filtre les réalisations
          designItems.forEach(item => {
            item.style.display = 'none';
            
            if (category === 'all' || item.getAttribute('data-category') === category) {
              item.style.display = 'block';
            }
          });
        });
      });

      // Gestion du téléchargement
      const downloadBtns = document.querySelectorAll('.download-btn');
      const modal = document.getElementById('downloadModal');
      const modalTitle = document.getElementById('modalProjectTitle');
      const closeModal = document.querySelector('.close-modal');
      const downloadLinks = document.querySelectorAll('.download-link');
      let currentProject = '';

      downloadBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
          e.preventDefault();
          currentProject = this.getAttribute('data-project');
          
          // Mettre à jour le titre dans la modal
          const projectTitle = this.closest('.design-item').querySelector('h3').textContent;
          modalTitle.textContent = projectTitle;
          
          // Afficher la modal
          modal.style.display = 'block';
        });
      });

      // Fermer la modal
      closeModal.addEventListener('click', function() {
        modal.style.display = 'none';
      });

      // Fermer quand on clique en dehors
      window.addEventListener('click', function(e) {
        if (e.target === modal) {
          modal.style.display = 'none';
        }
      });

      // Gestion des liens de téléchargement
      downloadLinks.forEach(link => {
        link.addEventListener('click', function(e) {
          e.preventDefault();
          const format = this.getAttribute('data-format');
          
          // Chemin vers le fichier à télécharger
          const filePath = `/images/${currentProject}.${format}`;
          
          // Créer un lien invisible pour forcer le téléchargement
          const downloadLink = document.createElement('a');
          downloadLink.href = filePath;
          downloadLink.download = `${currentProject}.${format}`;
          document.body.appendChild(downloadLink);
          downloadLink.click();
          document.body.removeChild(downloadLink);
          
          // Fermer la modale après déclenchement
          modal.style.display = 'none';
        });
      });
    });
  </script>
</body>
</html>