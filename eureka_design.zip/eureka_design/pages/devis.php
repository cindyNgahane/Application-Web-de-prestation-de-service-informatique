<?php
// Note: Suppression de la logique PHP pour se concentrer sur EmailJS
// Si vous voulez garder PHP, il faut choisir entre PHP et EmailJS
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demande de devis - Eureka Design</title>
    <style>
        /* Styles cohérents avec idee.php */
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --success-color: #2ecc71;
            --error-color: #e74c3c;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }
        
        /* Header - cohérent avec idee.php */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            padding: 20px 0;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .logo img {
            height: 40px;
        }
        
        /* Formulaire */
        .form-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 40px;
            margin: 100px auto 50px;
            max-width: 800px;
        }
        
        .form-title {
            text-align: center;
            color: var(--dark-color);
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }
        
        .required::after {
            content: " *";
            color: var(--error-color);
        }
        
        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: inherit;
            font-size: 16px;
            transition: border 0.3s;
            box-sizing: border-box;
        }
        
        input:focus, select:focus, textarea:focus {
            border-color: var(--primary-color);
            outline: none;
        }
        
        textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        /* Style personnalisé pour l'input file */
        .file-upload {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }
        
        .file-upload-btn {
            border: 2px dashed #ccc;
            border-radius: 4px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background-color: #f9f9f9;
        }
        
        .file-upload-btn:hover {
            border-color: var(--primary-color);
            background-color: #f0f7fc;
        }
        
        .file-upload-input {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .file-upload-info {
            margin-top: 10px;
            font-size: 14px;
            color: #666;
        }
        
        .file-upload-preview {
            margin-top: 15px;
            display: none;
        }
        
        .file-upload-preview img {
            max-width: 100%;
            max-height: 150px;
            border-radius: 4px;
        }
        
        .btn-submit {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: background 0.3s;
            display: block;
            width: 100%;
            margin-top: 20px;
        }
        
        .btn-submit:hover {
            background: #2980b9;
        }
        
        .btn-submit:disabled {
            background: #95a5a6;
            cursor: not-allowed;
        }
        
        .confirmation-message {
            background: var(--success-color);
            color: white;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
            display: none;
        }
        
        .error-message {
            background: var(--error-color);
            color: white;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
            display: none;
        }
        
        .loading {
            display: none;
            text-align: center;
            margin-top: 10px;
        }
        
        .spinner {
            border: 2px solid #f3f3f3;
            border-top: 2px solid var(--primary-color);
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            display: inline-block;
            margin-right: 10px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .form-container {
                padding: 20px;
                margin: 80px auto 30px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="logo">
                <img src="images/logo.jpg" alt="EUREKA Logo">
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="form-container">
            <h1 class="form-title">Demander un devis</h1>
            
            <div id="success-message" class="confirmation-message">
                Merci ! Votre demande de devis a bien été envoyée. Nous vous contacterons rapidement.
            </div>
            
            <div id="error-message" class="error-message">
                Erreur lors de l'envoi. Veuillez vérifier vos informations et réessayer.
            </div>
            
            <form id="contactForms">
                <div class="form-group">
                    <label for="nom" class="required">Nom complet</label>
                    <input type="text" id="nom" name="nom" required>
                </div>
                
                <div class="form-group">
                    <label for="email" class="required">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="telephone">Téléphone</label>
                    <input type="tel" id="telephone" name="telephone">
                </div>
                
                <div class="form-group">
                    <label for="entreprise">Entreprise</label>
                    <input type="text" id="entreprise" name="entreprise">
                </div>
                
                <div class="form-group">
                    <label for="service" class="required">Service souhaité</label>
                    <select id="service" name="service" required>
                        <option value="">-- Sélectionnez un service --</option>
                        <option value="web">Design Web</option>
                        <option value="branding">Identité Visuelle</option>
                        <option value="print">Design Print</option>
                        <option value="digital">Stratégie Digitale</option>
                        <option value="consulting">Consulting</option>
                        <option value="autre">Autre</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="description" class="required">Description de votre projet</label>
                    <textarea id="description" name="description" required placeholder="Décrivez votre projet en détail..."></textarea>
                </div>
                
                <div class="form-group">
                    <label for="budget">Budget estimé (optionnel)</label>
                    <select id="budget" name="budget">
                        <option value="">-- Sélectionnez une fourchette --</option>
                        <option value="50000-100000">50 000 FCFA - 100 000 FCFA</option>
                        <option value="100000-200000">100 000 FCFA - 200 000 FCFA</option>
                        <option value="200000-300000">200 000 FCFA - 300 000 FCFA</option>
                        <option value="300000+">Plus de 300 000 FCFA</option>
                        <option value="indetermine">À déterminer</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="delai">Délai souhaité (optionnel)</label>
                    <select id="delai" name="delai">
                        <option value="">-- Sélectionnez un délai --</option>
                        <option value="urgent">Moins d'1 mois</option>
                        <option value="1-3mois">1 à 3 mois</option>
                        <option value="3-6mois">3 à 6 mois</option>
                        <option value="6mois+">Plus de 6 mois</option>
                        <option value="flexible">Délai flexible</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="fichier">Joindre un fichier (optionnel)</label>
                    <div class="file-upload">
                        <label class="file-upload-btn">
                            <i class="fas fa-cloud-upload-alt" style="font-size: 24px; margin-bottom: 10px;"></i>
                            <div>Cliquez pour téléverser un fichier</div>
                            <div class="file-upload-info">Formats acceptés: JPG, PNG, PDF, DOC, ZIP (max 5MB)</div>
                            <input type="file" id="fichier" name="fichier" class="file-upload-input" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx,.zip,.psd,.ai">
                        </label>
                        <div class="file-upload-preview" id="filePreview">
                            <img id="previewImage" src="#" alt="Aperçu du fichier">
                            <div id="fileName"></div>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn-submit" id="submitBtn">
                    Envoyer ma demande
                </button>
                
                <div class="loading" id="loading">
                    <div class="spinner"></div>
                    Envoi en cours...
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
    <script>
        // Configuration EmailJS
        (function(){
            emailjs.init("HNn2aUdGxxbVMZrJa"); // Votre User ID
        })();

        // Éléments du DOM
        const form = document.getElementById("contactForms");
        const submitBtn = document.getElementById("submitBtn");
        const loading = document.getElementById("loading");
        const successMessage = document.getElementById("success-message");
        const errorMessage = document.getElementById("error-message");

        // Gestion de l'envoi du formulaire
        form.addEventListener("submit", function(event) {
            event.preventDefault();
            
            // Validation des champs requis
            const nom = document.getElementById("nom").value.trim();
            const email = document.getElementById("email").value.trim();
            const service = document.getElementById("service").value;
            const description = document.getElementById("description").value.trim();
            
            if (!nom || !email || !service || !description) {
                showError("Veuillez remplir tous les champs obligatoires.");
                return;
            }
            
            // Validation de l'email
            if (!isValidEmail(email)) {
                showError("Veuillez entrer une adresse email valide.");
                return;
            }
            
            // Désactiver le bouton et afficher le loading
            submitBtn.disabled = true;
            loading.style.display = "block";
            hideMessages();
            
            // Préparer les données du formulaire
            const formData = new FormData(form);
            const templateParams = {
                nom: formData.get('nom'),
                email: formData.get('email'),
                telephone: formData.get('telephone') || 'Non renseigné',
                entreprise: formData.get('entreprise') || 'Non renseigné',
                service: formData.get('service'),
                description: formData.get('description'),
                budget: formData.get('budget') || 'Non renseigné',
                delai: formData.get('delai') || 'Non renseigné'
            };
            
            // Envoi via EmailJS
            emailjs.send('service_1smbb3j', 'template_3tmcg2k', templateParams)
                .then(function(response) {
                    console.log('SUCCESS!', response.status, response.text);
                    showSuccess();
                    form.reset();
                    document.getElementById('filePreview').style.display = 'none';
                }, function(error) {
                    console.log('FAILED...', error);
                    showError("Erreur lors de l'envoi. Veuillez réessayer dans quelques instants.");
                })
                .finally(function() {
                    // Réactiver le bouton et cacher le loading
                    submitBtn.disabled = false;
                    loading.style.display = "none";
                });
        });

        // Fonction pour valider l'email
        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }

        // Fonction pour afficher le message de succès
        function showSuccess() {
            successMessage.style.display = "block";
            errorMessage.style.display = "none";
            setTimeout(() => {
                successMessage.style.display = "none";
            }, 5000);
        }

        // Fonction pour afficher les messages d'erreur
        function showError(message) {
            errorMessage.textContent = message;
            errorMessage.style.display = "block";
            successMessage.style.display = "none";
            setTimeout(() => {
                errorMessage.style.display = "none";
            }, 5000);
        }

        // Fonction pour cacher tous les messages
        function hideMessages() {
            successMessage.style.display = "none";
            errorMessage.style.display = "none";
        }

        // Aperçu du fichier sélectionné
        document.getElementById('fichier').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const preview = document.getElementById('filePreview');
            const previewImage = document.getElementById('previewImage');
            const fileName = document.getElementById('fileName');
            
            if (file) {
                // Vérifier la taille du fichier (5MB max)
                const maxSize = 5 * 1024 * 1024;
                if (file.size > maxSize) {
                    showError('Le fichier est trop volumineux (max 5MB)');
                    this.value = '';
                    return;
                }
                
                preview.style.display = 'block';
                fileName.textContent = file.name;
                
                // Afficher l'aperçu pour les images
                if (file.type.match('image.*')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        previewImage.src = e.target.result;
                        previewImage.style.display = 'block';
                    }
                    reader.readAsDataURL(file);
                } else {
                    previewImage.style.display = 'none';
                }
            } else {
                preview.style.display = 'none';
            }
        });

        // Animation du bouton de soumission
        submitBtn.addEventListener('mouseover', function() {
            if (!this.disabled) {
                this.style.transform = 'translateY(-2px)';
            }
        });

        submitBtn.addEventListener('mouseout', function() {
            this.style.transform = 'translateY(0)';
        });
    </script>
</body>
</html>