<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Détail du Projet - Entreprise Design</title>
  <style>
    /* Style de base */
    :root {
      --primary-color: #3498db;
      --secondary-color: #2c3e50;
      --light-color: #ecf0f1;
      --dark-color: #2c3e50;
      --success-color: #2ecc71;
      --sky-blue: #87CEEB;
      --warning-color: #f39c12;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      line-height: 1.6;
      color: #333;
      background: linear-gradient(135deg, var(--sky-blue) 0%, #B0E0E6 100%);
      min-height: 100vh;
    }
    
    .container {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 15px;
    }
    
    /* Header */
    header {
      background-color: rgba(255,255,255,0.95);
      backdrop-filter: blur(10px);
      box-shadow: 0 2px 20px rgba(0,0,0,0.1);
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1000;
    }
    
    .navbar {
      padding: 20px 0;
    }

    .navbar .container {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo img {
      height: 40px;
    }

    .nav-links {
      display: flex;
      gap: 20px;
      align-items: center;
    }

    .nav-links a {
      color: var(--dark-color);
      font-weight: 500;
      transition: all 0.3s;
      text-decoration: none;
    }

    .nav-links a:hover {
      color: var(--primary-color);
    }

    .btn {
      display: inline-block;
      padding: 10px 20px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s;
      border: 2px solid transparent;
    }

    .btn-outline {
      background: transparent;
      color: var(--primary-color);
      border: 2px solid var(--primary-color);
    }

    .btn-outline:hover {
      background: var(--primary-color);
      color: white;
    }

    .btn-primary {
      background: var(--primary-color);
      color: white;
      border: 2px solid var(--primary-color);
    }

    .btn-primary:hover {
      background: transparent;
      color: var(--primary-color);
    }

    .btn-back {
      background: var(--success-color);
      color: white;
      border: 2px solid var(--success-color);
      margin-right: 10px;
    }

    .btn-back:hover {
      background: transparent;
      color: var(--success-color);
    }
    
    /* Main Content */
    main {
      margin-top: 100px;
      padding: 40px 0;
    }
    
    .project-header {
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 40px;
      margin-bottom: 40px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .project-breadcrumb {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 14px;
      color: #666;
      margin-bottom: 20px;
    }
    
    .project-breadcrumb a {
      color: var(--primary-color);
      text-decoration: none;
    }
    
    .project-breadcrumb a:hover {
      text-decoration: underline;
    }
    
    .project-title {
      display: flex;
      align-items: center;
      gap: 20px;
      margin-bottom: 20px;
    }
    
    .project-badge {
      background: var(--primary-color);
      color: white;
      padding: 8px 20px;
      border-radius: 25px;
      font-size: 14px;
      font-weight: 600;
    }
    
    .project-title h1 {
      font-size: 2.5rem;
      color: var(--dark-color);
      margin: 0;
    }
    
    .project-meta {
      display: flex;
      gap: 30px;
      margin-bottom: 30px;
    }
    
    .meta-item {
      display: flex;
      align-items: center;
      gap: 8px;
      color: #666;
    }
    
    .meta-item i {
      color: var(--primary-color);
    }
    
    .project-description {
      font-size: 1.1rem;
      line-height: 1.8;
      color: #555;
    }
    
    /* Project Content */
    .project-content {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 40px;
      margin-bottom: 40px;
    }
    
    .project-gallery {
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 30px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .gallery-main {
      margin-bottom: 20px;
    }
    
    .gallery-main img {
      width: 100%;
      height: 400px;
      object-fit: cover;
      border-radius: 15px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    .gallery-thumbs {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 15px;
    }
    
    .gallery-thumbs img {
      width: 100%;
      height: 120px;
      object-fit: cover;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.3s;
      opacity: 0.7;
    }
    
    .gallery-thumbs img:hover,
    .gallery-thumbs img.active {
      opacity: 1;
      transform: scale(1.05);
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .project-sidebar {
      display: flex;
      flex-direction: column;
      gap: 30px;
    }
    
    .sidebar-card {
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(10px);
      border-radius: 15px;
      padding: 25px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    .sidebar-card h3 {
      color: var(--dark-color);
      margin-bottom: 15px;
      font-size: 1.3rem;
    }
    
    .project-info-list {
      list-style: none;
    }
    
    .project-info-list li {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      border-bottom: 1px solid #eee;
    }
    
    .project-info-list li:last-child {
      border-bottom: none;
    }
    
    .project-info-list strong {
      color: var(--dark-color);
    }
    
    .project-skills {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
    }
    
    .skill-tag {
      background: var(--primary-color);
      color: white;
      padding: 5px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 500;
    }
    
    .download-section {
      text-align: center;
    }
    
    .download-btn {
      background: var(--success-color);
      color: white;
      padding: 12px 25px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.3s;
      margin-bottom: 10px;
    }
    
    .download-btn:hover {
      background: #27ae60;
      transform: translateY(-2px);
    }
    
    /* Project Details Section */
    .project-details {
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 40px;
      margin-bottom: 40px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .details-tabs {
      display: flex;
      gap: 20px;
      margin-bottom: 30px;
      border-bottom: 2px solid #eee;
    }
    
    .tab-btn {
      background: none;
      border: none;
      padding: 15px 20px;
      font-size: 16px;
      font-weight: 500;
      color: #666;
      cursor: pointer;
      transition: all 0.3s;
      border-bottom: 2px solid transparent;
    }
    
    .tab-btn.active {
      color: var(--primary-color);
      border-bottom-color: var(--primary-color);
    }
    
    .tab-content {
      display: none;
    }
    
    .tab-content.active {
      display: block;
    }
    
    .challenge-solution {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
      margin-bottom: 30px;
    }
    
    .challenge-box, .solution-box {
      padding: 25px;
      border-radius: 15px;
      border-left: 4px solid var(--primary-color);
    }
    
    .challenge-box {
      background: #fff5f5;
      border-left-color: #e74c3c;
    }
    
    .solution-box {
      background: #f0fff4;
      border-left-color: var(--success-color);
    }
    
    .challenge-box h4, .solution-box h4 {
      color: var(--dark-color);
      margin-bottom: 15px;
    }
    
    .results-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
    }
    
    .result-card {
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      color: white;
      padding: 25px;
      border-radius: 15px;
      text-align: center;
    }
    
    .result-number {
      font-size: 2.5rem;
      font-weight: 700;
      display: block;
      margin-bottom: 10px;
    }
    
    .result-label {
      font-size: 14px;
      opacity: 0.9;
    }
    
    /* CTA Section */
    .cta-section {
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 40px;
      text-align: center;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .cta-section h3 {
      color: var(--dark-color);
      margin-bottom: 15px;
      font-size: 1.8rem;
    }
    
    .cta-section p {
      color: #666;
      margin-bottom: 25px;
      font-size: 1.1rem;
    }
    
    .cta-buttons {
      display: flex;
      justify-content: center;
      gap: 20px;
      flex-wrap: wrap;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .project-content {
        grid-template-columns: 1fr;
      }
      
      .project-title {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
      }
      
      .project-title h1 {
        font-size: 2rem;
      }
      
      .project-meta {
        flex-direction: column;
        gap: 15px;
      }
      
      .challenge-solution {
        grid-template-columns: 1fr;
      }
      
      .results-grid {
        grid-template-columns: repeat(2, 1fr);
      }
      
      .details-tabs {
        flex-wrap: wrap;
      }
      
      .nav-links {
        display: none;
      }
      
      .cta-buttons {
        flex-direction: column;
        align-items: center;
      }
    }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
  <header>
    <nav class="navbar">
      <div class="container">
        <a href="index.html" class="logo">
          <img src="images/logo.jpg" alt="EUREKA Logo">
        </a>
        <div class="nav-links">
          <a href="index.php">Accueil</a>
          <a href="services.php">Services</a>
          <a href="idee.php">Réalisations</a>
          <a href="#about">À propos</a>
          <a href="contact.html" class="btn btn-primary">Contact</a>
        </div>
      </div>
    </nav>
  </header>

  <main>
    <div class="container">
      <!-- Project Header -->
      <div class="project-header">
        <div class="project-breadcrumb">
          <a href="idee.php"><i class="fas fa-arrow-left"></i> Retour aux réalisations</a>
          <span>/</span>
          <span id="current-project">Détail du projet</span>
        </div>
        
        <div class="project-title">
          <span class="project-badge" id="project-category"></span>
          <h1 id="project-name"></h1>
        </div>
        
        <div class="project-meta">
          <div class="meta-item">
            <i class="fas fa-user"></i>
            <span>Client: <strong id="project-client"></strong></span>
          </div>
          <div class="meta-item">
            <i class="fas fa-calendar"></i>
            <span>Année: <strong id="project-year"></strong></span>
          </div>
          <div class="meta-item">
            <i class="fas fa-clock"></i>
            <span>Durée: <strong id="project-duration"></strong></span>
          </div>
          <div class="meta-item">
            <i class="fas fa-users"></i>
            <span>Équipe: <strong id="project-team"></strong></span>
          </div>
        </div>
        
        <div class="project-description">
          <p id="project-description">
            
          </p>
        </div>
      </div>

      <!-- Project Content -->
      <div class="project-content">
        <div class="project-gallery">
          <div class="gallery-main">
            <img id="main-image" src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=400&fit=crop" alt="Image principale">
          </div>
          <div class="gallery-thumbs">
       
          </div>
        </div>

        <div class="project-sidebar">
          <div class="sidebar-card">
            <h3>Informations du projet</h3>
            <ul class="project-info-list">
              <li><span>Statut:</span> <strong style="color: var(--success-color);">Terminé</strong></li>
              <li><span>Budget:</span> <strong>15 0000 FCFA</strong></li>
              <li><span>Secteur:</span> <strong>Finance</strong></li>
              <li><span>Plateforme:</span> <strong>Web</strong></li>
            </ul>
          </div>

          <div class="sidebar-card">
            <h3>Technologies utilisées</h3>
            <div class="project-skills">
              <span class="skill-tag">HTML5</span>
              <span class="skill-tag">CSS3</span>
              <span class="skill-tag">JavaScript</span>
              <span class="skill-tag">React</span>
              <span class="skill-tag">Node.js</span>
              <span class="skill-tag">MongoDB</span>
            </div>
          </div>

          <div class="sidebar-card">
            <div class="download-section">
              <h3>Télécharger</h3>
              <a href="#" class="download-btn">
                <i class="fas fa-download"></i>
                Fichiers du projet
              </a>
              <p style="font-size: 12px; color: #666; margin-top: 10px;">
                Inclut: PDF, images haute résolution, fichiers sources
              </p>
            </div>
          </div>
        </div>
      </div>

      <!-- Project Details -->
      <div class="project-details">
        <div class="details-tabs">
          <button class="tab-btn active" data-tab="overview">Aperçu</button>
          <button class="tab-btn" data-tab="process">Processus</button>
          <button class="tab-btn" data-tab="results">Résultats</button>
        </div>

        <div class="tab-content active" id="overview">
          <div class="challenge-solution">
            <div class="challenge-box">
              <h4><i class="fas fa-exclamation-triangle"></i>Defi </h4>
              <p></p>
            </div>
            <div class="solution-box">
              <h4><i class="fas fa-lightbulb"></i> Solution</h4>
              <p> </p>
            </div>
          </div>
        </div>

        <div class="tab-content" id="process">
          <h4>Phases du projet</h4>
          <div style="margin-top: 20px;">
            <div style="display: flex; gap: 20px; margin-bottom: 20px;">
              <div style="width: 40px; height: 40px; background: var(--primary-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">1</div>
              <div>
                <h5></h5>
                <p></p>
              </div>
            </div>
            <div style="display: flex; gap: 20px; margin-bottom: 20px;">
              <div style="width: 40px; height: 40px; background: var(--primary-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">2</div>
              <div>
                <h5></h5>
                <p></p>
              </div>
            </div>
            <div style="display: flex; gap: 20px; margin-bottom: 20px;">
              <div style="width: 40px; height: 40px; background: var(--primary-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">3</div>
              <div>
                <h5></h5>
                <p></p>
              </div>
            </div>
            <div style="display: flex; gap: 20px;">
              <div style="width: 40px; height: 40px; background: var(--success-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">4</div>
              <div>
                <h5></h5>
                <p></p>
              </div>
            </div>
          </div>
        </div>

        <div class="tab-content" id="results">
          <h4>Résultats obtenus</h4>
          <div class="results-grid">
            <div class="result-card">
              <span class="result-number"></span>
              <span class="result-label"></span>
            </div>
            <div class="result-card">
              <span class="result-number"></span>
              <span class="result-label"></span>
            </div>
            <div class="result-card">
              <span class="result-number"></span>
              <span class="result-label"></span>
            </div>
            <div class="result-card">
              <span class="result-number"></span>
              <span class="result-label"></span>
            </div>
          </div>
        </div>
      </div>

      <!-- CTA Section -->
      <div class="cta-section">
        <h3>Vous avez un projet similaire ?</h3>
        <p>Discutons de votre projet et créons ensemble une solution sur mesure pour votre entreprise.</p>
        <div class="cta-buttons">
          <a href="contact.html" class="btn btn-primary">Démarrer un projet</a>
          <a href="idee.php" class="btn btn-outline">Voir d'autres réalisations</a>
        </div>
      </div>
    </div>
  </main>
<script>
  // Données complètes des projets
const projectsData = {
  'site-web-corporate': {
    name: 'Site Web Corporate',
    category: 'Web Design',
    client: 'FinExpert',
    year: '2023',
    duration: '3 mois',
    team: '4 personnes',
    description: 'Refonte complète du site web d\'une entreprise de consulting financier avec une approche moderne, responsive et axée sur l\'expérience utilisateur.',
    skills: ['HTML5', 'CSS3', 'JavaScript', 'React', 'Node.js', 'MongoDB'],
    images: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=800&h=400&fit=crop'
    ],
    challenge: "L'ancien site web de FinExpert était obsolète, peu responsive et ne reflétait pas le professionnalisme de l'entreprise.",
    solution: "Création d'un site web moderne avec une architecture responsive et une navigation intuitive.",
    phases: [
      {
        title: "Analyse et recherche",
        description: "Étude approfondie des besoins client et analyse de la concurrence."
      },
      {
        title: "Conception UX/UI",
        description: "Création des maquettes et prototypes interactifs."
      },
      {
        title: "Développement",
        description: "Intégration front-end et back-end avec les technologies modernes."
      },
      {
        title: "Tests et déploiement",
        description: "Tests complets et mise en production du site web."
      }
    ],
    results: {
      traffic: "+150%",
      conversion: "+80%",
      bounce: "-60%",
      satisfaction: "95%"
    }
  },
  'identite-visuelle': {
    name: 'Identité Visuelle TechNova',
    category: 'Branding',
    client: 'TechNova',
    year: '2022',
    duration: '2 mois',
    team: '3 personnes',
    description: 'Création complète de l\'identité visuelle pour une startup technologique, incluant logo, charte graphique et supports de communication.',
    skills: ['Photoshop', 'Illustrator', 'InDesign', 'Figma'],
    images: [
      'https://images.unsplash.com/photo-1553818735-91a8816b997a?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1547658719-da2b51169166?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1542744094-24638eff58bb?w=800&h=400&fit=crop'
    ],
    challenge: "L'entreprise n'avait pas d'identité visuelle cohérente et peinait à se différencier sur le marché tech.",
    solution: "Développement d'une charte graphique complète avec un logo moderne et des couleurs distinctives.",
    phases: [
      {
        title: "Brief créatif",
        description: "Définition des objectifs et du positionnement de la marque."
      },
      {
        title: "Recherche et inspiration",
        description: "Exploration des tendances et création de moodboards."
      },
      {
        title: "Création du logo",
        description: "Conception de plusieurs propositions de logo et raffinement."
      },
      {
        title: "Charte graphique",
        description: "Développement complet de l'identité visuelle et des déclinaisons."
      }
    ],
    results: {
      traffic: "+200%",
      conversion: "+90%",
      bounce: "-50%",
      satisfaction: "98%"
    }
  },
  'app-mobile': {
    name: 'Application Mobile E-commerce',
    category: 'Mobile App',
    client: 'ShopMaster',
    year: '2023',
    duration: '4 mois',
    team: '6 personnes',
    description: 'Développement d\'une application mobile e-commerce native pour iOS et Android avec système de paiement intégré.',
    skills: ['React Native', 'Firebase', 'Stripe', 'Redux', 'TypeScript'],
    images: [
      'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=400&fit=crop'
    ],
    challenge: "Le client avait besoin d'une solution mobile pour étendre sa boutique en ligne et toucher plus de clients.",
    solution: "Développement d'une app native performante avec une expérience utilisateur optimisée pour le mobile.",
    phases: [
      {
        title: "Spécifications techniques",
        description: "Définition de l'architecture et des fonctionnalités."
      },
      {
        title: "Design UI/UX",
        description: "Création des interfaces adaptées aux mobiles."
      },
      {
        title: "Développement",
        description: "Programmation native iOS et Android."
      },
      {
        title: "Tests et publication",
        description: "Tests approfondis et publication sur les stores."
      }
    ],
    results: {
      traffic: "+300%",
      conversion: "+120%",
      bounce: "-45%",
      satisfaction: "92%"
    }
  },
  'campagne-marketing': {
    name: 'Campagne Marketing Digital',
    category: 'Marketing',
    client: 'BioVert',
    year: '2023',
    duration: '2 mois',
    team: '5 personnes',
    description: 'Campagne marketing digitale complète pour le lancement d\'une gamme de produits bio, incluant SEO, réseaux sociaux et publicité payante.',
    skills: ['Google Ads', 'Facebook Ads', 'SEO', 'Analytics', 'Mailchimp'],
    images: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1553818735-91a8816b997a?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&h=400&fit=crop'
    ],
    challenge: "Lancement d'une nouvelle gamme de produits bio dans un marché concurrentiel avec un budget limité.",
    solution: "Stratégie multi-canal optimisée avec ciblage précis et contenu engageant.",
    phases: [
      {
        title: "Audit et stratégie",
        description: "Analyse du marché et définition de la stratégie marketing."
      },
      {
        title: "Création de contenu",
        description: "Production de contenu visuel et rédactionnel."
      },
      {
        title: "Lancement des campagnes",
        description: "Mise en place des campagnes sur tous les canaux."
      },
      {
        title: "Optimisation",
        description: "Suivi des performances et optimisation continue."
      }
    ],
    results: {
      traffic: "+250%",
      conversion: "+160%",
      bounce: "-35%",
      satisfaction: "94%"
    }
  },
  'systeme-gestion': {
    name: 'Système de Gestion d\'Entreprise',
    category: 'Software',
    client: 'AdminPro',
    year: '2022',
    duration: '6 mois',
    team: '8 personnes',
    description: 'Développement d\'un système de gestion d\'entreprise complet avec modules RH, comptabilité et CRM intégrés.',
    skills: ['PHP', 'Laravel', 'MySQL', 'Vue.js', 'Docker'],
    images: [
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=800&h=400&fit=crop'
    ],
    challenge: "L'entreprise utilisait plusieurs logiciels non connectés, créant des inefficacités et des erreurs.",
    solution: "Développement d'une solution intégrée centralisant tous les processus métier.",
    phases: [
      {
        title: "Analyse des besoins",
        description: "Audit des processus existants et définition des requirements."
      },
      {
        title: "Architecture système",
        description: "Conception de l'architecture technique et de la base de données."
      },
      {
        title: "Développement modulaire",
        description: "Développement itératif des différents modules."
      },
      {
        title: "Formation et déploiement",
        description: "Formation des utilisateurs et mise en production."
      }
    ],
    results: {
      traffic: "+180%",
      conversion: "+100%",
      bounce: "-55%",
      satisfaction: "96%"
    }
  },
  'portfolio-artiste': {
    name: 'Portfolio d\'Artiste',
    category: 'Web Design',
    client: 'Marie Dubois',
    year: '2023',
    duration: '1 mois',
    team: '2 personnes',
    description: 'Création d\'un portfolio en ligne pour une artiste peintre, mettant en valeur ses œuvres avec une galerie interactive.',
    skills: ['HTML5', 'CSS3', 'JavaScript', 'Lightbox', 'Responsive Design'],
    images: [
      'https://images.unsplash.com/photo-1547658719-da2b51169166?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1542744094-24638eff58bb?w=800&h=400&fit=crop',
      'https://images.unsplash.com/photo-1553818735-91a8816b997a?w=800&h=400&fit=crop'
    ],
    challenge: "L'artiste avait besoin d'une présence web pour exposer ses œuvres et toucher de nouveaux clients.",
    solution: "Création d'un portfolio élégant avec galerie interactive et système de contact intégré.",
    phases: [
      {
        title: "Brief artistique",
        description: "Compréhension de l'univers artistique et des objectifs."
      },
      {
        title: "Conception visuelle",
        description: "Design sur mesure respectant l'identité artistique."
      },
      {
        title: "Développement",
        description: "Intégration avec galerie interactive et optimisation."
      },
      {
        title: "Optimisation SEO",
        description: "Référencement pour améliorer la visibilité en ligne."
      }
    ],
    results: {
      traffic: "+400%",
      conversion: "+200%",
      bounce: "-40%",
      satisfaction: "100%"
    }
  }
};

// Fonction pour obtenir l'ID du projet depuis l'URL
function getProjectId() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');
  console.log('ID récupéré depuis l\'URL:', id);
  
  if (!id || !projectsData[id]) {
    console.error('ID du projet invalide ou non trouvé:', id);
    // Optionnel: rediriger vers la page des réalisations
    // window.location.href = 'idee.php';
    return null;
  }
  return id;
}

// Fonction pour mettre à jour la galerie
function updateGallery(images) {
  const mainImg = document.getElementById('main-image');
  const thumbsContainer = document.querySelector('.gallery-thumbs');
  
  if (images && images.length > 0) {
    mainImg.src = images[0];
    mainImg.alt = 'Image principale du projet';
    thumbsContainer.innerHTML = '';
    
    images.forEach((img, index) => {
      const thumb = document.createElement('img');
      thumb.src = img.replace('800', '300').replace('400', '200');
      thumb.alt = `Vue ${index + 1}`;
      if (index === 0) thumb.classList.add('active');
      
      thumb.addEventListener('click', () => {
        document.querySelectorAll('.gallery-thumbs img').forEach(t => t.classList.remove('active'));
        thumb.classList.add('active');
        mainImg.src = img;
      });
      
      thumbsContainer.appendChild(thumb);
    });
  }
}

// Fonction pour mettre à jour le contenu des onglets
function updateTabContent(project) {
  // Onglet Aperçu - Défi et Solution
  const challengeBox = document.querySelector('.challenge-box p');
  const solutionBox = document.querySelector('.solution-box p');
  
  if (challengeBox) challengeBox.textContent = project.challenge;
  if (solutionBox) solutionBox.textContent = project.solution;
  
  // Onglet Processus - Phases
  const processContent = document.getElementById('process');
  if (processContent && project.phases) {
    const phasesHtml = project.phases.map((phase, index) => `
      <div style="display: flex; gap: 20px; margin-bottom: 20px;">
        <div style="width: 40px; height: 40px; background: ${index === project.phases.length - 1 ? 'var(--success-color)' : 'var(--primary-color)'}; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">${index + 1}</div>
        <div>
          <h5>${phase.title}</h5>
          <p>${phase.description}</p>
        </div>
      </div>
    `).join('');
    
    processContent.innerHTML = `
      <h4>Phases du projet</h4>
      <div style="margin-top: 20px;">
        ${phasesHtml}
      </div>
    `;
  }
  
  // Onglet Résultats
  const results = document.querySelectorAll('.result-card');
  const resultLabels = ['Augmentation du trafic', 'Taux de conversion', 'Réduction bounce rate', 'Satisfaction client'];
  
  if (results.length >= 4 && project.results) {
    const resultValues = [
      project.results.traffic,
      project.results.conversion,
      project.results.bounce,
      project.results.satisfaction
    ];
    
    results.forEach((result, index) => {
      const numberSpan = result.querySelector('.result-number');
      const labelSpan = result.querySelector('.result-label');
      
      if (numberSpan) numberSpan.textContent = resultValues[index] || '0%';
      if (labelSpan) labelSpan.textContent = resultLabels[index] || '';
    });
  }
}

// Fonction principale pour charger les données
function loadProject() {
  console.log("Chargement du projet...");
  
  const projectId = getProjectId();
  if (!projectId) {
    console.error("Impossible de charger le projet: ID invalide");
    return;
  }
  
  const project = projectsData[projectId];
  console.log("Projet chargé:", project);
  
  // Mettre à jour le titre de la page
  document.title = `${project.name} - Détail du Projet`;
  
  // Mettre à jour les informations de base
  const elements = {
    'current-project': project.name,
    'project-name': project.name,
    'project-category': project.category,
    'project-client': project.client,
    'project-year': project.year,
    'project-duration': project.duration,
    'project-team': project.team,
    'project-description': project.description
  };
  
  Object.entries(elements).forEach(([id, value]) => {
    const element = document.getElementById(id);
    if (element) {
      element.textContent = value;
    }
  });
  
  // Mettre à jour les compétences
  const skillsContainer = document.querySelector('.project-skills');
  if (skillsContainer) {
    skillsContainer.innerHTML = '';
    project.skills.forEach(skill => {
      const tag = document.createElement('span');
      tag.className = 'skill-tag';
      tag.textContent = skill;
      skillsContainer.appendChild(tag);
    });
  }
  
  // Mettre à jour la galerie
  updateGallery(project.images);
  
  // Mettre à jour les onglets
  updateTabContent(project);
  
  console.log("Projet chargé avec succès!");
}

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
  console.log("DOM chargé, initialisation...");
  
  // Charger le projet
  loadProject();
  
  // Gestion des onglets
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      // Retirer la classe active de tous les boutons et contenus
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      
      // Ajouter la classe active au bouton cliqué et au contenu correspondant
      this.classList.add('active');
      const targetTab = document.getElementById(this.dataset.tab);
      if (targetTab) {
        targetTab.classList.add('active');
      }
    });
  });
  
  console.log("Initialisation terminée");
});
</script>