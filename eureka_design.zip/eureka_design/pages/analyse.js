//import { postFile } from './api.js'; // si tu utilises des modules, sinon inclus api.js avant analyse.js dans ton HTML
let userName = "";
let step = 0; // Si prénom déjà connu, passer à étape 1

let currentStream = null;
let selectedImage = null;

// Extraction du prénom simple dans une phrase donnée, en priorité après "je m'appelle"
function extractFirstName(message) {
    // Passage en minuscule pour recherche insensible à la casse
    const lower = message.toLowerCase();

    // Chercher "je m'appelle" et extraire ce qui suit
    const phrase = "je m'appelle";
    const idx = lower.indexOf(phrase);
    if (idx !== -1) {
        let namePart = message.slice(idx + phrase.length).trim();
        // On ne garde que le premier mot (prénom)
        const firstName = namePart.split(/\s+/)[0];
        if (firstName) {
            // Majuscule au début, reste en minuscule
            return firstName.charAt(0).toUpperCase() + firstName.slice(1).toLowerCase();
        }
    }

    // Sinon essayer d'autres formulations avec regex
    const patterns = [
        /moi c'est (\w+)/i,
        /c'est (\w+)/i,
        /je suis (\w+)/i,
        /mon nom est (\w+)/i,
        /^(\w+)$/i
    ];

    for (const regex of patterns) {
        const match = message.match(regex);
        if (match && match[1]) {
            return match[1].charAt(0).toUpperCase() + match[1].slice(1).toLowerCase();
        }
    }
    return null;
}

// Met à jour la zone d'accueil avec le prénom
function updateWelcomeMessage() {
    if (userName) {
        document.getElementById('welcomeUser').textContent = `Bienvenue, ${userName}`;
    }
}

// Fonctions modales, caméra, upload, etc.
function showFunctions() { document.getElementById('functionsModal').classList.add('show'); }
function closeFunctions() { document.getElementById('functionsModal').classList.remove('show'); }
function openScanner() { closeFunctions(); showImageActions(); }
function showImageActions() { document.getElementById('imageActionsModal').classList.add('show'); }
function closeImageActions() { document.getElementById('imageActionsModal').classList.remove('show'); }
function openCamera() { closeFunctions(); showImageActions(); }
function openCameraCapture() { closeImageActions(); document.getElementById('cameraModal').classList.add('show'); startCamera(); }

async function startCamera() {
    try {
        currentStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        const videoElement = document.getElementById('cameraVideo');
        videoElement.srcObject = currentStream;

         // Quand la vidéo est prête, on attend 0.5s et on capture
       /* videoElement.onloadedmetadata = () => {
            videoElement.play();

            setTimeout(() => {
                capturePhoto();
            }, 500); // 10 seconde
        };*/
    } catch (err) {
        console.error('Erreur accès caméra:', err);
        alert('Impossible d\'accéder à la caméra');
        closeCamera();
    }
}

function capturePhoto() {
    const canvas = document.getElementById('canvas');
    const video = document.getElementById('cameraVideo');
    const context = canvas.getContext('2d');

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
        const imageUrl = URL.createObjectURL(blob);
        addImageToChat(imageUrl);

        // 🔥 Ajoute l’appel pour envoyer à l’API
        envoyerImageBlob(blob);

        closeCamera();
    }, 'image/jpeg');
}

function closeCamera() {
    if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
        currentStream = null;
    }
    document.getElementById('cameraModal').classList.remove('show');
}

function openFileUpload() { closeFunctions(); document.getElementById('fileInput').click(); }
function openPhotoUpload() { closeFunctions(); document.getElementById('fileInput').click(); }
function openGallery() { closeImageActions(); document.getElementById('fileInput').click(); }

function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    addImageToChat(url);

    // 🔥 Ajoute l’appel pour envoyer à l’API
    envoyerImageBlob(file);
}

function addImageToChat(imageUrl) {
    const chatArea = document.getElementById('chatArea');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user';
    messageDiv.innerHTML = `
        <div class="image-resize-container">
            <img src="${imageUrl}" alt="Image envoyée" class="image-preview" style="max-width: 200px; border-radius: 10px;">
            <div class="resize-handle"></div>
        </div>
        <div class="message-bubble">Image envoyée</div>
    `;
    chatArea.appendChild(messageDiv);
    chatArea.scrollTop = chatArea.scrollHeight;

    setTimeout(() => {
        addBotMessage("J'ai bien reçu votre image. Que souhaitez-vous que je fasse avec cette image ?");
    }, 1000);

     // 🔥 Lance l'envoi à l'API juste après l'ajout au chat
    envoyerImageAvecUrl(imageUrl);
}

function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();

    if (!message) return;

    addUserMessage(message);
    input.value = '';

    if (step === 0) {
        const extractedName = extractFirstName(message);
        if (extractedName) {
            userName = extractedName;
            localStorage.setItem('userName', userName);
            updateWelcomeMessage();
            setTimeout(() => {
                addBotMessage(`Enchanté, ${userName} ! 👋 Bienvenue sur GreenDocAI 🌿`);
            }, 1000);
            setTimeout(() => {
                addBotMessage(`Comment puis-je vous aider aujourd’hui ?`);
            }, 2500);
            step = 1;
        } else {
            setTimeout(() => {
                addBotMessage("Je n'ai pas bien compris votre prénom, pouvez-vous me le redonner s'il vous plaît ?");
            }, 500);
        }
    } else {
        // ✅ Ici on appelle ton API pour obtenir la vraie réponse
        addBotMessage("⏳ Je réfléchis à votre question..."); // optionnel: feedback utilisateur

        callApi(message)
            .then(data => {
                // 🔎 Adapte "data.response" à la clé réelle de ta réponse JSON
                const botReply = data.response || JSON.stringify(data);
                addBotMessage(botReply);
            })
            .catch(error => {
                console.error("Erreur lors de l’appel API :", error);
                addBotMessage("❌ Une erreur est survenue lors de la communication avec l’API.");
            });
    }
}


function addUserMessage(text) {
    const chatArea = document.getElementById('chatArea');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user';
    messageDiv.innerHTML = `<div class="message-bubble">${text}</div>`;
    chatArea.appendChild(messageDiv);
    chatArea.scrollTop = chatArea.scrollHeight;
}

function addBotMessage(text) {
    const chatArea = document.getElementById('chatArea');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot';
    messageDiv.innerHTML = `<div class="message-bubble">${text}</div>`;
    chatArea.appendChild(messageDiv);
    chatArea.scrollTop = chatArea.scrollHeight;
}

// Other functions
function openSettings() { alert('Paramètres - Fonctionnalité à implémenter'); }
function toggleVoice() { alert('Fonction vocale - Fonctionnalité à implémenter'); }

// Event listeners
document.getElementById('messageInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-overlay')) {
        closeFunctions();
        closeImageActions();
    }
});

document.addEventListener('mousedown', function(e) {
    if (e.target.classList.contains('resize-handle')) {
        e.preventDefault();
        const img = e.target.parentElement.querySelector('img');
        const startX = e.clientX;
        const startY = e.clientY;
        const startWidth = img.offsetWidth;
        const startHeight = img.offsetHeight;

        function onMouseMove(e) {
            const newWidth = startWidth + (e.clientX - startX);
            if (newWidth > 50 && newWidth < 300) {
                img.style.maxWidth = newWidth + 'px';
            }
        }

        function onMouseUp() {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }
});

// Reconnaissance vocale
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition;
if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.lang = 'fr-FR';
    recognition.continuous = false;
    recognition.interimResults = false;
} else {
    alert("La reconnaissance vocale n'est pas supportée sur ce navigateur.");
}

function toggleVoice() {
    if (!recognition) return;

    recognition.start();
    console.log("🎤 Écoute en cours...");

    recognition.onstart = () => {
        alert("🎙️ Parlez maintenant...");
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        console.log("Texte reconnu :", transcript);
        document.getElementById('messageInput').value = transcript;
        sendMessage();
    };

    recognition.onerror = (event) => {
        console.error("Erreur de reconnaissance :", event.error);
        alert("Erreur micro : " + event.error);
    };

    recognition.onend = () => {
        console.log("🎤 Arrêt de l'écoute.");
    };
}

// Au chargement, on affiche les messages d’accueil selon prénom connu ou non
window.addEventListener('DOMContentLoaded', () => {
    addBotMessage("Bonjour !");
    if (userName) {
        updateWelcomeMessage();
        setTimeout(() => {
            addBotMessage(`Ravi de vous revoir, ${userName} 👋`);
            setTimeout(() => {
                addBotMessage("Comment puis-je vous aider aujourd’hui ?");
            }, 1000);
        }, 1000);
        step = 1;
    } else {
        setTimeout(() => {
            addBotMessage("Quel est votre prénom ?");
        }, 1000);
        step = 0;
    }
});

window.addEventListener('DOMContentLoaded', () => {
    const retourBtn = document.getElementById('btnRetour');
    if (retourBtn) {
        retourBtn.addEventListener('click', () => {
            window.location.href = 'index.html'; // adapte le chemin si besoin
        });
    } else {
        console.error("⚠️ Bouton 'Retour' introuvable : vérifie l'ID et que le script est bien chargé après le HTML.");
    }
});



/*import { callApi } from './api.js';

async function analyserImage() {
  const fileInput = document.getElementById("fileInput");
  const file = fileInput.files[0];

  if (!file) {
    alert("Veuillez sélectionner une image !");
    return;
  }

  try {
    const result = await callApi(file);
    afficherResultat(result);
  } catch (err) {
    alert("Erreur lors de l’analyse : " + err.message);
  }
}

function afficherResultat(result) {
  console.log("Résultat :", result);
  const chatArea = document.getElementById("chatArea");
  chatArea.innerHTML += `<div class="bot-message">
    🌿 Plante : ${result.plant}<br>
    😷 Maladie : ${result.disease}<br>
    📝 Symptômes : ${result.symptoms}<br>
    ⚠️ Cause : ${result.cause}<br>
    💊 Traitement : ${result.treatment}
  </div>`;
}*/
