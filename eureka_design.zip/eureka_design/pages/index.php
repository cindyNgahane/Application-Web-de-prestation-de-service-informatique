<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EUREKA DESIGN & KONSULTING | Solutions Digitales Créatives</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="index.html" class="logo">
                <img src="images/logo.jpg" alt="EUREKA Logo">
                <span>E.D.K</span>
            </a>
            <div class="nav-links">
                <a href="index.php" class="active">Accueil</a>
                <a href="idee.php">Services</a>
                <a href="#about">À propos</a>
                
                <div class="auth-buttons">
                    <a href="login.php" class="btn btn-outline">Connexion</a>
                    <a href="inscription.php" class="btn btn-primary">S'inscrire</a>
                </div>
            </div>
            <button class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Transformez vos idées en solutions digitales</h1>
                <p>EUREKA DESIGN & KONSULTING vous accompagne dans la réalisation de vos projets avec expertise et créativité.</p>
                <div class="hero-buttons">
                    <a href="idee.php" class="btn btn-primary">Découvrir nos services</a>
                    <a href="#contact" class="btn btn-outline">Nous contacter</a>
                </div>
            </div>
            <div class="hero-image">
                <img src="images/femme noir.png" alt="Digital Solutions Illustration">
            </div>
        </div>
    </section>

    <!-- Services Preview -->
    <section class="services-preview">
        <div class="container">
            <h2 class="section-title">Nos Services</h2>
            <p class="section-subtitle">Des solutions sur mesure pour répondre à vos besoins</p>
            
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-paint-brush"></i>
                    </div>
                    <h3>Design Graphique</h3>
                    <p>Création d'identités visuelles percutantes et mémorables.</p>
                    <a href="idee.php#graphic-design" class="btn btn-link">En savoir plus <i class="fas fa-arrow-right"></i></a>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <h3>Services de communication</h3>
                    <ul class="service-features">
                        <li>Conseil et stratégie</li>
                        <li>Création graphique et design</li>
                        <li>Publicité et médias</li>
                        <li>Supports imprimés</li>
                        <li>Motion design</li>
                    </ul>
                    <a href="idee.php" class="btn btn-outline">En savoir plus</a>
                </div>
                
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-globe"></i>
                    </div>
                    <h3>Services Web</h3>
                    <ul class="service-features">
                        <li>Création de sites internet</li>
                        <li>Refonte de site web</li>
                        <li>Référencement naturel (SEO)</li>
                        <li>Référencement Payant (SEA)</li>
                        <li>Social Ads</li>
                    </ul>
                    <a href="idee.php" class="btn btn-outline">En savoir plus</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3>Stratégie Digitale</h3>
                    <p>Optimisez votre présence en ligne avec nos experts.</p>
                    <a href="idee.php#digital-strategy" class="btn btn-link">En savoir plus <i class="fas fa-arrow-right"></i></a>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <h3>Motion et vidéo</h3>
                    <ul class="service-features">
                        <li>Rédaction de scénarios</li>
                        <li>Design et animation graphique</li>
                        <li>Montage vidéo</li>
                        <li>Diffusion stratégique</li>
                    </ul>
                    <a href="idee.php" class="btn btn-outline">En savoir plus</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <h3>Impression et Serigraphie</h3>
                    <ul class="service-features">
                        <li>Impression Laser(carte de voeux, mariage,visite etc)</li>
                        <li>Impression des :plos,tee-shirts,casquettes etc</li>
                        <li>Rool-up</li>
                        
                    </ul>
                    <a href="idee.php" class="btn btn-outline">En savoir plus</a>
                </div>
            </div>
            
            <div class="text-center">
                <a href="idee.php" class="btn btn-secondary">Voir tous nos services</a>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about" id="about">
        <div class="container">
            <div class="about-image">
                <img src="images/femmetailleur.png" alt="Notre équipe">
            </div>
            <div class="about-content">
                <h2 class="section-title">Qui sommes-nous ?</h2>
                <p>EUREKA DESIGN & KONSULTING est une agence digitale innovante spécialisée dans la création de solutions sur mesure pour les entreprises ambitieuses.</p>
                <p>Notre équipe pluridisciplinaire combine expertise technique et créativité pour vous offrir des résultats exceptionnels.</p>
                <ul class="about-features">
                    <li><i class="fas fa-check-circle"></i> Approche personnalisée</li>
                    <li><i class="fas fa-check-circle"></i> Méthodologie agile</li>
                    <li><i class="fas fa-check-circle"></i> Suivi transparent</li>
                    <li><i class="fas fa-check-circle"></i> Satisfaction garantie</li>
                </ul>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials">
        <div class="container">
            <h2 class="section-title">Ils nous font confiance</h2>
            <p class="section-subtitle">Découvrez ce que nos clients disent de nous</p>
            
            <div class="testimonials-slider">
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <div class="rating">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p>"Le travail réalisé par EUREKA a dépassé nos attentes. Leur approche professionnelle et leur réactivité ont fait toute la différence."</p>
                    </div>
                    <div class="testimonial-author">
                        
                        <div>
                            <h4>Sophie Martin</h4>
                            <span>Directrice Marketing, TechSolutions</span>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <div class="rating">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p>"Notre nouveau site web a considérablement amélioré notre visibilité en ligne. Merci à toute l'équipe pour leur excellent travail!"</p>
                    </div>
                    <div class="testimonial-author">
                        
                        <div>
                            <h4>Thomas Dubois</h4>
                            <span>PDG, GreenLife</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact" id="contact">
        <div class="container">
            <h2 class="section-title">Contactez-nous</h2>
            <p class="section-subtitle">Nous sommes à votre écoute pour discuter de votre projet</p>
            
            <div class="contact-container">
                <div class="contact-info">
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h4>Adresse</h4>
                            <p>Douala</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-phone-alt"></i>
                        <div>
                            <h4>Téléphone</h4>
                            <p>+237 6 90 58 85 99</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h4>Email</h4>
                            <p>contact@eureka-design.com</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h4>Horaires</h4>
                            <p>Lundi-Vendredi: 9h-18h</p>
                        </div>
                    </div>
                </div>
                
                <div class="modal-overlay" id="contactModal">
                    <div class="modal-content">
                        <form class="contact-form" id="contactForm">
                            <div class="form-group">
                                <input type="text" id name="nom" placeholder="Votre nom" required>
                            </div>
                            <div class="form-group">
                                <input type="email" id="email" name="email" placeholder="Votre email" required>
                            </div>
                            <div class="form-group">
                                <input type="text" id="subject" name="sujet" placeholder="Sujet">
                            </div>
                            <div class="form-group">
                                <textarea id="message" rows="5" name="message" placeholder="Votre message" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Envoyer le message</button> 
                        </form>
                        <div id="success-message" style="display:none; color: #000">✅ Message envoyé avec succès !</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <a href="index.php" class="logo">
                        
                        <span>EUREKA</span>
                    </a>
                    <p>Solutions digitales innovantes pour votre entreprise.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                
                <div class="footer-col">
                    <h4>Liens rapides</h4>
                    <ul>
                        <li><a href="index.php">Accueil</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="#about">À propos</a></li>
                        <li><a href="#contact">Contact</a></li>
                        <li><a href="login.php">Connexion</a></li>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h4>Services</h4>
                    <ul>
                        <li><a href="services.html#graphic-design">Design Graphique</a></li>
                        <li><a href="services.html#web-dev">Développement Web</a></li>
                        <li><a href="services.html#digital-strategy">Stratégie Digitale</a></li>
                        <li><a href="services.html#branding">Branding</a></li>
                        <li><a href="services.html#seo">SEO & Marketing</a></li>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h4>Newsletter</h4>
                    <p>Abonnez-vous pour recevoir nos dernières actualités.</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Votre email" required>
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2023 EUREKA DESIGN & KONSULTING. Tous droits réservés.</p>
                <div class="footer-links">
                    <a href="#">Politique de confidentialité</a>
                    <a href="#">Conditions d'utilisation</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
    <script>
        (function(){
            emailjs.init("HNn2aUdGxxbVMZrJa"); // <-- À remplacer
        })();
        // Envoi du formulaire
        document.getElementById("contactForm").addEventListener("submit", function(event) {
            event.preventDefault();
            
            emailjs.sendForm('service_1smbb3j', 'template_bhdscff', this)
            .then(function(response) {
                document.getElementById("success-message").style.display = "block";
                setTimeout(() => closeForm(), 3000);
            }, function(error) {
                alert("Erreur lors de l'envoi. Veuillez réessayer.");
            });
        });
        </script>
        <script src="js/main.js"></script>
</body>
</html>