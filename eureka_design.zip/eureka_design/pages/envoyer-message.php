<?php
session_start();
require_once 'admin/databases.php';

// Définir le header pour JSON
header('Content-Type: application/json');

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'client') {
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit();
}

// Vérification que la requête est POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit();
}

try {
    // Récupération des données avec validation
    $id_projet = isset($_POST['id_projet']) && is_numeric($_POST['id_projet']) ? intval($_POST['id_projet']) : null;
    $id_destinataire = isset($_POST['id_destinataire']) && is_numeric($_POST['id_destinataire']) ? intval($_POST['id_destinataire']) : null;
    $sujet = isset($_POST['sujet']) ? trim($_POST['sujet']) : '';
    $contenu = isset($_POST['contenu']) ? trim($_POST['contenu']) : '';
    $priorite = isset($_POST['priorite']) ? trim($_POST['priorite']) : 'normale';
    $id_expediteur = $_SESSION['user_id'];
    
    // Validation des données obligatoires
    if (empty($id_projet) || empty($contenu)) {
        throw new Exception('Le projet et le contenu sont obligatoires');
    }
    
    // Validation de la priorité
    $priorites_autorisees = ['normale', 'haute', 'urgente'];
    if (!in_array($priorite, $priorites_autorisees)) {
        $priorite = 'normale';
    }
    
    // Vérification que le projet appartient bien au client
    $stmt = $pdo->prepare("SELECT id_projet FROM projet WHERE id_projet = ? AND id_client = ?");
    $stmt->execute([$id_projet, $id_expediteur]);
    if (!$stmt->fetch()) {
        throw new Exception('Projet non trouvé ou non autorisé');
    }
    
    // SOLUTION DÉFINITIVE : Trouver un gestionnaire disponible
    $destinataire_final_id = null;
    
    // 1. Si un destinataire spécifique est fourni, vérifier qu'il est gestionnaire et actif
    if (!empty($id_destinataire)) {
        $stmt = $pdo->prepare("SELECT id_utilisateur FROM utilisateur WHERE id_utilisateur = ? AND type = 'gestionnaire' AND statut = 'actif'");
        $stmt->execute([$id_destinataire]);
        if ($stmt->fetch()) {
            $destinataire_final_id = $id_destinataire;
        }
    }
    
    // 2. Si pas de destinataire spécifique valide, prendre le premier gestionnaire actif
    if (!$destinataire_final_id) {
        $stmt = $pdo->prepare("SELECT id_utilisateur FROM utilisateur WHERE type = 'gestionnaire' AND statut = 'actif' ORDER BY id_utilisateur ASC LIMIT 1");
        $stmt->execute();
        $gestionnaire = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($gestionnaire) {
            $destinataire_final_id = $gestionnaire['id_utilisateur'];
        } else {
            throw new Exception('Aucun gestionnaire disponible pour recevoir votre message. Veuillez contacter l\'administrateur système.');
        }
    }
    
    // Récupération des informations du projet pour le message
    $stmt = $pdo->prepare("SELECT p.*, s.nom as service_nom FROM projet p JOIN service s ON p.id_service = s.id_service WHERE p.id_projet = ?");
    $stmt->execute([$id_projet]);
    $projet = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$projet) {
        throw new Exception('Informations du projet non trouvées');
    }
    
    // Construction du message complet
    $message_complet = "=== DEMANDE CONCERNANT LE PROJET ===\n";
    $message_complet .= "Projet: " . $projet['service_nom'] . "\n";
    $message_complet .= "ID Projet: #" . $id_projet . "\n";
    $message_complet .= "Statut actuel: " . ucfirst(str_replace('_', ' ', $projet['statut'])) . "\n";
    $message_complet .= "Sujet: " . $sujet . "\n";
    $message_complet .= "Priorité: " . strtoupper($priorite) . "\n";
    $message_complet .= "Date: " . date('d/m/Y H:i') . "\n";
    $message_complet .= "Client: " . ($_SESSION['user_nom'] ?? 'Utilisateur #' . $id_expediteur) . "\n";
    $message_complet .= "===============================\n\n";
    $message_complet .= "MESSAGE:\n";
    $message_complet .= $contenu . "\n\n";
    $message_complet .= "--- Fin du message ---";
    
    // Début de la transaction
    $pdo->beginTransaction();
    
    // Insertion du message dans la base de données
    $stmt = $pdo->prepare("INSERT INTO message (contenu, id_expediteur, id_destinataire, date_envoi, est_lu) VALUES (?, ?, ?, current_timestamp(), 0)");
    $result = $stmt->execute([$message_complet, $id_expediteur, $destinataire_final_id]);
    
    if (!$result) {
        throw new Exception('Erreur lors de l\'insertion du message');
    }
    
    // Validation de la transaction
    $pdo->commit();
    
    // Log de l'activité
    error_log("Message envoyé - Projet: {$id_projet}, Expéditeur: {$id_expediteur}, Destinataire: {$destinataire_final_id}, Sujet: {$sujet}");
    
    echo json_encode([
        'success' => true, 
        'message' => 'Votre message a été envoyé avec succès au gestionnaire. Vous recevrez une réponse dans les plus brefs délais.',
        'data' => [
            'projet_id' => $id_projet,
            'sujet' => $sujet,
            'priorite' => $priorite,
            'date_envoi' => date('d/m/Y H:i'),
            'destinataire_id' => $destinataire_final_id
        ]
    ]);
    
} catch (PDOException $e) {
    // Annuler la transaction en cas d'erreur
    if ($pdo->inTransaction()) {
        $pdo->rollback();
    }
    
    // Log de l'erreur
    error_log("Erreur PDO dans envoyer-message.php: " . $e->getMessage());
    
    echo json_encode([
        'success' => false, 
        'message' => 'Erreur technique lors de l\'envoi du message. Veuillez réessayer.'
    ]);
    
} catch (Exception $e) {
    // Annuler la transaction en cas d'erreur
    if ($pdo->inTransaction()) {
        $pdo->rollback();
    }
    
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?>