<?php
session_start();
require 'admin/databases.php';

// Vérification de l'authentification
//if (!isset($_SESSION['utilisateur_id'])) {
   // header('Location: login.php');
    //exit();
//}

// Récupération des messages
$sql = "SELECT m.*, u.nom as expediteur_nom 
        FROM message m
        JOIN utilisateur u ON m.id_expediteur = u.id_utilisateur
        WHERE m.id_destinataire = ?
        ORDER BY m.date_envoi DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$_SESSION['user_id']]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Marquer comme lus
$pdo->prepare("UPDATE message SET est_lu = 1 WHERE id_destinataire = ? AND est_lu = 0")
    ->execute([$_SESSION['user_id']]);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Messages - Eureka Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .message-unread {
            background-color: #f8f9fa;
            font-weight: 500;
        }
        .message-item {
            transition: all 0.3s ease;
        }
        .message-item:hover {
            background-color: #f1f1f1;
        }
        .message-avatar {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 50%;
            background-color: #4e73df;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'header-client.php'; ?>

    <div class="container py-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="bi bi-envelope me-2"></i>Mes messages</h4>
            </div>
            <div class="card-body p-0">
                <?php if (count($messages) > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($messages as $message): ?>
                            <div class="list-group-item message-item <?= !$message['est_lu'] ? 'message-unread' : '' ?>">
                                <div class="d-flex align-items-start">
                                    <div class="message-avatar me-3">
                                        <?= strtoupper(substr($message['expediteur_nom'], 0, 1)) ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between">
                                            <h6 class="mb-1"><?= htmlspecialchars($message['expediteur_nom']) ?></h6>
                                            <small class="text-muted"><?= date('d/m/Y H:i', strtotime($message['date_envoi'])) ?></small>
                                        </div>
                                        <p class="mb-1"><?= htmlspecialchars($message['contenu']) ?></p>
                                        <?php if (!$message['est_lu']): ?>
                                            <span class="badge bg-danger">Nouveau</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-envelope-open display-4 text-muted"></i>
                        <h5 class="mt-3">Aucun message</h5>
                        <p class="text-muted">Vous n'avez reçu aucun message pour le moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'footer-client.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>