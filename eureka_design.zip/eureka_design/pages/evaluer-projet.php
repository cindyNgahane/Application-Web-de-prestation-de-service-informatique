<?php
session_start();
require_once 'admin/databases.php';

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'client') {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_projet = $_POST['id_projet'];
    $note = $_POST['note'];
    $commentaire = $_POST['commentaire'] ?? null;
    $id_client = $_SESSION['user_id'];

    try {
        // Vérifier que le projet appartient bien au client
        $stmt = $pdo->prepare("SELECT id_projet FROM projet WHERE id_projet = ? AND id_client = ?");
        $stmt->execute([$id_projet, $id_client]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception("Ce projet ne vous appartient pas ou n'existe pas");
        }

        // Insérer ou mettre à jour l'évaluation
        $stmt = $pdo->prepare("INSERT INTO evaluation (id_projet, id_client, note, commentaire) 
                              VALUES (?, ?, ?, ?)
                              ON DUPLICATE KEY UPDATE note = VALUES(note), commentaire = VALUES(commentaire)");
        $stmt->execute([$id_projet, $id_client, $note, $commentaire]);

        $_SESSION['message'] = "Merci pour votre évaluation !";
        $_SESSION['message_type'] = "success";
    } catch (Exception $e) {
        $_SESSION['message'] = "Erreur: " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
    }

    header("Location: projets.php");
    exit();
}