<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nos Services - EUREKA</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/service.css">
</head>
<body>
    
    <nav class="navbar">
        <div class="container">
            <a href="index.html" class="logo">
                <img src="images/logo.jpg" alt="EUREKA Logo">
                <span>EUREKA</span>
            </a>
            <div class="nav-links">
                <a href="index.php">Accueil</a>
                <a href="services.php" class="active">Services</a>
                <a href="#about">À propos</a>
                
                <div class="auth-buttons">
                    <a href="login.php" class="btn btn-outline">Connexion</a>
                    <a href="inscription.php" class="btn btn-primary">S'inscrire</a>
                </div>
            </div>
        </div>
    </nav>

    <main class="services-section">
        <div class="container">
            <h1 class="section-title">Nos services</h1>
            <p class="section-subtitle">Découvrez notre gamme complète de services pour booster votre présence en ligne</p>
            
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-globe"></i>
                    </div>
                    <h3>Services Web</h3>
                    <ul class="service-features">
                        <li>Création de sites internet</li>
                        <li>Refonte de site web</li>
                        <li>Référencement naturel (SEO)</li>
                        <li>Référencement Payant (SEA)</li>
                        <li>Social Ads</li>
                    </ul>
                    <a href="idee.php" class="btn btn-outline">En savoir plus</a>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <h3>Services de communication</h3>
                    <ul class="service-features">
                        <li>Conseil et stratégie</li>
                        <li>Création graphique et design</li>
                        <li>Publicité et médias</li>
                        <li>Supports imprimés</li>
                        <li>Motion design</li>
                    </ul>
                    <a href="idee.php" class="btn btn-outline">En savoir plus</a>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <h3>Motion et vidéo</h3>
                    <ul class="service-features">
                        <li>Rédaction de scénarios</li>
                        <li>Design et animation graphique</li>
                        <li>Montage vidéo</li>
                        <li>Diffusion stratégique</li>
                    </ul>
                    <a href="idee.php" class="btn btn-outline">En savoir plus</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <h3>Impression et Serigraphie</h3>
                    <ul class="service-features">
                        <li>Impression Laser(carte de voeux, mariage,visite etc)</li>
                        <li>Impression des :plos,tee-shirts,casquettes etc</li>
                        <li>Rool-up</li>
                        
                    </ul>
                    <a href="idee.php" class="btn btn-outline">En savoir plus</a>
                </div>
        </div>
        </div>
    </main>
    </section>
         <section class="about">
            <h1 class="title">Dernières formations</h1>
            <div class="flex flex2">
         
                <div class="sidebar">
                    <button class="active" data-target="visuel1">Community manager</button>
                    <button data-target="visuel2">Développement web</button>
                    <button data-target="visuel3">Infographie</button>
                    <button data-target="visuel4">Développement d'application mobile</button>
                    <button data-target="visuel5">Marketing Digital</button>
                    <button data-target="visuel6">Photoshop</button>
                    <button data-target="visuel7">TCF - TEF</button>
                </div>
          
                <div class="content ctnt">
                    <img id="visuel1" class="visuel active" src="images/adobe.jpg">
                    <img id="visuel2" class="visuel" src="images/appli_mobile" alt="IA">
                    <img id="visuel3" class="visuel" src="images/adobe.jpg" alt="Design">
                    <img id="visuel4" class="visuel" src="images/formationdev.jpg" alt="Design">
                    <img id="visuel5" class="visuel" src="images/.jpg" alt="Design">
                    <img id="visuel6" class="visuel" src="images/.jpg" alt="Design">
                    <img id="visuel7" class="visuel" src="images/.jpg" alt="Design">
                </div>
             </div>
         </section>
     <!-- Contact Section -->
    <section class="contact" id="contact">
        <div class="container">
            <h2 class="section-title">Contactez-nous</h2>
            <p class="section-subtitle">Nous sommes à votre écoute pour discuter de votre projet</p>
            
            <div class="contact-container">
                <div class="contact-info">
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h4>Adresse</h4>
                            <p>Douala</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-phone-alt"></i>
                        <div>
                            <h4>Téléphone</h4>
                            <p>+237 6 90 58 85 99</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h4>Email</h4>
                            <p>contact@eureka-design.com</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h4>Horaires</h4>
                            <p>Lundi-Vendredi: 9h-18h</p>
                        </div>
                    </div>
                </div>
                
                <div class="modal-overlay" id="contactModal">
                    <div class="modal-content">
                        <form class="contact-form" id="contactForm">
                            <div class="form-group">
                                <input type="text" id name="nom" placeholder="Votre nom" required>
                            </div>
                            <div class="form-group">
                                <input type="email" id="email" name="email" placeholder="Votre email" required>
                            </div>
                            <div class="form-group">
                                <input type="text" id="subject" name="sujet" placeholder="Sujet">
                            </div>
                            <div class="form-group">
                                <textarea id="message" rows="5" name="message" placeholder="Votre message" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Envoyer le message</button> 
                        </form>
                        <div id="success-message" style="display:none; color: #000">✅ Message envoyé avec succès !</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <a href="index.html" class="logo">
                        <img src="images/logo-eureka-white.png" alt="EUREKA Logo">
                        <span>EUREKA</span>
                    </a>
                    <p>Solutions digitales innovantes pour votre entreprise.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                
                <div class="footer-col">
                    <h4>Liens rapides</h4>
                    <ul>
                        <li><a href="index.html">Accueil</a></li>
                        <li><a href="services.html">Services</a></li>
                        <li><a href="#about">À propos</a></li>
                        <li><a href="#contact">Contact</a></li>
                        <li><a href="login.html">Connexion</a></li>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h4>Services</h4>
                    <ul>
                        <li><a href="services.html#graphic-design">Design Graphique</a></li>
                        <li><a href="services.html#web-dev">Développement Web</a></li>
                        <li><a href="services.html#digital-strategy">Stratégie Digitale</a></li>
                        <li><a href="services.html#branding">Branding</a></li>
                        <li><a href="services.html#seo">SEO & Marketing</a></li>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h4>Newsletter</h4>
                    <p>Abonnez-vous pour recevoir nos dernières actualités.</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Votre email" required>
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2023 EUREKA DESIGN & KONSULTING. Tous droits réservés.</p>
                <div class="footer-links">
                    <a href="#">Politique de confidentialité</a>
                    <a href="#">Conditions d'utilisation</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
    <script>
        (function(){
            emailjs.init("HNn2aUdGxxbVMZrJa"); // <-- À remplacer
        })();
        // Envoi du formulaire
        document.getElementById("contactForm").addEventListener("submit", function(event) {
            event.preventDefault();
            
            emailjs.sendForm('service_1smbb3j', 'template_bhdscff', this)
            .then(function(response) {
                document.getElementById("success-message").style.display = "block";
                setTimeout(() => closeForm(), 3000);
            }, function(error) {
                alert("Erreur lors de l'envoi. Veuillez réessayer.");
            });
        });
        </script>

     <script>
        //const buttons = document.querySelectorAll('.sidebar button');
        //const visuels = document.querySelectorAll('.visuel');
    
        buttons.forEach(button => {
          button.addEventListener('click', () => {
            // Supprimer toutes les classes actives
            buttons.forEach(btn => btn.classList.remove('active'));
            visuels.forEach(v => v.classList.remove('active'));
    
            // Ajouter la classe active à l'élément cliqué
            button.classList.add('active');
            const targetId = button.getAttribute('data-target');
            document.getElementById(targetId).classList.add('active');
          });
        });
      </script>
</body>
</html>