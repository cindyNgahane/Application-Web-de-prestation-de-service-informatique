<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Évaluations | EUREKA DESIGN & KONSULTING</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="dashboard">
    <!-- Dashboard Navigation -->
    <aside class="dashboard-sidebar">
        <!-- Same sidebar as projects.html -->
    </aside>

    <!-- Dashboard Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header">
            <!-- Same header as projects.html -->
        </header>
        
        <div class="dashboard-content">
            <div class="evaluations-header">
                <h2>Évaluations</h2>
                <p>Consultez et gérez les évaluations de vos projets</p>
            </div>
            
            <div class="evaluations-stats">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="stat-content">
                        <h3>4.8</h3>
                        <p>Note moyenne</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <h3>12</h3>
                        <p>Projets évalués</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-comment"></i>
                    </div>
                    <div class="stat-content">
                        <h3>9</h3>
                        <p>Commentaires</p>
                    </div>
                </div>
            </div>
            
            <div class="evaluations-tabs">
                <button class="tab-btn active" data-tab="pending">À évaluer <span class="badge">2</span></button>
                <button class="tab-btn" data-tab="completed">Évaluations complétées</button>
            </div>
            
            <div class="evaluations-content">
                <div class="tab-content active" id="pending">
                    <div class="evaluation-card">
                        <div class="evaluation-project">
                            <h3>Site Web Corporatif</h3>
                            <p>Projet terminé le 15/07/2023</p>
                        </div>
                        <div class="evaluation-form">
                            <div class="rating-input">
                                <span>Note:</span>
                                <div class="stars">
                                    <i class="fas fa-star" data-rating="1"></i>
                                    <i class="fas fa-star" data-rating="2"></i>
                                    <i class="fas fa-star" data-rating="3"></i>
                                    <i class="fas fa-star" data-rating="4"></i>
                                    <i class="fas fa-star" data-rating="5"></i>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="feedback">Commentaire (optionnel)</label>
                                <textarea id="feedback" rows="4" placeholder="Décrivez votre expérience avec ce projet..."></textarea>
                            </div>
                            <button class="btn btn-primary">Soumettre l'évaluation</button>
                        </div>
                    </div>
                    
                    <div class="evaluation-card">
                        <div class="evaluation-project">
                            <h3>Application Mobile</h3>
                            <p>Projet terminé le 30/09/2023</p>
                        </div>
                        <div class="evaluation-form">
                            <div class="rating-input">
                                <span>Note:</span>
                                <div class="stars">
                                    <i class="fas fa-star" data-rating="1"></i>
                                    <i class="fas fa-star" data-rating="2"></i>
                                    <i class="fas fa-star" data-rating="3"></i>
                                    <i class="fas fa-star" data-rating="4"></i>
                                    <i class="fas fa-star" data-rating="5"></i>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="feedback2">Commentaire (optionnel)</label>
                                <textarea id="feedback2" rows="4" placeholder="Décrivez votre expérience avec ce projet..."></textarea>
                            </div>
                            <button class="btn btn-primary">Soumettre l'évaluation</button>
                        </div>
                    </div>
                </div>
                
                <div class="tab-content" id="completed">
                    <div class="completed-evaluations">
                        <div class="completed-evaluation">
                            <div class="evaluation-header">
                                <h3>Identité Visuelle</h3>
                                <div class="rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <span>5.0</span>
                                </div>
                            </div>
                            <p class="evaluation-date">Évalué le 02/06/2023</p>
                            <p class="evaluation-comment">"Le travail réalisé sur notre identité visuelle a dépassé nos attentes. L'équipe a parfaitement capté l'esprit de notre marque et l'a traduit en une identité visuelle cohérente et moderne. Les livrables étaient complets et professionnels."</p>
                            <div class="evaluation-response">
                                <h4>Réponse de l'équipe:</h4>
                                <p>"Merci beaucoup pour votre retour positif ! Ce fut un plaisir de travailler sur votre projet et nous sommes ravis que le résultat vous plaise."</p>
                            </div>
                        </div>
                        
                        <div class="completed-evaluation">
                            <div class="evaluation-header">
                                <h3>Stratégie SEO</h3>
                                <div class="rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                    <span>4.0</span>
                                </div>
                            </div>
                            <p class="evaluation-date">Évalué le 20/05/2023</p>
                            <p class="evaluation-comment">"Bonne analyse SEO avec des recommandations pertinentes. Nous avons déjà vu une amélioration de notre positionnement après quelques semaines. Il aurait été utile d'avoir plus d'explications sur certaines recommandations techniques."</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="js/main.js"></script>
    <script src="js/evaluations.js"></script>
</body>
</html>