<?php
session_start();
require_once 'admin/databases.php';

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'client') {
    header('Location: ../login.php');
    exit();
}

$clientId = $_SESSION['user_id'];

// Récupération des projets du client
$stmt = $pdo->prepare("SELECT p.*, s.nom as service_nom, s.prix, 
                      (SELECT AVG(note) FROM evaluations WHERE id_projet = p.id_projet) as moyenne_notes,
                      (SELECT COUNT(*) FROM evaluations WHERE id_projet = p.id_projet) as nombre_avis
                      FROM projet p
                      JOIN service s ON p.id_service = s.id_service
                      WHERE p.id_client = ?
                      ORDER BY p.date_creation DESC");
$stmt->execute([$clientId]);
$projets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupération du nombre de messages non lus
$stmt = $pdo->prepare("SELECT COUNT(*) FROM message WHERE id_destinataire = ? AND est_lu = 0");
$stmt->execute([$clientId]);
$messagesNonLus = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Projets - Eureka Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
    <style>
        :root {
            --primary-color: #4a6fa5;
            --secondary-color: #166088;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--dark-color);
        }
        
        .navbar {
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .notification-badge {
            position: relative;
            cursor: pointer;
        }
        
        .notification-badge .badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: var(--danger-color);
            color: white;
            border-radius: 50%;
            padding: 4px 6px;
            font-size: 0.7rem;
            min-width: 18px;
            text-align: center;
        }
        
        .main-content {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            margin: 20px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .projet-card {
            transition: all 0.3s ease;
            border: none;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 25px;
            background: white;
        }
        
        .projet-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 20px;
            border-bottom: none;
        }
        
        .statut-badge {
            font-size: 0.8rem;
            padding: 0.35em 0.65em;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .card-body {
            padding: 25px;
        }
        
        .card-title {
            font-weight: 600;
            color: var(--secondary-color);
            margin-bottom: 15px;
        }
        
        .card-text {
            margin-bottom: 10px;
            color: #555;
        }
        
        .info-icon {
            color: var(--primary-color);
            margin-right: 8px;
            width: 20px;
            text-align: center;
        }
        
        .notes-section {
            background-color: #f8f9fa;
            border-left: 3px solid var(--primary-color);
            padding: 15px;
            margin: 15px 0;
            border-radius: 0 5px 5px 0;
        }
        
        .rating-container {
            margin: 15px 0;
        }
        
        .btn-action {
            border-radius: 50px;
            padding: 8px 20px;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .btn-details {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-details:hover {
            background-color: var(--secondary-color);
        }
        
        .btn-message {
            border: 1px solid var(--primary-color);
            color: var(--primary-color);
        }
        
        .btn-message:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .empty-state i {
            font-size: 3rem;
            color: var(--primary-color);
            margin-bottom: 20px;
        }
        
        .star-rating {
            color: var(--warning-color);
            font-size: 1.2rem;
        }
        
        .evaluation-form {
            display: none;
            margin-top: 15px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        
        .modal-header {
            background-color: var(--primary-color);
            color: white;
        }
        
        .modal-header .btn-close {
            filter: invert(1);
        }
        
        .message-form {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
        }
        
        .page-title {
            color: var(--primary-color);
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
        }
        
        .btn-primary {
            background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="bi bi-lightbulb-fill text-primary"></i>
                E.D.K
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    
                    <li class="nav-item">
                        <a class="nav-link active" href="projets.php">Mes Projets</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link notification-badge" href="messages.php">
                            <i class="bi bi-bell-fill"></i>
                            <?php if ($messagesNonLus > 0): ?>
                                <span class="badge"><?= $messagesNonLus ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i>
                            <?= htmlspecialchars($_SESSION['user_nom'] ?? 'utilisateurs') ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profil.php">Mon Profil</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Déconnexion</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <h1 class="fw-bold page-title">Mes Projets</h1>
            <a href="../nouveau-projet.php" class="btn btn-primary btn-lg">
                <i class="bi bi-plus-lg"></i> Nouveau projet
            </a>
        </div>

        <?php if (count($projets) > 0): ?>
            <div class="row">
                <?php foreach ($projets as $projet): ?>
                    <div class="col-lg-6">
                        <div class="card projet-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0"><?= htmlspecialchars($projet['service_nom']) ?></h5>
                                <span class="statut-badge badge bg-<?= 
                                    $projet['statut'] === 'en_attente' ? 'warning' : 
                                    ($projet['statut'] === 'en_cours' ? 'primary' : 
                                    ($projet['statut'] === 'termine' ? 'success' : 'secondary')) ?>">
                                    <?= ucfirst(str_replace('_', ' ', $projet['statut'])) ?>
                                </span>
                            </div>
                            
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="bi bi-calendar info-icon"></i>
                                    <span>Créé le <?= date('d/m/Y', strtotime($projet['date_creation'])) ?></span>
                                </div>
                                
                                <?php if ($projet['date_livraison_prevue']): ?>
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="bi bi-clock info-icon"></i>
                                        <span>Livraison prévue: <?= date('d/m/Y', strtotime($projet['date_livraison_prevue'])) ?></span>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="d-flex align-items-center mb-3">
                                    <i class="bi bi-currency-euro info-icon"></i>
                                    <span class="fw-bold">Prix: <?= number_format($projet['prix'], 2) ?> €</span>
                                </div>
                                
                                <?php if (!empty($projet['notes_supplementaires'])): ?>
                                    <div class="notes-section">
                                        <h6 class="fw-bold"><i class="bi bi-journal-text"></i> Notes:</h6>
                                        <p class="mb-0"><?= nl2br(htmlspecialchars($projet['notes_supplementaires'])) ?></p>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($projet['statut'] === 'termine'): ?>
                                    <div class="rating-container">
                                        <h6 class="fw-bold">Évaluation:</h6>
                                        <?php if ($projet['moyenne_notes']): ?>
                                            <div class="star-rating mb-2">
                                                <?php 
                                                $fullStars = floor($projet['moyenne_notes']);
                                                $halfStar = ($projet['moyenne_notes'] - $fullStars) >= 0.5;
                                                
                                                for ($i = 1; $i <= 5; $i++): 
                                                    if ($i <= $fullStars): ?>
                                                        <i class="bi bi-star-fill"></i>
                                                    <?php elseif ($halfStar && $i == $fullStars + 1): ?>
                                                        <i class="bi bi-star-half"></i>
                                                    <?php else: ?>
                                                        <i class="bi bi-star"></i>
                                                    <?php endif;
                                                endfor; ?>
                                                <span class="ms-2">(<?= $projet['nombre_avis'] ?> avis)</span>
                                            </div>
                                        <?php else: ?>
                                            <p class="text-muted">Pas encore évalué</p>
                                        <?php endif; ?>
                                        
                                        <button class="btn btn-sm btn-outline-primary toggle-evaluation" data-projet="<?= $projet['id_projet'] ?>">
                                            <i class="bi bi-pencil"></i> Donner votre avis
                                        </button>
                                        
                                        <div class="evaluation-form" id="evaluation-form-<?= $projet['id_projet'] ?>">
                                            <form action="evaluer-projet.php" method="post">
                                                <input type="hidden" name="id_projet" value="<?= $projet['id_projet'] ?>">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label">Note:</label>
                                                    <div class="rateyo" 
                                                         data-rateyo-rating="0"
                                                         data-rateyo-num-stars="5"
                                                         data-rateyo-score="3"></div>
                                                    <input type="hidden" name="note">
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="commentaire" class="form-label">Commentaire:</label>
                                                    <textarea class="form-control" name="commentaire" rows="3" placeholder="Votre expérience avec ce projet..."></textarea>
                                                </div>
                                                
                                                <button type="submit" class="btn btn-primary btn-sm">
                                                    <i class="bi bi-send"></i> Envoyer l'évaluation
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="d-flex justify-content-between pt-3">
                                    <a href="projet-details.php?id=<?= $projet['id_projet'] ?>" class="btn btn-action btn-details">
                                        <i class="bi bi-eye"></i> Détails
                                    </a>
                                    <button class="btn btn-action btn-message" data-bs-toggle="modal" data-bs-target="#messageModal" data-projet="<?= $projet['id_projet'] ?>" data-service="<?= htmlspecialchars($projet['service_nom']) ?>">
                                        <i class="bi bi-chat"></i> Contacter l'admin
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="bi bi-folder-x"></i>
                <h3 class="mb-3">Aucun projet trouvé</h3>
                <p class="text-muted mb-4">Vous n'avez pas encore de projets actifs. Commencez par créer votre premier projet.</p>
                <a href="../nouveau-projet.php" class="btn btn-primary btn-lg">
                    <i class="bi bi-plus-lg"></i> Créer un projet
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Modal de messagerie -->
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel">
                        <i class="bi bi-chat-dots"></i> Contacter l'administrateur
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="message-form">
                        <form id="messageForm" action="envoyer-message.php" method="post">
                            <input type="hidden" name="id_projet" id="modal_projet_id">
                            <input type="hidden" name="id_destinataire" value="1"> <!-- ID de l'administrateur -->
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="bi bi-info-circle"></i> Projet concerné:
                                </label>
                                <p class="text-muted" id="modal_service_nom"></p>
                            </div>
                            
                            <div class="mb-3">
                                <label for="sujet" class="form-label fw-bold">
                                    <i class="bi bi-tag"></i> Sujet:
                                </label>
                                <select class="form-select" name="sujet" id="sujet" required>
                                    <option value="">Sélectionnez un sujet</option>
                                    <option value="Question générale">Question générale</option>
                                    <option value="Problème technique">Problème technique</option>
                                    <option value="Modification du projet">Modification du projet</option>
                                    <option value="Délai de livraison">Délai de livraison</option>
                                    <option value="Facturation">Facturation</option>
                                    <option value="Autre">Autre</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="message" class="form-label fw-bold">
                                    <i class="bi bi-chat-text"></i> Message:
                                </label>
                                <textarea class="form-control" name="contenu" id="message" rows="6" placeholder="Décrivez votre demande ou question concernant ce projet..." required></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="priorite" class="form-label fw-bold">
                                    <i class="bi bi-exclamation-triangle"></i> Priorité:
                                </label>
                                <select class="form-select" name="priorite" id="priorite">
                                    <option value="normale">Normale</option>
                                    <option value="haute">Haute</option>
                                    <option value="urgente">Urgente</option>
                                </select>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                    <i class="bi bi-x-circle"></i> Annuler
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-send"></i> Envoyer le message
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Initialisation du plugin RateYo
            $(".rateyo").rateYo({
                starWidth: "20px",
                ratedFill: "#ffc107",
                normalFill: "#e9ecef",
                spacing: "5px",
                onSet: function(rating, rateYoInstance) {
                    $(this).next('input[name="note"]').val(rating);
                }
            });
            
            // Toggle evaluation form
            $(".toggle-evaluation").click(function() {
                const projetId = $(this).data('projet');
                $("#evaluation-form-" + projetId).slideToggle();
            });
            
            // Gestion du modal de messagerie
            $('#messageModal').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget);
                var projetId = button.data('projet');
                var serviceName = button.data('service');
                
                var modal = $(this);
                modal.find('#modal_projet_id').val(projetId);
                modal.find('#modal_service_nom').text(serviceName);
            });
            
            // Soumission du formulaire de message
            $('#messageForm').on('submit', function(e) {
                e.preventDefault();
                
                var formData = $(this).serialize();
                
                $.ajax({
                    url: 'envoyer-message.php',
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#messageModal').modal('hide');
                            
                            // Afficher un message de succès
                            $('<div class="alert alert-success alert-dismissible fade show" role="alert">' +
                              '<i class="bi bi-check-circle"></i> ' + response.message +
                              '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                              '</div>').insertAfter('.main-content > .d-flex:first-child');
                            
                            // Réinitialiser le formulaire
                            $('#messageForm')[0].reset();
                        } else {
                            alert('Erreur: ' + response.message);
                        }
                    },
                    error: function() {
                        alert('Erreur lors de l\'envoi du message.');
                    }
                });
            });
        });
    </script>
</body>
</html>