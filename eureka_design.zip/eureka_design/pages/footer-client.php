<?php
// footer-client.php
?>
    <footer class="bg-light mt-5 py-4">
        <div class="container text-center">
            <p class="mb-0">Eureka Design &copy; <?= date('Y') ?> - Tous droits réservés</p>
            <p class="text-muted small mb-0">Version 1.0.0</p>
        </div>
    </footer>
</body>
</html>