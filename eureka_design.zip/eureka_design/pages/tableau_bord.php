<?php
session_start();
require_once '../databases.php';

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) ){
    header('Location: ../login.php');
    exit();
}

// Vérification que c'est bien un client
if ($_SESSION['user_type'] !== 'client') {
    header('Location: ../index.php');
    exit();
}

// Récupération des informations du client
$clientId = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM utilisateur WHERE id_utilisateur = ?");
$stmt->execute([$clientId]);
$client = $stmt->fetch(PDO::FETCH_ASSOC);

// Récupération des projets du client
$stmtProjets = $pdo->prepare("SELECT p.*, s.nom as service_nom 
                             FROM projet p
                             JOIN service s ON p.id_service = s.id_service
                             WHERE p.id_client = ?
                             ORDER BY p.date_creation DESC
                             LIMIT 3");
$stmtProjets->execute([$clientId]);
$projets = $stmtProjets->fetchAll(PDO::FETCH_ASSOC);

// Récupération des messages récents
$stmtMessages = $pdo->prepare("SELECT m.*, u.nom as expediteur_nom 
                              FROM message m
                              JOIN utilisateur u ON m.id_expediteur = u.id_utilisateur
                              WHERE m.id_destinataire = ?
                              ORDER BY m.date_envoi DESC
                              LIMIT 5");
$stmtMessages->execute([$clientId]);
$messages = $stmtMessages->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace Client - Eureka Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .profile-pic {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            border: 5px solid #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .card-hover:hover {
            transform: translateY(-5px);
            transition: transform 0.3s ease;
        }
    </style>
</head>
<body>
    <?php include 'includes/header-client.php'; ?>

    <div class="container py-5">
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <img src="../uploads/profiles/<?= htmlspecialchars($client['photo_profil']) ?>" 
                             class="profile-pic mb-3" 
                             alt="Photo de profil">
                        <h4><?= htmlspecialchars($client['prenom'] . ' ' . $client['nom']) ?></h4>
                        <p class="text-muted">Client depuis <?= date('d/m/Y', strtotime($client['date_inscription'])) ?></p>
                        <div class="d-grid gap-2">
                            <a href="mon-compte.php" class="btn btn-outline-primary">Mon compte</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card card-hover h-100">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <i class="bi bi-folder"></i> Mes projets
                                </h5>
                                <?php if (count($projets) > 0): ?>
                                    <ul class="list-group list-group-flush">
                                        <?php foreach ($projets as $projet): ?>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                <?= htmlspecialchars($projet['service_nom']) ?>
                                                <span class="badge bg-<?= 
                                                    $projet['statut'] === 'en_attente' ? 'warning' : 
                                                    ($projet['statut'] === 'en_cours' ? 'primary' : 
                                                    ($projet['statut'] === 'termine' ? 'success' : 'secondary')) ?>">
                                                    <?= ucfirst(str_replace('_', ' ', $projet['statut'])) ?>
                                                </span>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted">Aucun projet pour le moment</p>
                                <?php endif; ?>
                                <a href="projets.php" class="btn btn-sm btn-primary mt-3">Voir tous</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 mb-4">
                        <div class="card card-hover h-100">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <i class="bi bi-envelope"></i> Messages récents
                                </h5>
                                <?php if (count($messages) > 0): ?>
                                    <ul class="list-group list-group-flush">
                                        <?php foreach ($messages as $message): ?>
                                            <li class="list-group-item">
                                                <strong><?= htmlspecialchars($message['expediteur_nom']) ?></strong>
                                                <p class="mb-1 text-truncate"><?= htmlspecialchars(substr($message['contenu'], 0, 50)) ?>...</p>
                                                <small class="text-muted"><?= date('d/m/Y H:i', strtotime($message['date_envoi'])) ?></small>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted">Aucun message</p>
                                <?php endif; ?>
                                <a href="messages.php" class="btn btn-sm btn-primary mt-3">Voir tous</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer-client.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>