<?php
require_once 'databases.php';

echo "<h2>🔍 Débogage des Requêtes Dashboard</h2>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .success { color: green; background: #f0f8f0; padding: 10px; margin: 10px 0; border-radius: 5px; }
    .error { color: red; background: #fff0f0; padding: 10px; margin: 10px 0; border-radius: 5px; }
    .info { color: blue; background: #f0f0ff; padding: 10px; margin: 10px 0; border-radius: 5px; }
    .query { background: #f5f5f5; padding: 10px; margin: 10px 0; border-radius: 5px; font-family: monospace; }
</style>";

try {
    echo "<div class='success'>✅ Connexion à la base de données réussie!</div>";
    
    // 1. Vérifier la structure des tables
    echo "<h3>📋 Structure des Tables</h3>";
    
    $tables = ['utilisateur', 'projet', 'service', 'evaluation', 'historique_achat', 'message'];
    
    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("DESCRIBE $table");
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo "<div class='info'><strong>Table '$table':</strong> " . count($columns) . " colonnes trouvées</div>";
        } catch (Exception $e) {
            echo "<div class='error'>❌ Table '$table' n'existe pas: " . $e->getMessage() . "</div>";
        }
    }
    
    // 2. Vérifier le contenu des tables
    echo "<h3>📊 Contenu des Tables</h3>";
    
    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM $table");
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
            echo "<div class='info'><strong>$table:</strong> $count enregistrements</div>";
        } catch (Exception $e) {
            echo "<div class='error'>❌ Erreur pour $table: " . $e->getMessage() . "</div>";
        }
    }
    
    // 3. Tester chaque requête individuellement
    echo "<h3>🔍 Test des Requêtes Spécifiques</h3>";
    
    // Test 1: Clients
    echo "<h4>1. Requête Clients</h4>";
    $query1 = "SELECT COUNT(*) as total FROM utilisateur WHERE type = 'client' AND statut = 'actif'";
    echo "<div class='query'>$query1</div>";
    try {
        $stmt = $pdo->query($query1);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='success'>✅ Résultat: " . $result['total'] . " clients</div>";
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
    // Test alternative pour clients
    echo "<h4>1b. Test alternatif - Tous les clients</h4>";
    $query1b = "SELECT COUNT(*) as total FROM utilisateur WHERE type = 'client'";
    echo "<div class='query'>$query1b</div>";
    try {
        $stmt = $pdo->query($query1b);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='success'>✅ Résultat: " . $result['total'] . " clients (tous statuts)</div>";
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
    // Vérifier les valeurs dans la colonne type
    echo "<h4>1c. Vérification des types d'utilisateurs</h4>";
    $query1c = "SELECT type, COUNT(*) as count FROM utilisateur GROUP BY type";
    echo "<div class='query'>$query1c</div>";
    try {
        $stmt = $pdo->query($query1c);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($results as $row) {
            echo "<div class='info'>Type: '{$row['type']}' - Count: {$row['count']}</div>";
        }
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
    // Vérifier les valeurs dans la colonne statut
    echo "<h4>1d. Vérification des statuts d'utilisateurs</h4>";
    $query1d = "SELECT statut, COUNT(*) as count FROM utilisateur GROUP BY statut";
    echo "<div class='query'>$query1d</div>";
    try {
        $stmt = $pdo->query($query1d);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($results as $row) {
            echo "<div class='info'>Statut: '{$row['statut']}' - Count: {$row['count']}</div>";
        }
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
    // Test 2: Projets
    echo "<h4>2. Requête Projets</h4>";
    $query2 = "SELECT COUNT(*) as total FROM projet";
    echo "<div class='query'>$query2</div>";
    try {
        $stmt = $pdo->query($query2);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='success'>✅ Résultat: " . $result['total'] . " projets</div>";
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
    // Test 3: Chiffre d'affaires
    echo "<h4>3. Requête Chiffre d'Affaires</h4>";
    $query3 = "SELECT COALESCE(SUM(montant), 0) as total FROM historique_achat";
    echo "<div class='query'>$query3</div>";
    try {
        $stmt = $pdo->query($query3);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='success'>✅ Résultat: " . $result['total'] . " €</div>";
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
    // Test 4: Satisfaction
    echo "<h4>4. Requête Satisfaction</h4>";
    $query4 = "SELECT COALESCE(AVG(note), 0) as moyenne FROM evaluation";
    echo "<div class='query'>$query4</div>";
    try {
        $stmt = $pdo->query($query4);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='success'>✅ Résultat: " . round($result['moyenne'], 1) . "/5</div>";
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
    // Test 5: Messages
    echo "<h4>5. Requête Messages</h4>";
    $query5 = "SELECT COUNT(*) as total FROM message WHERE est_lu = 0";
    echo "<div class='query'>$query5</div>";
    try {
        $stmt = $pdo->query($query5);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='success'>✅ Résultat: " . $result['total'] . " messages non lus</div>";
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
    // Test 6: Projets par statut (qui fonctionne)
    echo "<h4>6. Requête Projets par Statut (qui fonctionne)</h4>";
    $query6 = "SELECT statut, COUNT(*) as nombre FROM projet GROUP BY statut";
    echo "<div class='query'>$query6</div>";
    try {
        $stmt = $pdo->query($query6);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($results as $row) {
            echo "<div class='success'>✅ Statut: '{$row['statut']}' - Nombre: {$row['nombre']}</div>";
        }
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
    // Afficher quelques exemples de données
    echo "<h3>📝 Exemples de Données</h3>";
    
    echo "<h4>Utilisateurs (5 premiers):</h4>";
    try {
        $stmt = $pdo->query("SELECT id_utilisateur, nom, email, type, statut FROM utilisateur LIMIT 5");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Nom</th><th>Email</th><th>Type</th><th>Statut</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>{$user['id_utilisateur']}</td>";
            echo "<td>{$user['nom']}</td>";
            echo "<td>{$user['email']}</td>";
            echo "<td><strong>{$user['type']}</strong></td>";
            echo "<td><strong>{$user['statut']}</strong></td>";
            echo "</tr>";
        }
        echo "</table>";
    } catch (Exception $e) {
        echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='error'>❌ Erreur de connexion: " . $e->getMessage() . "</div>";
}
?>
