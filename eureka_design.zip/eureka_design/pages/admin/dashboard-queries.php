<?php
require_once 'databases.php'; // Votre fichier existant

class DashboardQueries {
    private $pdo;
    
    public function __construct() {
        global $pdo; // Utilise votre variable $pdo globale
        $this->pdo = $pdo;
    }
    
    public function getDashboardMetrics() {
        try {
            // Nombre total de clients
            $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM utilisateur WHERE type = 'client' AND statut = 'actif'");
            $totalClients = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
            
            // Nombre total de projets
            $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM projet");
            $totalProjets = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
            
            // Chiffre d'affaires total
            $stmt = $this->pdo->query("SELECT COALESCE(SUM(montant), 0) as total FROM historique_achat");
            $chiffreAffaires = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
            
            // Satisfaction moyenne
            $stmt = $this->pdo->query("SELECT COALESCE(AVG(note), 0) as moyenne FROM evaluations");
            $satisfactionMoyenne = round($stmt->fetch(PDO::FETCH_ASSOC)['moyenne'], 1);
            
            // Messages non lus
            $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM message WHERE est_lu = 0");
            $messagesNonLus = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
            
            return [
                'totalClients' => (int)$totalClients,
                'totalProjets' => (int)$totalProjets,
                'chiffreAffaires' => (float)$chiffreAffaires,
                'satisfactionMoyenne' => (float)$satisfactionMoyenne,
                'messagesNonLus' => (int)$messagesNonLus
            ];
        } catch (Exception $e) {
            error_log("Erreur getDashboardMetrics: " . $e->getMessage());
            return [
                'totalClients' => 0,
                'totalProjets' => 0,
                'chiffreAffaires' => 0,
                'satisfactionMoyenne' => 0,
                'messagesNonLus' => 0
            ];
        }
    }
    
    public function getProjetsParStatut() {
        try {
            $stmt = $this->pdo->query("
                SELECT 
                    statut,
                    COUNT(*) as nombre
                FROM projet 
                GROUP BY statut
            ");
            
            $projetsParStatut = [
                'en_attente' => 0,
                'en_cours' => 0,
                'termine' => 0,
                'livre' => 0
            ];
            
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $projetsParStatut[$row['statut']] = (int)$row['nombre'];
            }
            
            return $projetsParStatut;
        } catch (Exception $e) {
            error_log("Erreur getProjetsParStatut: " . $e->getMessage());
            return [
                'en_attente' => 0,
                'en_cours' => 0,
                'termine' => 0,
                'livre' => 0
            ];
        }
    }
    
    public function getServicesPopulaires() {
        try {
            $stmt = $this->pdo->query("
                SELECT 
                    s.nom,
                    COUNT(ha.id_achat) as commandes,
                    COALESCE(SUM(ha.montant), 0) as revenus
                FROM service s
                LEFT JOIN historique_achat ha ON s.id_service = ha.id_service
                WHERE s.est_actif = 1
                GROUP BY s.id_service, s.nom
                ORDER BY commandes DESC, revenus DESC
                LIMIT 5
            ");
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Erreur getServicesPopulaires: " . $e->getMessage());
            return [];
        }
    }
    
    public function getEvaluationsRecentes() {
        try {
            $stmt = $this->pdo->query("
                SELECT 
                    u.nom as client,
                    s.nom as projet_service,
                    e.note,
                    e.commentaire,
                    e.date_evaluation
                FROM evaluations e
                JOIN utilisateur u ON e.id_client = u.id_utilisateur
                JOIN projet p ON e.id_projet = p.id_projet
                JOIN service s ON p.id_service = s.id_service
                ORDER BY e.date_evaluation DESC
                LIMIT 10
            ");
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Erreur getEvaluationsRecentes: " . $e->getMessage());
            return [];
        }
    }
    
    public function getEvolutionMensuelle() {
        try {
            // Projets par mois
            $stmt = $this->pdo->query("
                SELECT 
                    DATE_FORMAT(date_creation, '%Y-%m') as mois,
                    COUNT(*) as projets
                FROM projet 
                WHERE date_creation >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                GROUP BY DATE_FORMAT(date_creation, '%Y-%m')
                ORDER BY mois
            ");
            $projetsParMois = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Revenus par mois
            $stmt = $this->pdo->query("
                SELECT 
                    DATE_FORMAT(date_achat, '%Y-%m') as mois,
                    SUM(montant) as revenus
                FROM historique_achat 
                WHERE date_achat >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                GROUP BY DATE_FORMAT(date_achat, '%Y-%m')
                ORDER BY mois
            ");
            $revenusParMois = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Combiner les résultats
            $evolution = [];
            $revenusMap = [];
            
            foreach ($revenusParMois as $row) {
                $revenusMap[$row['mois']] = (float)$row['revenus'];
            }
            
            foreach ($projetsParMois as $row) {
                $evolution[] = [
                    'mois' => $row['mois'],
                    'projets' => (int)$row['projets'],
                    'revenus' => $revenusMap[$row['mois']] ?? 0
                ];
            }
            
            return $evolution;
        } catch (Exception $e) {
            error_log("Erreur getEvolutionMensuelle: " . $e->getMessage());
            return [];
        }
    }
    
    public function calculatePredictions() {
        try {
            // Projets ce mois
            $stmt = $this->pdo->query("
                SELECT COUNT(*) as projets_ce_mois
                FROM projet 
                WHERE MONTH(date_creation) = MONTH(CURDATE()) 
                AND YEAR(date_creation) = YEAR(CURDATE())
            ");
            $projetsCeMois = $stmt->fetch(PDO::FETCH_ASSOC)['projets_ce_mois'];
            
            // Projets mois précédent
            $stmt = $this->pdo->query("
                SELECT COUNT(*) as projets_mois_precedent
                FROM projet 
                WHERE MONTH(date_creation) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
                AND YEAR(date_creation) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
            ");
            $projetsMoisPrecedent = $stmt->fetch(PDO::FETCH_ASSOC)['projets_mois_precedent'];
            
            // Calcul de la tendance
            $tendanceProjets = $projetsMoisPrecedent > 0 ? $projetsCeMois / $projetsMoisPrecedent : 1;
            $projetsMoisProchain = max(1, round($projetsCeMois * $tendanceProjets));
            
            // Revenus ce mois
            $stmt = $this->pdo->query("
                SELECT COALESCE(SUM(montant), 0) as revenus_ce_mois
                FROM historique_achat 
                WHERE MONTH(date_achat) = MONTH(CURDATE()) 
                AND YEAR(date_achat) = YEAR(CURDATE())
            ");
            $revenusCeMois = $stmt->fetch(PDO::FETCH_ASSOC)['revenus_ce_mois'];
            
            // Revenus mois précédent
            $stmt = $this->pdo->query("
                SELECT COALESCE(SUM(montant), 0) as revenus_mois_precedent
                FROM historique_achat 
                WHERE MONTH(date_achat) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
                AND YEAR(date_achat) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
            ");
            $revenusMoisPrecedent = $stmt->fetch(PDO::FETCH_ASSOC)['revenus_mois_precedent'];
            
            $tendanceRevenus = $revenusMoisPrecedent > 0 ? $revenusCeMois / $revenusMoisPrecedent : 1;
            $revenusPrevus = max(0, round($revenusCeMois * $tendanceRevenus));
            
            // Satisfaction prévue
            $stmt = $this->pdo->query("
                SELECT AVG(note) as satisfaction_recente
                FROM evaluation 
                WHERE date_evaluation >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            ");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $satisfactionRecente = $result['satisfaction_recente'] ?? 4.0;
            $tauxSatisfactionPrevu = min(5.0, $satisfactionRecente * 1.02);
            
            // Nouveaux clients potentiels
            $stmt = $this->pdo->query("
                SELECT COUNT(*) as nouveaux_clients
                FROM utilisateur 
                WHERE type = 'client' 
                AND date_inscription >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            ");
            $nouveauxClientsCeMois = $stmt->fetch(PDO::FETCH_ASSOC)['nouveaux_clients'];
            $clientsPotentiels = max(1, round($nouveauxClientsCeMois * 1.15));
            
            return [
                'projetsMoisProchain' => (int)$projetsMoisProchain,
                'revenusPrevus' => (float)$revenusPrevus,
                'tauxSatisfactionPrevu' => round($tauxSatisfactionPrevu, 1),
                'clientsPotentiels' => (int)$clientsPotentiels
            ];
        } catch (Exception $e) {
            error_log("Erreur calculatePredictions: " . $e->getMessage());
            return [
                'projetsMoisProchain' => 1,
                'revenusPrevus' => 0,
                'tauxSatisfactionPrevu' => 4.0,
                'clientsPotentiels' => 1
            ];
        }
    }
    
    public function getBusinessInsights() {
        try {
            // Évolution satisfaction
            $stmt = $this->pdo->query("
                SELECT 
                    AVG(CASE WHEN date_evaluation >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN note END) as satisfaction_recente,
                    AVG(CASE WHEN date_evaluation >= DATE_SUB(CURDATE(), INTERVAL 60 DAY) 
                             AND date_evaluation < DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN note END) as satisfaction_precedente
                FROM evaluation
            ");
            $satisfactionData = $stmt->fetch(PDO::FETCH_ASSOC);
            $evolutionSatisfaction = ($satisfactionData['satisfaction_recente'] ?? 0) - ($satisfactionData['satisfaction_precedente'] ?? 0);
            
            // Service le plus rentable
            $stmt = $this->pdo->query("
                SELECT s.nom, SUM(ha.montant) as revenus_total
                FROM service s
                JOIN historique_achat ha ON s.id_service = ha.id_service
                GROUP BY s.id_service, s.nom
                ORDER BY revenus_total DESC
                LIMIT 1
            ");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $servicePlusRentable = $result['nom'] ?? 'Aucun';
            
            // Projets en retard
            $stmt = $this->pdo->query("
                SELECT COUNT(*) as projets_en_retard
                FROM projet 
                WHERE statut IN ('en_attente', 'en_cours') 
                AND date_livraison_prevue < CURDATE()
            ");
            $projetsEnRetard = $stmt->fetch(PDO::FETCH_ASSOC)['projets_en_retard'];
            
            return [
                'evolutionSatisfaction' => round($evolutionSatisfaction, 2),
                'servicePlusRentable' => $servicePlusRentable,
                'projetsEnRetard' => (int)$projetsEnRetard
            ];
        } catch (Exception $e) {
            error_log("Erreur getBusinessInsights: " . $e->getMessage());
            return [
                'evolutionSatisfaction' => 0,
                'servicePlusRentable' => 'Aucun',
                'projetsEnRetard' => 0
            ];
        }
    }
    
    // Nouvelle méthode pour obtenir la distribution réelle des notes
    public function getDistributionNotes() {
        try {
            $stmt = $this->pdo->query("
                SELECT 
                    note,
                    COUNT(*) as nombre
                FROM evaluations 
                GROUP BY note
                ORDER BY note
            ");
            
            $distribution = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $distribution[$row['note']] = (int)$row['nombre'];
            }
            
            return array_values($distribution); // Retourne [nb_1_etoile, nb_2_etoiles, ...]
        } catch (Exception $e) {
            error_log("Erreur getDistributionNotes: " . $e->getMessage());
            return [0, 0, 0, 0, 0];
        }
    }

    // Nouvelle méthode pour l'évolution réelle avec plus de données
    public function getEvolutionComplete() {
        try {
            // Projets par mois (12 derniers mois)
            $stmt = $this->pdo->query("
                SELECT 
                    DATE_FORMAT(date_creation, '%Y-%m') as mois,
                    COUNT(*) as projets
                FROM projet 
                WHERE date_creation >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(date_creation, '%Y-%m')
                ORDER BY mois
            ");
            $projetsParMois = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Revenus par mois (12 derniers mois)
            $stmt = $this->pdo->query("
                SELECT 
                    DATE_FORMAT(date_achat, '%Y-%m') as mois,
                    SUM(montant) as revenus
                FROM historique_achat 
                WHERE date_achat >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(date_achat, '%Y-%m')
                ORDER BY mois
            ");
            $revenusParMois = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Créer un tableau complet des 12 derniers mois
            $evolution = [];
            $revenusMap = [];
            
            // Mapper les revenus
            foreach ($revenusParMois as $row) {
                $revenusMap[$row['mois']] = (float)$row['revenus'];
            }
            
            // Créer la structure complète
            for ($i = 11; $i >= 0; $i--) {
                $date = date('Y-m', strtotime("-$i months"));
                $projets = 0;
                
                // Chercher les projets pour ce mois
                foreach ($projetsParMois as $projet) {
                    if ($projet['mois'] === $date) {
                        $projets = (int)$projet['projets'];
                        break;
                    }
                }
                
                $evolution[] = [
                    'mois' => $date,
                    'projets' => $projets,
                    'revenus' => $revenusMap[$date] ?? 0
                ];
            }
            
            return $evolution;
        } catch (Exception $e) {
            error_log("Erreur getEvolutionComplete: " . $e->getMessage());
            return [];
        }
    }

    // Nouvelle méthode pour les statistiques de services réelles
    public function getServicesStatistiques() {
        try {
            $stmt = $this->pdo->query("
                SELECT 
                    s.nom,
                    COUNT(p.id_projet) as projets_total,
                    COUNT(CASE WHEN p.statut = 'livre' THEN 1 END) as projets_livres,
                COALESCE(AVG(e.note), 0) as satisfaction_moyenne,
                    COALESCE(SUM(ha.montant), s.prix * COUNT(p.id_projet)) as revenus_total
                FROM service s
                LEFT JOIN projet p ON s.id_service = p.id_service
                LEFT JOIN evaluations e ON p.id_projet = e.id_projet
                LEFT JOIN historique_achat ha ON s.id_service = ha.id_service
                WHERE s.est_actif = 1
                GROUP BY s.id_service, s.nom, s.prix
                ORDER BY projets_total DESC, revenus_total DESC
                LIMIT 10
            ");
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Erreur getServicesStatistiques: " . $e->getMessage());
            return [];
        }
    }

    // Mettre à jour getAllDashboardData pour inclure les nouvelles données
    public function getAllDashboardData() {
        return [
            'metrics' => $this->getDashboardMetrics(),
            'projetsParStatut' => $this->getProjetsParStatut(),
            'servicesPopulaires' => $this->getServicesPopulaires(),
            'evaluationsRecentes' => $this->getEvaluationsRecentes(),
            'evolutionMensuelle' => $this->getEvolutionComplete(), // Nouvelle méthode
            'predictions' => $this->calculatePredictions(),
            'insights' => $this->getBusinessInsights(),
            'distributionNotes' => $this->getDistributionNotes(), // Nouvelle donnée
            'servicesStatistiques' => $this->getServicesStatistiques() // Nouvelle donnée
        ];
    }
}
?>
