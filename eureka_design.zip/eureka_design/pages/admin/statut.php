<?php
session_start();

// Connexion à la base de données
$host = 'localhost';
$dbname = 'eureka_design_db';
$username = 'root'; // À remplacer par vos identifiants
$password = '';     // À remplacer par votre mot de passe

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Récupérer la liste des clients
$clientsQuery = $pdo->query("SELECT id_utilisateur, nom, email FROM utilisateur WHERE type = 'client'");
$clients = $clientsQuery->fetchAll(PDO::FETCH_ASSOC);

// Si un formulaire est soumis pour mettre à jour un projet
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['project_id'], $_POST['progress'])) {
    $projectId = $_POST['project_id'];
    $progress = $_POST['progress'];
    
    // Déterminer le statut en fonction de la progression
    if ($progress == 0) {
        $status = 'en_attente';
    } elseif ($progress > 0 && $progress < 80) {
        $status = 'en_cours';
    } else {
        $status = 'termine';
    }
    
    // Mettre à jour le projet dans la base de données
    $updateQuery = $pdo->prepare("UPDATE projet SET statut = ? WHERE id_projet = ?");
    $updateQuery->execute([$status, $projectId]);
    
    // Message de succès
    $_SESSION['success_message'] = "Le statut du projet a été mis à jour avec succès!";
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration des Projets</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f9fafb;
            min-height: 100vh;
            padding: 24px;
        }

        .container {
            max-width: 1280px;
            margin: 0 auto;
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .back-button {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: white;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            color: #374151;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.2s;
        }

        .back-button:hover {
            background-color: #f3f4f6;
        }

        .title-section h1 {
            font-size: 30px;
            font-weight: 700;
            color: #111827;
            margin-bottom: 4px;
        }

        .title-section p {
            color: #6b7280;
            font-size: 16px;
        }

        .stats {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #6b7280;
            font-size: 14px;
        }

        .stats-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .main-content {
            max-width: 672px;
            margin: 0 auto;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .card-header {
            padding: 24px 24px 0 24px;
            border-bottom: 1px solid #f3f4f6;
            margin-bottom: 24px;
        }

        .card-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 18px;
            font-weight: 600;
            color: #111827;
            margin-bottom: 8px;
        }

        .card-description {
            color: #6b7280;
            font-size: 14px;
        }

        .card-content {
            padding: 0 24px 24px 24px;
        }

        .form-group {
            margin-bottom: 24px;
        }

        .label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #374151;
            margin-bottom: 8px;
        }

        .select {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            background: white;
            font-size: 14px;
            color: #111827;
        }

        .select:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .select:disabled {
            background-color: #f9fafb;
            color: #9ca3af;
            cursor: not-allowed;
        }

        .project-details {
            padding: 16px;
            background-color: #f9fafb;
            border-radius: 8px;
            margin-bottom: 24px;
        }

        .project-details h4 {
            font-weight: 500;
            color: #111827;
            margin-bottom: 4px;
        }

        .project-details p {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 8px;
        }

        .project-progress {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .project-progress span {
            font-size: 14px;
            color: #6b7280;
        }

        .badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
            border: 1px solid #d1d5db;
            background: white;
            color: #374151;
        }

        .slider-section {
            margin-bottom: 24px;
        }

        .slider-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
        }

        .progress-display {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .progress-value {
            font-size: 24px;
            font-weight: 700;
            color: #111827;
        }

        .status-badge {
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
            color: white;
        }

        .status-waiting { background-color: #6b7280; }
        .status-progress { background-color: #3b82f6; }
        .status-completed { background-color: #10b981; }

        .slider-container {
            position: relative;
            margin-bottom: 16px;
        }

        .slider {
            width: 100%;
            height: 8px;
            border-radius: 4px;
            background: #e5e7eb;
            outline: none;
            -webkit-appearance: none;
            appearance: none;
        }

        .slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #3b82f6;
            cursor: pointer;
            border: 2px solid white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .slider::-moz-range-thumb {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #3b82f6;
            cursor: pointer;
            border: 2px solid white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .slider:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .slider-labels {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #6b7280;
        }

        .save-button {
            width: 100%;
            padding: 12px 16px;
            background-color: #111827;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: background-color 0.2s;
        }

        .save-button:hover:not(:disabled) {
            background-color: #1f2937;
        }

        .save-button:disabled {
            background-color: #9ca3af;
            cursor: not-allowed;
        }

        .hidden {
            display: none;
        }

        .icon {
            width: 16px;
            height: 16px;
            fill: currentColor;
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 16px;
            }

            .header-left {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px;
            }

            .title-section h1 {
                font-size: 24px;
            }

            .stats {
                align-self: stretch;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- En-tête -->
        <div class="header">
            <div class="header-left">
                <a href="#" class="back-button">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="m12 19-7-7 7-7"/>
                        <path d="M19 12H5"/>
                    </svg>
                    Retour aux Projets
                </a>
                <div class="title-section">
                    <h1>Administration des Projets</h1>
                    <p>Gérez le statut d'avancement des projets clients</p>
                </div>
            </div>

        </div>

        <div class="main-content">
            <!-- Formulaire de modification -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                            <polyline points="17,21 17,13 7,13 7,21"/>
                            <polyline points="7,3 7,8 15,8"/>
                        </svg>
                        Modifier le Statut d'un Projet
                    </div>
                    <div class="card-description">Sélectionnez un client et un projet pour mettre à jour son avancement</div>
                </div>
                <div class="card-content">
                    
                   

                    <!-- Sélection du projet -->
                <div class="form-group">
    <label class="label" for="client-select">Client</label>
    <select id="client-select" class="select">
        <option value="">Choisir un client...</option>
        <?php foreach ($clients as $client): ?>
            <option value="<?= $client['id_utilisateur'] ?>">
                <?= htmlspecialchars($client['nom']) ?> (<?= htmlspecialchars($client['email']) ?>)
            </option>
        <?php endforeach; ?>
    </select>
</div>

<div class="form-group">
    <label class="label" for="project-select">Projet</label>
    <select id="project-select" class="select" disabled>
        <option value="">Sélectionnez d'abord un client</option>
    </select>
</div>

                    <!-- Détails du projet sélectionné -->
                    <div id="project-details" class="project-details hidden">
                        <h4 id="project-name"></h4>
                        <p id="project-description"></p>
                        <div class="project-progress">
                            <span>Progrès actuel:</span>
                            <span class="badge" id="current-progress">0%</span>
                        </div>
                    </div>

                    <!-- Slider de progression -->
                    <div class="slider-section">
                        <div class="slider-header">
                            <label class="label">Pourcentage d'avancement</label>
                            <div class="progress-display">
                                <span class="progress-value" id="progress-value">0%</span>
                                <span class="status-badge status-waiting" id="status-badge">En attente</span>
                            </div>
                        </div>
                        <div class="slider-container">
                            <input type="range" id="progress-slider" class="slider" min="0" max="100" step="5" value="0" disabled>
                        </div>
                        <div class="slider-labels">
                            <span>0% - En attente</span>
                            <span>10-80% - En cours</span>
                            <span>80-100% - Terminé</span>
                        </div>
                    </div>

                    <!-- Bouton de sauvegarde -->
                    <button id="save-button" class="save-button" disabled>
                        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                            <polyline points="17,21 17,13 7,13 7,21"/>
                            <polyline points="7,3 7,8 15,8"/>
                        </svg>
                        Sauvegarder les Modifications
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
// Fonction pour charger les projets d'un client
function loadProjects(clientId) {
    fetch('get_projects.php?client_id=' + clientId)
        .then(response => response.json())
        .then(projects => {
            const projectSelect = document.getElementById('project-select');
            projectSelect.innerHTML = '<option value="">Choisir un projet...</option>';
            
            if (projects.length > 0) {
                projectSelect.disabled = false;
                projects.forEach(project => {
                    const option = document.createElement('option');
                    option.value = project.id_projet;
                    option.textContent = project.id_service + ' - ' + project.statut;
                    option.dataset.progress = project.progress || 0;
                    projectSelect.appendChild(option);
                });
            } else {
                projectSelect.innerHTML = '<option value="">Aucun projet trouvé</option>';
                projectSelect.disabled = true;
            }
            
            // Réinitialiser les autres champs
            document.getElementById('project-details').classList.add('hidden');
            document.getElementById('progress-slider').disabled = true;
            document.getElementById('save-button').disabled = true;
        });
}

// Fonction pour charger les détails d'un projet
function loadProjectDetails(projectId) {
    fetch('get_details.php?project_id=' + projectId)
        .then(response => response.json())
        .then(project => {
            if (project) {
                document.getElementById('project-name').textContent = 'Projet #' + project.id_projet;
                document.getElementById('project-description').textContent = 'Service: ' + project.id_service + ' | Statut: ' + project.statut;
                document.getElementById('current-progress').textContent = getProgressFromStatus(project.statut) + '%';
                
                const progress = getProgressFromStatus(project.statut);
                document.getElementById('progress-slider').value = progress;
                updateStatus(progress);
                
                document.getElementById('project-details').classList.remove('hidden');
                document.getElementById('progress-slider').disabled = false;
                document.getElementById('save-button').disabled = false;
            }
        });
}

// Fonction pour convertir le statut en pourcentage
function getProgressFromStatus(status) {
    switch(status) {
        case 'en_attente': return 0;
        case 'en_cours': return 50;
        case 'termine': return 100;
        case 'livre': return 100;
        default: return 0;
    }
}

// Fonction pour convertir le pourcentage en statut
function getStatusFromProgress(progress) {
    if (progress === 0) return { label: "En attente", class: "status-waiting" };
    if (progress > 0 && progress < 80) return { label: "En cours", class: "status-progress" };
    return { label: "Terminé", class: "status-completed" };
}

function updateStatus(progress) {
    const status = getStatusFromProgress(progress);
    document.getElementById('progress-value').textContent = progress + '%';
    document.getElementById('status-badge').textContent = status.label;
    document.getElementById('status-badge').className = 'status-badge ' + status.class;
}

// Gestion de la sélection du client
document.getElementById('client-select').addEventListener('change', function() {
    if (this.value) {
        loadProjects(this.value);
    } else {
        document.getElementById('project-select').innerHTML = '<option value="">Sélectionnez d\'abord un client</option>';
        document.getElementById('project-select').disabled = true;
    }
});

// Gestion de la sélection du projet
document.getElementById('project-select').addEventListener('change', function() {
    if (this.value) {
        loadProjectDetails(this.value);
    } else {
        document.getElementById('project-details').classList.add('hidden');
        document.getElementById('progress-slider').disabled = true;
        document.getElementById('save-button').disabled = true;
    }
});

// Gestion du slider de progression
document.getElementById('progress-slider').addEventListener('input', function() {
    updateStatus(parseInt(this.value));
});

// Gestion de la sauvegarde
document.getElementById('save-button').addEventListener('click', function() {
    const projectId = document.getElementById('project-select').value;
    const progress = parseInt(document.getElementById('progress-slider').value);
    
    if (projectId) {
        const formData = new FormData();
        formData.append('project_id', projectId);
        formData.append('progress', progress);
        
        fetch('statut.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (response.ok) {
                alert('Projet mis à jour avec succès !');
                // Recharger les détails du projet
                loadProjectDetails(projectId);
            } else {
                alert('Une erreur est survenue lors de la mise à jour.');
            }
        });
    }
});
</script>
</body>
</html>