<?php
// clients.php - Page d'administration des clients

// Vérification de l'authentification et des permissions
session_start();
require_once 'databases.php'; // Fichier de configuration avec la connexion à la DB

// Vérifier si l'utilisateur est connecté et est un gestionnaire
//if (!isset($_SESSION['id_utilisateur']) || $_SESSION['type'] !== 'gestionnaire') {
  //  header('Location: login.php');
  //  exit();
//}

// Traitement des actions CRUD
$message = '';
$message_type = '';

// Ajout d'un nouveau client
if (isset($_POST['ajouter'])) {
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $mot_de_passe = password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO utilisateur (nom, email, mot_de_passe, type, statut) VALUES (?, ?, ?, 'client', 'actif')");
        $stmt->execute([$nom, $email, $mot_de_passe]);
        $message = "Client ajouté avec succès!";
        $message_type = "success";
    } catch (PDOException $e) {
        $message = "Erreur lors de l'ajout du client: " . $e->getMessage();
        $message_type = "danger";
    }
}

// Modification d'un client
if (isset($_POST['modifier'])) {
    $id = $_POST['id'];
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $statut = $_POST['statut'];
    
    try {
        $stmt = $pdo->prepare("UPDATE utilisateur SET nom = ?, email = ?, statut = ? WHERE id_utilisateur = ?");
        $stmt->execute([$nom, $email, $statut, $id]);
        $message = "Client modifié avec succès!";
        $message_type = "success";
    } catch (PDOException $e) {
        $message = "Erreur lors de la modification du client: " . $e->getMessage();
        $message_type = "danger";
    }
}

// Suppression d'un client
if (isset($_GET['supprimer'])) {
    $id = $_GET['supprimer'];
    
    try {
        // Vérifier d'abord si le client a des projets associés
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM projet WHERE id_client = ?");
        $stmt->execute([$id]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $message = "Impossible de supprimer ce client car il a des projets associés.";
            $message_type = "warning";
        } else {
            $stmt = $pdo->prepare("DELETE FROM utilisateur WHERE id_utilisateur = ? AND type = 'client'");
            $stmt->execute([$id]);
            $message = "Client supprimé avec succès!";
            $message_type = "success";
        }
    } catch (PDOException $e) {
        $message = "Erreur lors de la suppression du client: " . $e->getMessage();
        $message_type = "danger";
    }
}

// Récupération de la liste des clients
$stmt = $pdo->query("SELECT * FROM utilisateur WHERE type = 'client' ORDER BY date_inscription DESC");
$clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Clients - Eureka Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .table-responsive {
            overflow-x: auto;
        }
        .action-btns {
            white-space: nowrap;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; // Inclure la barre latérale ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Gestion des Clients</h1>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#ajouterClientModal">
                        <i class="bi bi-plus-circle"></i> Ajouter un client
                    </button>
                </div>
                
                <?php if ($message): ?>
                    <div class="alert alert-<?= $message_type ?> alert-dismissible fade show" role="alert">
                        <?= $message ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nom</th>
                                <th>Email</th>
                                <th>Date d'inscription</th>
                                <th>Dernier accès</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($clients as $client): ?>
                                <tr>
                                    <td><?= htmlspecialchars($client['id_utilisateur']) ?></td>
                                    <td><?= htmlspecialchars($client['nom']) ?></td>
                                    <td><?= htmlspecialchars($client['email']) ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime($client['date_inscription'])) ?></td>
                                    <td><?= $client['dernier_acces'] ? date('d/m/Y H:i', strtotime($client['dernier_acces'])) : 'Jamais' ?></td>
                                    <td>
                                        <span class="badge bg-<?= $client['statut'] === 'actif' ? 'success' : 'secondary' ?>">
                                            <?= ucfirst($client['statut']) ?>
                                        </span>
                                    </td>
                                    <td class="action-btns">
                                        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modifierClientModal<?= $client['id_utilisateur'] ?>">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <a href="?supprimer=<?= $client['id_utilisateur'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce client?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                
                                <!-- Modal de modification pour ce client -->
                                <div class="modal fade" id="modifierClientModal<?= $client['id_utilisateur'] ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Modifier le client</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form method="POST">
                                                <div class="modal-body">
                                                    <input type="hidden" name="id" value="<?= $client['id_utilisateur'] ?>">
                                                    <div class="mb-3">
                                                        <label for="nom" class="form-label">Nom</label>
                                                        <input type="text" class="form-control" id="nom" name="nom" value="<?= htmlspecialchars($client['nom']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="email" class="form-label">Email</label>
                                                        <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($client['email']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="statut" class="form-label">Statut</label>
                                                        <select class="form-select" id="statut" name="statut">
                                                            <option value="actif" <?= $client['statut'] === 'actif' ? 'selected' : '' ?>>Actif</option>
                                                            <option value="inactif" <?= $client['statut'] === 'inactif' ? 'selected' : '' ?>>Inactif</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                                    <button type="submit" name="modifier" class="btn btn-primary">Enregistrer</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Modal d'ajout d'un nouveau client -->
    <div class="modal fade" id="ajouterClientModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Ajouter un nouveau client</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom</label>
                            <input type="text" class="form-control" id="nom" name="nom" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="mot_de_passe" class="form-label">Mot de passe</label>
                            <input type="password" class="form-control" id="mot_de_passe" name="mot_de_passe" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="ajouter" class="btn btn-primary">Ajouter</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>