<?php
// Script de test pour vérifier la connexion
require_once 'databases.php';
require_once 'dashboard-queries.php';

echo "<h2>Test de Connexion à la Base de Données</h2>";

try {
    // Test de connexion basique
    echo "<p>✅ Connexion à la base de données réussie!</p>";
    
    // Test des requêtes
    $dashboardQueries = new DashboardQueries();
    
    echo "<h3>Tests des requêtes:</h3>";
    
    // Test métriques
    $metrics = $dashboardQueries->getDashboardMetrics();
    echo "<p>✅ Métriques récupérées: " . json_encode($metrics) . "</p>";
    
    // Test projets par statut
    $projets = $dashboardQueries->getProjetsParStatut();
    echo "<p>✅ Projets par statut: " . json_encode($projets) . "</p>";
    
    // Test services populaires
    $services = $dashboardQueries->getServicesPopulaires();
    echo "<p>✅ Services populaires: " . count($services) . " services trouvés</p>";
    
    // Test évaluations
    $evaluations = $dashboardQueries->getEvaluationsRecentes();
    echo "<p>✅ Évaluations récentes: " . count($evaluations) . " évaluations trouvées</p>";
    
    // Test prédictions
    $predictions = $dashboardQueries->calculatePredictions();
    echo "<p>✅ Prédictions calculées: " . json_encode($predictions) . "</p>";
    
    echo "<h3 style='color: green;'>🎉 Tous les tests sont passés avec succès!</h3>";
    echo "<p><a href='dashboard.php'>➡️ Accéder au tableau de bord</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erreur: " . $e->getMessage() . "</p>";
    echo "<h3>Solutions possibles:</h3>";
    echo "<ul>";
    echo "<li>Vérifiez que MySQL est démarré</li>";
    echo "<li>Vérifiez les paramètres dans databases.php</li>";
    echo "<li>Vérifiez que la base 'eureka_design_db' existe</li>";
    echo "<li>Vérifiez que les tables sont créées</li>";
    echo "</ul>";
}
?>