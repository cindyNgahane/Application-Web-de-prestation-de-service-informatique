<?php
session_start();
require_once '../databases.php';

header('Content-Type: application/json');

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'gestionnaire') {
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit();
}

// Récupération des données JSON
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id_message'])) {
    echo json_encode(['success' => false, 'message' => 'ID du message manquant']);
    exit();
}

$id_message = $input['id_message'];
$id_admin = $_SESSION['user_id'];

try {
    // Vérifier que le message appartient bien à l'administrateur connecté
    $stmt_check = $pdo->prepare("SELECT id_message FROM message WHERE id_message = ? AND id_destinataire = ?");
    $stmt_check->execute([$id_message, $id_admin]);
    
    if (!$stmt_check->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Message non trouvé']);
        exit();
    }
    
    // Supprimer le message
    $stmt = $pdo->prepare("DELETE FROM message WHERE id_message = ?");
    $stmt->execute([$id_message]);
    
    echo json_encode(['success' => true, 'message' => 'Message supprimé avec succès']);
    
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur de base de données : ' . $e->getMessage()]);
}
?>
