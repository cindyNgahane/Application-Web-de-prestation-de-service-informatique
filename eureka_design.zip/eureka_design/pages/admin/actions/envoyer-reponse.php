<?php
session_start();
require_once '../databases.php';

header('Content-Type: application/json');

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'gestionnaire') {
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit();
}

// Récupération des données JSON
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id_destinataire']) || !isset($input['contenu'])) {
    echo json_encode(['success' => false, 'message' => 'Données manquantes']);
    exit();
}

$id_destinataire = $input['id_destinataire'];
$contenu = trim($input['contenu']);
$id_expediteur = $_SESSION['user_id'];

if (empty($contenu)) {
    echo json_encode(['success' => false, 'message' => 'Le contenu ne peut pas être vide']);
    exit();
}

try {
    // Vérifier que le destinataire existe
    $stmt_check = $pdo->prepare("SELECT id_utilisateur FROM utilisateur WHERE id_utilisateur = ?");
    $stmt_check->execute([$id_destinataire]);
    
    if (!$stmt_check->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Destinataire non trouvé']);
        exit();
    }
    
    // Insérer le nouveau message
    $stmt = $pdo->prepare("
        INSERT INTO message (id_expediteur, id_destinataire, contenu, date_envoi, est_lu) 
        VALUES (?, ?, ?, NOW(), 0)
    ");
    $stmt->execute([$id_expediteur, $id_destinataire, $contenu]);
    
    echo json_encode(['success' => true, 'message' => 'Réponse envoyée avec succès']);
    
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur de base de données : ' . $e->getMessage()]);
}
?>
