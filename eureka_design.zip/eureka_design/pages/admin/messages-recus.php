<?php
session_start();
require_once 'databases.php'; // Même dossier

// Vérification de l'authentification (seuls les gestionnaires peuvent accéder)
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'gestionnaire') {
    header('Location: ../login.php');
    exit();
}

// Récupération des messages reçus par l'administrateur connecté
try {
    $id_admin = $_SESSION['user_id'];
    
    // Requête pour récupérer tous les messages reçus avec les informations des expéditeurs
    $stmt = $pdo->prepare("
        SELECT 
            m.id_message,
            m.contenu,
            m.date_envoi,
            m.est_lu,
            u.nom as nom_expediteur,
            u.email as email_expediteur,
            u.id_utilisateur as id_expediteur
        FROM message m
        JOIN utilisateur u ON m.id_expediteur = u.id_utilisateur
        WHERE m.id_destinataire = ?
        ORDER BY m.date_envoi DESC
    ");
    
    $stmt->execute([$id_admin]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Compter les messages non lus
    $stmt_non_lus = $pdo->prepare("SELECT COUNT(*) as nb_non_lus FROM message WHERE id_destinataire = ? AND est_lu = 0");
    $stmt_non_lus->execute([$id_admin]);
    $nb_non_lus = $stmt_non_lus->fetch(PDO::FETCH_ASSOC)['nb_non_lus'];
    
} catch(PDOException $e) {
    $error_message = "Erreur lors de la récupération des messages : " . $e->getMessage();
    $messages = [];
    $nb_non_lus = 0;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages Reçus - Administration</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
        }
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }
        .stats {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255,255,255,0.2);
            padding: 10px 20px;
            border-radius: 20px;
            font-size: 0.9em;
        }
        .messages-container {
            padding: 30px;
        }
        .message-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 4px solid #3498db;
            transition: all 0.3s ease;
            position: relative;
        }
        .message-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .message-card.non-lu {
            border-left-color: #e74c3c;
            background: #fff5f5;
        }
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e9ecef;
        }
        .expediteur-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .expediteur-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3498db, #2ecc71);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2em;
        }
        .expediteur-details h3 {
            color: #2c3e50;
            margin-bottom: 3px;
        }
        .expediteur-details p {
            color: #7f8c8d;
            font-size: 0.9em;
        }
        .message-date {
            color: #7f8c8d;
            font-size: 0.9em;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .statut-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8em;
            font-weight: bold;
        }
        .statut-lu {
            background: #d4edda;
            color: #155724;
        }
        .statut-non-lu {
            background: #f8d7da;
            color: #721c24;
        }
        .message-content {
            background: white;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #e9ecef;
            line-height: 1.6;
            white-space: pre-wrap;
            max-height: 300px;
            overflow-y: auto;
        }
        .message-actions {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: #3498db;
            color: white;
        }
        .btn-primary:hover {
            background: #2980b9;
        }
        .btn-success {
            background: #27ae60;
            color: white;
        }
        .btn-success:hover {
            background: #219a52;
        }
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        .btn-danger:hover {
            background: #c0392b;
        }
        .no-messages {
            text-align: center;
            padding: 50px;
            color: #7f8c8d;
        }
        .filters {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        .filter-group {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filter-group label {
            font-weight: 600;
            color: #2c3e50;
        }
        .filter-group select,
        .filter-group input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.9em;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .alert-danger {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .alert-success {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        @media (max-width: 768px) {
            .header h1 {
                font-size: 2em;
            }
            
            .message-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .filter-group {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="stats">
                <?php echo $nb_non_lus; ?> message<?php echo $nb_non_lus > 1 ? 's' : ''; ?> non lu<?php echo $nb_non_lus > 1 ? 's' : ''; ?>
            </div>
            <h1>📧 Messages Reçus</h1>
            <p>Gestion des messages des clients</p>
        </div>

        <div class="filters">
            <div class="filter-group">
                <label>Filtrer par statut:</label>
                <select id="filtreStatut" onchange="filtrerMessages()">
                    <option value="tous">Tous les messages</option>
                    <option value="non_lu">Non lus uniquement</option>
                    <option value="lu">Lus uniquement</option>
                </select>
                
                <label>Rechercher:</label>
                <input type="text" id="rechercheTexte" placeholder="Nom du client ou contenu..." onkeyup="filtrerMessages()">
            </div>
        </div>

        <div class="messages-container">
            <?php if (isset($error_message)): ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <?php if (empty($messages)): ?>
                <div class="no-messages">
                    <div style="font-size: 4em; margin-bottom: 20px; opacity: 0.5;">📭</div>
                    <h3>Aucun message reçu</h3>
                    <p>Vous n'avez reçu aucun message des clients pour le moment.</p>
                </div>
            <?php else: ?>
                <?php foreach ($messages as $message): ?>
                    <div class="message-card <?php echo $message['est_lu'] ? 'lu' : 'non-lu'; ?>" 
                         data-statut="<?php echo $message['est_lu'] ? 'lu' : 'non_lu'; ?>"
                         id="message-<?php echo $message['id_message']; ?>">
                        <div class="message-header">
                            <div class="expediteur-info">
                                <div class="expediteur-avatar">
                                    <?php echo strtoupper(substr($message['nom_expediteur'], 0, 1)); ?>
                                </div>
                                <div class="expediteur-details">
                                    <h3><?php echo htmlspecialchars($message['nom_expediteur']); ?></h3>
                                    <p><?php echo htmlspecialchars($message['email_expediteur']); ?></p>
                                </div>
                            </div>
                            <div style="text-align: right;">
                                <div class="message-date">
                                    📅 <?php echo date('d/m/Y à H:i', strtotime($message['date_envoi'])); ?>
                                </div>
                                <div class="statut-badge <?php echo $message['est_lu'] ? 'statut-lu' : 'statut-non-lu'; ?>" 
                                     id="statut-<?php echo $message['id_message']; ?>">
                                    <?php echo $message['est_lu'] ? '✅ Lu' : '🔔 Non lu'; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="message-content">
                            <?php echo htmlspecialchars($message['contenu']); ?>
                        </div>
                        
                        <div class="message-actions">
                            <?php if (!$message['est_lu']): ?>
                                <button class="btn btn-success" 
                                        onclick="marquerCommeLu(<?php echo $message['id_message']; ?>)"
                                        id="btn-lu-<?php echo $message['id_message']; ?>">
                                    ✅ Marquer comme lu
                                </button>
                            <?php endif; ?>
                            
                            <button class="btn btn-primary" 
                                    onclick="repondre(<?php echo $message['id_expediteur']; ?>, '<?php echo htmlspecialchars($message['nom_expediteur']); ?>')">
                                📤 Répondre
                            </button>
                            
                            <button class="btn btn-danger" 
                                    onclick="supprimerMessage(<?php echo $message['id_message']; ?>)">
                                🗑️ Supprimer
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function filtrerMessages() {
            const filtreStatut = document.getElementById('filtreStatut').value;
            const rechercheTexte = document.getElementById('rechercheTexte').value.toLowerCase();
            const messages = document.querySelectorAll('.message-card');
            
            messages.forEach(message => {
                const statut = message.getAttribute('data-statut');
                const contenu = message.textContent.toLowerCase();
                
                let afficher = true;
                
                // Filtre par statut
                if (filtreStatut !== 'tous' && statut !== filtreStatut) {
                    afficher = false;
                }
                
                // Filtre par texte
                if (rechercheTexte && !contenu.includes(rechercheTexte)) {
                    afficher = false;
                }
                
                message.style.display = afficher ? 'block' : 'none';
            });
        }

        function marquerCommeLu(idMessage) {
            if (confirm('Marquer ce message comme lu ?')) {
                fetch('actions/marquer-lu.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        id_message: idMessage
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Mettre à jour l'interface
                        const messageCard = document.getElementById('message-' + idMessage);
                        const statutBadge = document.getElementById('statut-' + idMessage);
                        const btnLu = document.getElementById('btn-lu-' + idMessage);
                        
                        messageCard.classList.remove('non-lu');
                        messageCard.classList.add('lu');
                        messageCard.setAttribute('data-statut', 'lu');
                        
                        statutBadge.className = 'statut-badge statut-lu';
                        statutBadge.textContent = '✅ Lu';
                        
                        if (btnLu) {
                            btnLu.remove();
                        }
                        
                        // Mettre à jour le compteur
                        location.reload();
                    } else {
                        alert('Erreur : ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    alert('Une erreur est survenue');
                });
            }
        }

        function repondre(idExpediteur, nomExpediteur) {
            const reponse = prompt('Votre réponse à ' + nomExpediteur + ' :');
            if (reponse && reponse.trim() !== '') {
                fetch('actions/envoyer-reponse.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        id_destinataire: idExpediteur,
                        contenu: reponse.trim()
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Réponse envoyée avec succès !');
                    } else {
                        alert('Erreur : ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    alert('Une erreur est survenue');
                });
            }
        }

        function supprimerMessage(idMessage) {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce message ? Cette action est irréversible.')) {
                fetch('actions/supprimer-message.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        id_message: idMessage
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('message-' + idMessage).remove();
                        alert('Message supprimé avec succès !');
                    } else {
                        alert('Erreur : ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    alert('Une erreur est survenue');
                });
            }
        }
    </script>
</body>
</html>