
<?php
session_start();

// Vérification de l'authentification et des permissions
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'gestionnaire') {
    header('Location: ../login.php');
    exit();
}


require_once 'databases.php'; // Fichier de configuration de la base de données

// Fonctions utilitaires
function getServices(PDO $pdo) {
    try {
        $stmt = $pdo->query("SELECT id_service, nom, prix FROM service WHERE est_actif = 1");
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Debug - à enlever en production
        error_log("Services récupérés: " . print_r($services, true));
        
        return $services;
    } catch (PDOException $e) {
        error_log("Erreur lors de la récupération des services: " . $e->getMessage());
        return [];
    }
}

function getClients(PDO $pdo) {
    $stmt = $pdo->query("SELECT id_utilisateur, nom, email FROM utilisateur WHERE type = 'client' AND statut = 'actif'");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getProjets(PDO $pdo) {
    $query = "SELECT p.*, u.nom as client_nom, s.nom as service_nom 
              FROM projet p
              JOIN utilisateur u ON p.id_client = u.id_utilisateur
              JOIN service s ON p.id_service = s.id_service
              ORDER BY p.date_creation DESC";
    $stmt = $pdo->query($query);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Traitement des actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'ajouter':
                    // Validation des données
                    if (empty($_POST['id_client']) || empty($_POST['id_service'])) {
                        throw new Exception("Tous les champs obligatoires doivent être remplis");
                    }

                    $stmt = $pdo->prepare("INSERT INTO projet (id_client, id_service, date_livraison_prevue, statut, notes_supplementaires) 
                                          VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $_POST['id_client'],
                        $_POST['id_service'],
                        $_POST['date_livraison_prevue'] ?: null,
                        'en_attente',
                        $_POST['notes_supplementaires'] ?: null
                    ]);
                    $_SESSION['message'] = "Projet ajouté avec succès";
                    $_SESSION['message_type'] = "success";
                    break;

                case 'modifier':
                    if (empty($_POST['id_projet'])) {
                        throw new Exception("ID projet manquant");
                    }

                    $stmt = $pdo->prepare("UPDATE projet 
                                          SET id_client = ?, id_service = ?, date_livraison_prevue = ?, 
                                              statut = ?, notes_supplementaires = ?
                                          WHERE id_projet = ?");
                    $stmt->execute([
                        $_POST['id_client'],
                        $_POST['id_service'],
                        $_POST['date_livraison_prevue'] ?: null,
                        $_POST['statut'],
                        $_POST['notes_supplementaires'] ?: null,
                        $_POST['id_projet']
                    ]);
                    $_SESSION['message'] = "Projet mis à jour avec succès";
                    $_SESSION['message_type'] = "success";
                    break;

                case 'changer_statut':
                    if (empty($_POST['id_projet']) || empty($_POST['nouveau_statut'])) {
                        throw new Exception("Données manquantes pour changer le statut");
                    }

                    $stmt = $pdo->prepare("UPDATE projet SET statut = ? WHERE id_projet = ?");
                    $stmt->execute([$_POST['nouveau_statut'], $_POST['id_projet']]);
                    $_SESSION['message'] = "Statut du projet mis à jour";
                    $_SESSION['message_type'] = "success";
                    break;

                case 'supprimer':
                    if (empty($_POST['id_projet'])) {
                        throw new Exception("ID projet manquant");
                    }

                    $stmt = $pdo->prepare("DELETE FROM projet WHERE id_projet = ?");
                    $stmt->execute([$_POST['id_projet']]);
                    $_SESSION['message'] = "Projet supprimé avec succès";
                    $_SESSION['message_type'] = "success";
                    break;
            }
        }
    } catch (Exception $e) {
        $_SESSION['message'] = "Erreur: " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
    }
    header("Location: projet.php");
    exit();
}

// Récupération des données
$services = getServices($pdo);
$clients = getClients($pdo);
$projets = getProjets($pdo);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration des Projets - Eureka Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .statut-en_attente { background-color: #fff3cd; }
        .statut-en_cours { background-color: #cce5ff; }
        .statut-termine { background-color: #d4edda; }
        .statut-livre { background-color: #e2e3e5; }
        .action-buttons .btn { margin-right: 5px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; // Inclure la barre latérale de l'admin ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Administration des Projets</h1>
                </div>

                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
                        <?= $_SESSION['message'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
                <?php endif; ?>

                <!-- Formulaire d'ajout/modification -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 id="form-title">Ajouter un nouveau projet</h5>
                    </div>
                    <div class="card-body">
                        <form id="projet-form" method="POST">
                            <input type="hidden" id="action" name="action" value="ajouter">
                            <input type="hidden" id="id_projet" name="id_projet" value="">
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="id_client" class="form-label">Client</label>
                                    <select class="form-select" id="id_client" name="id_client" required>
                                        <option value="">Sélectionner un client</option>
                                        <?php foreach ($clients as $client): ?>
                                            <option value="<?= $client['id_utilisateur'] ?>"><?= htmlspecialchars($client['nom']) ?> (<?= htmlspecialchars($client['email']) ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="id_service" class="form-label">Service</label>
                                    <select class="form-select" id="id_service" name="id_service" required>
                                        <option value="">Sélectionner un service</option>
                                        <?php foreach ($services as $service): ?>
                                            <option value="<?= $service['id_service'] ?>" data-prix="<?= $service['prix'] ?>"><?= htmlspecialchars($service['nom']) ?> (<?= number_format($service['prix'], 2) ?> €)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="date_livraison_prevue" class="form-label">Date de livraison prévue</label>
                                    <input type="date" class="form-control" id="date_livraison_prevue" name="date_livraison_prevue">
                                </div>
                                <div class="col-md-6">
                                    <label for="statut" class="form-label">Statut</label>
                                    <select class="form-select" id="statut" name="statut">
                                        <option value="en_attente">En attente</option>
                                        <option value="en_cours">En cours</option>
                                        <option value="termine">Terminé</option>
                                        <option value="livre">Livré</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="notes_supplementaires" class="form-label">Notes supplémentaires</label>
                                <textarea class="form-control" id="notes_supplementaires" name="notes_supplementaires" rows="3"></textarea>
                            </div>
                            
                            <div class="d-flex justify-content-end">
                                <button type="button" id="cancel-edit" class="btn btn-secondary me-2" style="display: none;">Annuler</button>
                                <button type="submit" class="btn btn-primary">Enregistrer</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Liste des projets -->
                <div class="card">
                    <div class="card-header">
                        <h5>Liste des projets</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Client</th>
                                        <th>Service</th>
                                        <th>Date création</th>
                                        <th>Livraison prévue</th>
                                        <th>Statut</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($projets as $projet): ?>
                                        <tr class="statut-<?= $projet['statut'] ?>">
                                            <td><?= $projet['id_projet'] ?></td>
                                            <td><?= htmlspecialchars($projet['client_nom']) ?></td>
                                            <td><?= htmlspecialchars($projet['service_nom']) ?></td>
                                            <td><?= date('d/m/Y H:i', strtotime($projet['date_creation'])) ?></td>
                                            <td><?= $projet['date_livraison_prevue'] ? date('d/m/Y', strtotime($projet['date_livraison_prevue'])) : 'Non définie' ?></td>
                                            <td>
                                                <span class="badge bg-<?= 
                                                    $projet['statut'] === 'en_attente' ? 'warning' : 
                                                    ($projet['statut'] === 'en_cours' ? 'primary' : 
                                                    ($projet['statut'] === 'termine' ? 'success' : 'secondary')) ?>">
                                                    <?= ucfirst(str_replace('_', ' ', $projet['statut'])) ?>
                                                </span>
                                            </td>
                                            <td class="action-buttons">
                                                <button class="btn btn-sm btn-outline-primary edit-btn" 
                                                        data-id="<?= $projet['id_projet'] ?>"
                                                        data-client="<?= $projet['id_client'] ?>"
                                                        data-service="<?= $projet['id_service'] ?>"
                                                        data-dateprevue="<?= $projet['date_livraison_prevue'] ?>"
                                                        data-statut="<?= $projet['statut'] ?>"
                                                        data-notes="<?= htmlspecialchars($projet['notes_supplementaires']) ?>">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                                        <i class="bi bi-gear"></i> Statut
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <li><a class="dropdown-item change-status" href="#" data-id="<?= $projet['id_projet'] ?>" data-status="en_attente">En attente</a></li>
                                                        <li><a class="dropdown-item change-status" href="#" data-id="<?= $projet['id_projet'] ?>" data-status="en_cours">En cours</a></li>
                                                        <li><a class="dropdown-item change-status" href="#" data-id="<?= $projet['id_projet'] ?>" data-status="termine">Terminé</a></li>
                                                        <li><a class="dropdown-item change-status" href="#" data-id="<?= $projet['id_projet'] ?>" data-status="livre">Livré</a></li>
                                                    </ul>
                                                </div>
                                                
                                                <button class="btn btn-sm btn-outline-danger delete-btn" data-id="<?= $projet['id_projet'] ?>">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Modal de confirmation de suppression -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirmer la suppression</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Êtes-vous sûr de vouloir supprimer ce projet ? Cette action est irréversible.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <form id="delete-form" method="POST">
                        <input type="hidden" name="action" value="supprimer">
                        <input type="hidden" id="delete-id" name="id_projet" value="">
                        <button type="submit" class="btn btn-danger">Supprimer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Édition d'un projet
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const client = this.getAttribute('data-client');
                const service = this.getAttribute('data-service');
                const dateprevue = this.getAttribute('data-dateprevue');
                const statut = this.getAttribute('data-statut');
                const notes = this.getAttribute('data-notes');
                
                document.getElementById('form-title').textContent = 'Modifier le projet #' + id;
                document.getElementById('action').value = 'modifier';
                document.getElementById('id_projet').value = id;
                document.getElementById('id_client').value = client;
                document.getElementById('id_service').value = service;
                document.getElementById('date_livraison_prevue').value = dateprevue;
                document.getElementById('statut').value = statut;
                document.getElementById('notes_supplementaires').value = notes;
                document.getElementById('cancel-edit').style.display = 'block';
                
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
        
        // Annulation de l'édition
        document.getElementById('cancel-edit').addEventListener('click', function() {
            document.getElementById('projet-form').reset();
            document.getElementById('form-title').textContent = 'Ajouter un nouveau projet';
            document.getElementById('action').value = 'ajouter';
            document.getElementById('id_projet').value = '';
            this.style.display = 'none';
        });
        
        // Changement de statut
        document.querySelectorAll('.change-status').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const id = this.getAttribute('data-id');
                const status = this.getAttribute('data-status');
                
                if (confirm(`Êtes-vous sûr de vouloir changer le statut de ce projet à "${status.replace('_', ' ')}" ?`)) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.innerHTML = `
                        <input type="hidden" name="action" value="changer_statut">
                        <input type="hidden" name="id_projet" value="${id}">
                        <input type="hidden" name="nouveau_statut" value="${status}">
                    `;
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        });
        
        // Suppression d'un projet
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                document.getElementById('delete-id').value = id;
                const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
                modal.show();
            });
        });
    </script>
</body>
</html>