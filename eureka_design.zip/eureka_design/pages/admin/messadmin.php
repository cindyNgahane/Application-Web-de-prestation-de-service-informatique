<?php
session_start();
require 'databases.php';

// Vérification admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'gestionnaire') {
    header('Location: ../login.php');
    exit();
}

// Traitement de l'envoi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_destinataire = $_POST['id_destinataire'];
    $contenu = $_POST['contenu'];
    $id_expediteur = $_SESSION['user_id'];

    try {
        $stmt = $pdo->prepare("INSERT INTO message (contenu, id_expediteur, id_destinataire) VALUES (?, ?, ?)");
        $stmt->execute([$contenu, $id_expediteur, $id_destinataire]);
        
        $_SESSION['message'] = "Message envoyé avec succès";
        $_SESSION['message_type'] = "success";
        header("Location: messadmin.php");
        exit();
    } catch (PDOException $e) {
        $_SESSION['message'] = "Erreur: " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
    }
}

// Récupération des utilisateurs
$stmt = $pdo->query("SELECT id_utilisateur, nom, email FROM utilisateur WHERE type = 'client' AND statut = 'actif'");
$utilisateurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envoyer un Message - Administration</title>
    <style>
        :root {
            --primary-color: #4a6fa5;
            --secondary-color: #166088;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

       body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
            min-height: 100vh;
            color: var(--dark-color);
            padding: 20px;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.container {
    max-width: 800px;
    margin: 30px auto;
    background: white;
    border-radius: 15px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    overflow: hidden;
    padding: 0; /* Retirer le padding interne */
}


       .header {
    background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
    color: white !important;
    padding: 30px !important;
    text-align: center;
    margin: 0;
    border-bottom: none !important;
}
        .header h2 {
            color: white !important;
            font-size: 28px;
            margin-bottom: 10px;
        }

        .header p {
            color: white !important;
            font-size: 16px;
        }

        .alert {
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 8px;
            border: 1px solid transparent;
            font-weight: 500;
        }

        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }

        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }

        .form-container {
            background: var(--light-color);
            padding: 25px;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--secondary-color);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: white;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(74, 111, 165, 0.2);
            transform: translateY(-1px);
        }

        select.form-control {
            cursor: pointer;
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
            font-family: inherit;
        }

        .btn {
            display: inline-block;
            padding: 12px 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            text-decoration: none;
            text-align: center;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(74, 111, 165, 0.3);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #545b62;
            transform: translateY(-2px);
        }

        .btn:active {
            transform: translateY(0);
        }

        .btn-lg {
            padding: 15px 30px;
            font-size: 18px;
        }

        .form-footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .navigation-links {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .btn-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .form-help {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
            font-style: italic;
        }

        .required {
            color: var(--danger-color);
        }

        .client-info {
            background: white;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #e9ecef;
            margin-top: 5px;
            font-size: 14px;
            color: #666;
        }

        @media (max-width: 768px) {
            .container {
                padding: 20px;
                margin: 15px;
            }
            
            .header h2 {
                font-size: 24px;
            }
            
            .btn-group {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
            }
        }

        /* Animation pour les éléments */
        .form-container {
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Style pour les options du select */
        select option {
            padding: 10px;
        }

        /* Amélioration du focus */
        .form-control:focus + .form-help {
            color: var(--primary-color);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Envoyer un Message</h2>
            <p>Communiquer avec vos clients</p>
        </div>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?= $_SESSION['message_type'] ?>">
                <?= $_SESSION['message'] ?>
            </div>
            <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" id="messageForm">
                <div class="form-group">
                    <label for="destinataire">
                        Client destinataire <span class="required">*</span>
                    </label>
                    <select name="id_destinataire" id="destinataire" class="form-control" required onchange="showClientInfo()">
                        <option value="">-- Sélectionner un client --</option>
                        <?php foreach ($utilisateurs as $user): ?>
                            <option value="<?= $user['id_utilisateur'] ?>" 
                                    data-email="<?= htmlspecialchars($user['email']) ?>">
                                <?= htmlspecialchars($user['nom']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-help">Choisissez le client qui recevra votre message</div>
                    <div id="clientInfo" class="client-info" style="display: none;"></div>
                </div>

                <div class="form-group">
                    <label for="contenu">
                        Message <span class="required">*</span>
                    </label>
                    <textarea name="contenu" id="contenu" class="form-control" rows="6" required 
                              placeholder="Tapez votre message ici..."></textarea>
                    <div class="form-help">Rédigez votre message de manière claire et professionnelle</div>
                </div>
                
                <div class="form-footer">
                    <div class="btn-group">
                        <button type="submit" class="btn btn-primary btn-lg">
                            ✉ Envoyer le Message
                        </button>
                        <button type="reset" class="btn btn-secondary" onclick="resetForm()">
                            🔄 Effacer
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <div class="navigation-links">
            <a href="messages-recus.php" class="btn btn-primary btn-lg">
                📨 Messages Reçus
            </a>
        </div>
    </div>

    <script>
        function showClientInfo() {
            const select = document.getElementById('destinataire');
            const clientInfo = document.getElementById('clientInfo');
            const selectedOption = select.options[select.selectedIndex];
            
            if (selectedOption.value) {
                const email = selectedOption.getAttribute('data-email');
                clientInfo.innerHTML = `<strong>Email:</strong> ${email}`;
                clientInfo.style.display = 'block';
            } else {
                clientInfo.style.display = 'none';
            }
        }

        function resetForm() {
            document.getElementById('messageForm').reset();
            document.getElementById('clientInfo').style.display = 'none';
        }

        // Animation au chargement
        document.addEventListener('DOMContentLoaded', function() {
            const container = document.querySelector('.container');
            container.style.opacity = '0';
            container.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                container.style.transition = 'all 0.5s ease-out';
                container.style.opacity = '1';
                container.style.transform = 'translateY(0)';
            }, 100);
        });

        // Validation du formulaire
        document.getElementById('messageForm').addEventListener('submit', function(e) {
            const destinataire = document.getElementById('destinataire').value;
            const contenu = document.getElementById('contenu').value.trim();
            
            if (!destinataire) {
                alert('Veuillez sélectionner un destinataire');
                e.preventDefault();
                return;
            }
            
            if (!contenu) {
                alert('Veuillez saisir un message');
                e.preventDefault();
                return;
            }
            
            if (contenu.length < 10) {
                alert('Le message doit contenir au moins 10 caractères');
                e.preventDefault();
                return;
            }
        });

        // Auto-resize du textarea
        document.getElementById('contenu').addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = this.scrollHeight + 'px';
        });
    </script>
</body>
</html>