<?php
session_start();
require_once 'databases.php';



// Récupération des évaluations avec les détails des projets et clients
function getEvaluations(PDO $pdo) {
    $query = "SELECT e.*, 
                     u.nom as client_nom, u.prenom as client_prenom,
                     s.nom as service_nom, p.titre as projet_titre
              FROM evaluations e
              JOIN projet p ON e.id_projet = p.id_projet
              JOIN utilisateur u ON e.id_client = u.id_utilisateur
              JOIN service s ON p.id_service = s.id_service
              ORDER BY e.date_evaluation DESC";
    
    return $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
}

$evaluations = getEvaluations($pdo);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Évaluations Clients - Administration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --sidebar-width: 250px;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fa;
            overflow-x: hidden;
        }

        /* Sidebar styling */
        .sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: #343a40;
            transition: all 0.3s;
            z-index: 1000;
        }

        /* Main content area */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: all 0.3s;
            min-height: 100vh;
        }

        /* Evaluation card styling */
        .evaluation-card {
            background: #ffffff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0.15rem 1.75rem rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }

        .evaluation-card:hover {
            transform: translateY(-5px);
        }

        .rating-stars {
            color: #f6c23e;
            font-size: 1.5rem;
        }

        .rating-stars .empty-star {
            color: #e3e6f0;
        }

        .client-avatar {
            width: 50px;
            height: 50px;
            background: #007bff;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 15px;
            font-size: 1.2rem;
        }

        .evaluation-comment {
            background: #e9ecef;
            border-left: 4px solid #007bff;
            padding: 15px;
            margin: 15px 0;
            border-radius: 0 8px 8px 0;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <?php include 'sidebar.php'; ?>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="bi bi-star-fill"></i> Évaluations Clients</h1>
        </div>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
        <?php endif; ?>
        
        <?php if (count($evaluations) > 0): ?>
            <div class="row">
                <?php foreach ($evaluations as $eval): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="evaluation-card">
                            <div class="d-flex align-items-center mb-3">
                                <div class="client-avatar">
                                    <?= strtoupper(substr($eval['client_prenom'], 0, 1) . substr($eval['client_nom'], 0, 1)) ?>
                                </div>
                                <div>
                                    <h5 class="mb-0 text-capitalize"><?= htmlspecialchars($eval['client_prenom']) ?> <span class="text-uppercase"><?= htmlspecialchars($eval['client_nom']) ?></span></h5>
                                    <small class="text-muted">Projet: <?= !empty($eval['projet_titre']) ? htmlspecialchars($eval['projet_titre']) : 'Projet #'.$eval['id_projet'] ?></small>
                                </div>
                            </div>
                            
                            <div class="rating-stars mb-2">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="bi bi-star-fill <?= $i <= $eval['note'] ? '' : 'empty-star' ?>"></i>
                                <?php endfor; ?>
                                <span class="ms-2"><?= $eval['note'] ?>/5</span>
                            </div>
                            
                            <div class="mb-2">
                                <small class="text-muted">
                                    <i class="bi bi-calendar"></i> <?= date('d/m/Y H:i', strtotime($eval['date_evaluation'])) ?>
                                    | <i class="bi bi-briefcase"></i> <?= htmlspecialchars($eval['service_nom']) ?>
                                </small>
                            </div>
                            
                            <?php if (!empty($eval['commentaire'])): ?>
                                <div class="evaluation-comment">
                                    <p class="mb-0"><?= nl2br(htmlspecialchars($eval['commentaire'])) ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-star display-4 text-muted"></i>
                <h4 class="mt-3">Aucune évaluation disponible</h4>
                <p class="text-muted">Les clients n'ont pas encore évalué de projets.</p>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>