<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=eureka_design_db', 'root', '');

    // Sécurisation des données reçues
    $contenu = htmlspecialchars($_POST['contenu']);
    $id_destinataire = (int)$_POST['id_destinataire'];

    // Insertion du message
    $stmt = $pdo->prepare("INSERT INTO message (contenu, id_expediteur, id_destinataire) VALUES (?, ?, ?)");
    $stmt->execute([$contenu, 18, $id_destinataire]);

    echo "Message envoyé avec succès ! <a href='projet.php'>Retour</a>";
} else {
    echo "Méthode non autorisée.";
}
    ?>

    // Affichage du message de confirmation stylisé
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Message envoyé</title>
        <style>
            :root {
                --primary-color: #4a6fa5;
                --secondary-color: #166088;
                --success-color: #28a745;
                --light-color: #f8f9fa;
                --dark-color: #343a40;
            }
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            }
            
            body {
                background-color: #f5f5f5;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                padding: 20px;
            }
            
            .confirmation-container {
                background: white;
                padding: 40px;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
                text-align: center;
                max-width: 500px;
                width: 100%;
            }
            
            .success-icon {
                color: var(--success-color);
                font-size: 50px;
                margin-bottom: 20px;
            }
            
            h1 {
                color: var(--secondary-color);
                margin-bottom: 20px;
                font-size: 24px;
            }
            
            .btn {
                display: inline-block;
                background-color: var(--primary-color);
                color: white;
                border: none;
                padding: 12px 25px;
                font-size: 16px;
                border-radius: 5px;
                cursor: pointer;
                transition: all 0.3s;
                text-decoration: none;
                margin-top: 30px;
                font-weight: 600;
            }
            
            .btn:hover {
                background-color: var(--secondary-color);
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }
            
            @media (max-width: 600px) {
                .confirmation-container {
                    padding: 30px 20px;
                }
                
                h1 {
                    font-size: 20px;
                }
            }
        </style>
    </head>
    <body>
        <div class="confirmation-container">
            <div class="success-icon">✓</div>
            <h1>Message envoyé avec succès !</h1>
            <p>Votre message a bien été transmis au destinataire.</p>
            <a href="projet.php" class="btn">Retour </a>
        </div>
    </body>
    </html>';
 