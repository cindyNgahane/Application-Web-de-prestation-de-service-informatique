<?php
session_start();

// Vérification de l'authentification
if (!isset($_SESSION['user_id'])) {
    header('Location: admin/login.php');
    exit();
}

require_once 'dashboard-queries.php';

// Vérifier la connexion à la base de données
try {
    $dashboardQueries = new DashboardQueries();
    $dashboardData = $dashboardQueries->getAllDashboardData();
    $connectionStatus = 'success';
} catch (Exception $e) {
    $connectionStatus = 'error';
    $errorMessage = $e->getMessage();
    // Données par défaut en cas d'erreur
    $dashboardData = [
        'metrics' => ['totalClients' => 0, 'totalProjets' => 0, 'chiffreAffaires' => 0, 'satisfactionMoyenne' => 0, 'messagesNonLus' => 0],
        'projetsParStatut' => ['en_attente' => 0, 'en_cours' => 0, 'termine' => 0, 'livre' => 0],
        'servicesPopulaires' => [],
        'evaluationsRecentes' => [],
        'evolutionMensuelle' => [],
        'predictions' => ['projetsMoisProchain' => 0, 'revenusPrevus' => 0, 'tauxSatisfactionPrevu' => 0, 'clientsPotentiels' => 0],
        'insights' => ['evolutionSatisfaction' => 0, 'servicePlusRentable' => 'Aucun', 'projetsEnRetard' => 0]
    ];
}

// Pour AJAX
if (isset($_GET['ajax']) && $_GET['ajax'] === 'true') {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => $connectionStatus,
        'data' => $dashboardData,
        'error' => $connectionStatus === 'error' ? $errorMessage : null
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Eureka Design</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .tab-button.active { 
            border-bottom-color: #3b82f6 !important; 
            color: #3b82f6 !important; 
        }
        .sidebar {
    display: block !important;
    visibility: visible !important;
    width: 16.66667% !important;
}
    </style>
</head>
<body class="bg-gray-50">
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="min-h-screen p-6">
                    <div class="max-w-7xl mx-auto space-y-6">
                        <!-- Header -->
                        <div class="flex items-center justify-between">
                            <div>
                                <h1 class="text-3xl font-bold text-gray-900">Tableau de Bord Eureka Design</h1>
                                <p class="text-gray-600 mt-1">Données en temps réel de votre base de données</p>
                            </div>
                            <div class="flex items-center space-x-4">
                                <button onclick="refreshDashboard()" id="refreshBtn" class="bg-white border border-gray-300 rounded-md px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                                    <i class="fas fa-sync-alt mr-2" id="refreshIcon"></i>Actualiser
                                </button>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium <?= $connectionStatus === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                    <span class="w-2 h-2 <?= $connectionStatus === 'success' ? 'bg-green-500' : 'bg-red-500' ?> rounded-full mr-2"></span>
                                    <?= $connectionStatus === 'success' ? 'Base de données connectée' : 'Erreur de connexion' ?>
                                </span>
                            </div>
                        </div>

                        <?php if ($connectionStatus === 'error'): ?>
                            <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                                <div class="flex">
                                    <i class="fas fa-exclamation-triangle text-red-400 mr-3 mt-1"></i>
                                    <div>
                                        <h3 class="text-sm font-medium text-red-800">Erreur de connexion à la base de données</h3>
                                        <p class="text-sm text-red-700 mt-1"><?= htmlspecialchars($errorMessage) ?></p>
                                        <p class="text-sm text-red-600 mt-2">Vérifiez que votre serveur MySQL est démarré et que les paramètres dans databases.php sont corrects.</p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- Métriques principales -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                            <div class="bg-white rounded-lg shadow p-6">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-sm font-medium text-gray-600">Total Clients</p>
                                        <p class="text-2xl font-bold text-gray-900"><?= number_format($dashboardData['metrics']['totalClients']) ?></p>
                                    </div>
                                    <i class="fas fa-users text-gray-400 text-xl"></i>
                                </div>
                                <p class="text-xs text-gray-500 mt-2">Clients actifs</p>
                            </div>

                            <div class="bg-white rounded-lg shadow p-6">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-sm font-medium text-gray-600">Total Projets</p>
                                        <p class="text-2xl font-bold text-gray-900"><?= number_format($dashboardData['metrics']['totalProjets']) ?></p>
                                    </div>
                                    <i class="fas fa-folder-open text-gray-400 text-xl"></i>
                                </div>
                                <p class="text-xs text-gray-500 mt-2">Tous statuts confondus</p>
                            </div>

                            <div class="bg-white rounded-lg shadow p-6">
                                <div class="flex items-center justify-between">
                                   <div> 
                                        <p class="text-sm font-medium text-gray-600">Chiffre d'Affaires</p>
                                        <p class="text-2xl font-bold text-gray-900"><?= number_format($dashboardData['metrics']['chiffreAffaires'], 0, ',', ' ') ?> €</p>
                                    </div>
                        
                                    <i class="fas fa-euro-sign text-gray-400 text-xl"></i>
                                </div>
                                <p class="text-xs text-gray-500 mt-2">Total historique</p>
                            </div>
                        
                            <div class="bg-white rounded-lg shadow p-6">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-sm font-medium text-gray-600">Satisfaction</p>
                                        <p class="text-2xl font-bold text-gray-900"><?= $dashboardData['metrics']['satisfactionMoyenne'] ?>/5</p>
                                    </div>
                                    <i class="fas fa-star text-gray-400 text-xl"></i>
                                </div>
                                <div class="flex mt-2">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fas fa-star text-sm <?= $i <= round($dashboardData['metrics']['satisfactionMoyenne']) ? 'text-yellow-400' : 'text-gray-300' ?>"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>

                            <div class="bg-white rounded-lg shadow p-6">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-sm font-medium text-gray-600">Messages</p>
                                        <p class="text-2xl font-bold text-gray-900"><?= number_format($dashboardData['metrics']['messagesNonLus']) ?></p>
                                    </div>
                                    <i class="fas fa-envelope text-gray-400 text-xl"></i>
                                </div>
                                <p class="text-xs text-gray-500 mt-2">Non lus</p>
                            </div>
                        </div>

                        <!-- Onglets -->
                        <div class="bg-white rounded-lg shadow">
                            <div class="border-b border-gray-200">
                                <nav class="-mb-px flex space-x-8 px-6">
                                    <button onclick="showTab('overview')" class="tab-button active border-b-2 border-blue-500 py-4 px-1 text-sm font-medium text-blue-600">
                                        Vue d'ensemble
                                    </button>
                                    <button onclick="showTab('projects')" class="tab-button border-b-2 border-transparent py-4 px-1 text-sm font-medium text-gray-500 hover:text-gray-700">
                                        Projets
                                    </button>
                                    <button onclick="showTab('analytics')" class="tab-button border-b-2 border-transparent py-4 px-1 text-sm font-medium text-gray-500 hover:text-gray-700">
                                        Analyses
                                    </button>
                                    <button onclick="showTab('predictions')" class="tab-button border-b-2 border-transparent py-4 px-1 text-sm font-medium text-gray-500 hover:text-gray-700">
                                        Prédictions IA
                                    </button>
                                    <button onclick="showTab('visualizations')" class="tab-button border-b-2 border-transparent py-4 px-1 text-sm font-medium text-gray-500 hover:text-gray-700">
                                        <i class="fas fa-chart-pie mr-2"></i>Visualisations
                                    </button>
                                </nav>
                            </div>

                            <!-- Vue d'ensemble -->
                            <div id="overview" class="tab-content active p-6">
                                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                                    <!-- Répartition des projets -->
                                    <div class="bg-gray-50 rounded-lg p-6">
                                        <h3 class="text-lg font-semibold mb-4">Répartition des Projets</h3>
                                        <div class="space-y-4">
                                            <?php foreach($dashboardData['projetsParStatut'] as $statut => $nombre): ?>
                                                <div class="flex items-center justify-between">
                                                    <div class="flex items-center space-x-2">
                                                        <i class="fas fa-circle text-sm <?= getStatusColor($statut) ?>"></i>
                                                        <span class="capitalize"><?= str_replace('_', ' ', $statut) ?></span>
                                                    </div>
                                                    <div class="flex items-center space-x-2">
                                                        <div class="w-20 bg-gray-200 rounded-full h-2">
                                                            <div class="h-2 rounded-full <?= getStatusBgColor($statut) ?>" 
                                                                 style="width: <?= $dashboardData['metrics']['totalProjets'] > 0 ? ($nombre / $dashboardData['metrics']['totalProjets']) * 100 : 0 ?>%"></div>
                                                        </div>
                                                        <span class="font-semibold"><?= $nombre ?></span>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>

                                    <!-- Services populaires -->
                                    <div class="bg-gray-50 rounded-lg p-6">
                                        <h3 class="text-lg font-semibold mb-4">Services les Plus Demandés</h3>
                                        <div class="space-y-4">
                                            <?php if (empty($dashboardData['servicesPopulaires'])): ?>
                                                <p class="text-gray-500 text-center py-4">Aucune donnée disponible</p>
                                            <?php else: ?>
                                                <?php foreach($dashboardData['servicesPopulaires'] as $index => $service): ?>
                                                    <div class="flex items-center justify-between">
                                                        <div>
                                                            <p class="font-medium"><?= htmlspecialchars($service['nom']) ?></p>
                                                            <p class="text-sm text-gray-600"><?= $service['commandes'] ?> commandes</p>
                                                        </div>
                                                        <div class="text-right">
                                                            <p class="font-semibold"><?= number_format($service['revenus'], 0, ',', ' ') ?> €</p>
                                                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                                                #<?= $index + 1 ?>
                                                            </span>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Évaluations récentes -->
                                <div class="bg-gray-50 rounded-lg p-6">
                                    <h3 class="text-lg font-semibold mb-4">Évaluations Récentes</h3>
                                    <?php if (empty($dashboardData['evaluationsRecentes'])): ?>
                                        <p class="text-gray-500 text-center py-8">Aucune évaluation disponible</p>
                                    <?php else: ?>
                                        <div class="overflow-x-auto">
                                            <table class="min-w-full divide-y divide-gray-200">
                                                <thead class="bg-gray-50">
                                                    <tr>
                                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note</th>
                                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Commentaire</th>
                                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="bg-white divide-y divide-gray-200">
                                                    <?php foreach(array_slice($dashboardData['evaluationsRecentes'], 0, 5) as $evaluation): ?>
                                                        <tr>
                                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                                <?= htmlspecialchars($evaluation['client']) ?>
                                                            </td>
                                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                                <?= htmlspecialchars($evaluation['projet_service']) ?>
                                                            </td>
                                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                                <div class="flex items-center">
                                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                                        <i class="fas fa-star text-xs <?= $i <= $evaluation['note'] ? 'text-yellow-400' : 'text-gray-300' ?>"></i>
                                                                    <?php endfor; ?>
                                                                    <span class="ml-2">(<?= $evaluation['note'] ?>/5)</span>
                                                                </div>
                                                            </td>
                                                            <td class="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                                                                <?= htmlspecialchars($evaluation['commentaire'] ?: 'Aucun commentaire') ?>
                                                            </td>
                                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                                <?= date('d/m/Y', strtotime($evaluation['date_evaluation'])) ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Projets -->
                            <div id="projects" class="tab-content p-6">
                                <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
                                    <div class="bg-yellow-50 rounded-lg p-6 border border-yellow-200">
                                        <h3 class="text-lg font-semibold text-yellow-800">En Attente</h3>
                                        <p class="text-3xl font-bold text-yellow-600 mt-2"><?= $dashboardData['projetsParStatut']['en_attente'] ?></p>
                                        <p class="text-sm text-yellow-700 mt-2">Nécessitent une attention</p>
                                    </div>
                                    
                                    <div class="bg-blue-50 rounded-lg p-6 border border-blue-200">
                                        <h3 class="text-lg font-semibold text-blue-800">En Cours</h3>
                                        <p class="text-3xl font-bold text-blue-600 mt-2"><?= $dashboardData['projetsParStatut']['en_cours'] ?></p>
                                        <p class="text-sm text-blue-700 mt-2">En développement actif</p>
                                    </div>
                                    
                                    <div class="bg-green-50 rounded-lg p-6 border border-green-200">
                                        <h3 class="text-lg font-semibold text-green-800">Terminés</h3>
                                        <p class="text-3xl font-bold text-green-600 mt-2"><?= $dashboardData['projetsParStatut']['termine'] ?></p>
                                        <p class="text-sm text-green-700 mt-2">Prêts à livrer</p>
                                    </div>
                                    
                                    <div class="bg-purple-50 rounded-lg p-6 border border-purple-200">
                                        <h3 class="text-lg font-semibold text-purple-800">Livrés</h3>
                                        <p class="text-3xl font-bold text-purple-600 mt-2"><?= $dashboardData['projetsParStatut']['livre'] ?></p>
                                        <p class="text-sm text-purple-700 mt-2">Complètement terminés</p>
                                    </div>
                                </div>
                                
                                <?php if($dashboardData['insights']['projetsEnRetard'] > 0): ?>
                                    <div class="mt-6 bg-red-50 border border-red-200 rounded-lg p-6">
                                        <h3 class="text-lg font-semibold text-red-800">⚠️ Projets en Retard</h3>
                                        <p class="text-2xl font-bold text-red-600 mt-2"><?= $dashboardData['insights']['projetsEnRetard'] ?></p>
                                        <p class="text-sm text-red-700 mt-2">Projets dépassant leur date de livraison prévue</p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Analyses -->
                            <div id="analytics" class="tab-content p-6">
                                <div class="bg-gray-50 rounded-lg p-6">
                                    <h3 class="text-lg font-semibold mb-4">Évolution Mensuelle</h3>
                                    <?php if (empty($dashboardData['evolutionMensuelle'])): ?>
                                        <p class="text-gray-500 text-center py-8">Aucune donnée d'évolution disponible</p>
                                    <?php else: ?>
                                        <div class="space-y-4">
                                            <?php foreach($dashboardData['evolutionMensuelle'] as $mois): ?>
                                                <div class="flex items-center justify-between p-4 border rounded-lg bg-white">
                                                    <div>
                                                        <p class="font-medium"><?= date('M Y', strtotime($mois['mois'] . '-01')) ?></p>
                                                        <p class="text-sm text-gray-600"><?= $mois['projets'] ?> projets</p>
                                                    </div>
                                                    <div class="text-right">
                                                        <p class="font-semibold"><?= number_format($mois['revenus'], 0, ',', ' ') ?> €</p>
                                                        <div class="w-20 bg-gray-200 rounded-full h-2 mt-1">
                                                            <div class="bg-blue-500 h-2 rounded-full" style="width: <?= min(100, ($mois['revenus'] / 10000) * 100) ?>%"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="mt-6 bg-gray-50 rounded-lg p-6">
                                    <h3 class="text-lg font-semibold mb-4">Insights Business</h3>
                                    <div class="space-y-4">
                                        <div class="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                            <h4 class="font-semibold text-blue-800">Service le Plus Rentable</h4>
                                            <p class="text-sm text-blue-700 mt-1">
                                                "<?= htmlspecialchars($dashboardData['insights']['servicePlusRentable']) ?>" génère le plus de revenus
                                            </p>
                                        </div>

                                        <div class="p-4 border rounded-lg <?= $dashboardData['insights']['evolutionSatisfaction'] >= 0 ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200' ?>">
                                            <h4 class="font-semibold <?= $dashboardData['insights']['evolutionSatisfaction'] >= 0 ? 'text-green-800' : 'text-red-800' ?>">
                                                Évolution Satisfaction
                                            </h4>
                                            <p class="text-sm mt-1 <?= $dashboardData['insights']['evolutionSatisfaction'] >= 0 ? 'text-green-700' : 'text-red-700' ?>">
                                                <?= $dashboardData['insights']['evolutionSatisfaction'] >= 0 ? '+' : '' ?><?= $dashboardData['insights']['evolutionSatisfaction'] ?> points ce mois
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Prédictions -->
                            <div id="predictions" class="tab-content p-6">
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                                    <div class="bg-green-50 rounded-lg p-6 border border-green-200">
                                        <div class="flex items-center justify-between mb-2">
                                            <h3 class="text-sm font-medium text-green-800">Projets Prévus</h3>
                                            <i class="fas fa-chart-line text-green-600"></i>
                                        </div>
                                        <p class="text-2xl font-bold text-green-600"><?= $dashboardData['predictions']['projetsMoisProchain'] ?></p>
                                        <p class="text-xs text-green-700 mt-1">Mois prochain (IA)</p>
                                    </div>

                                    <div class="bg-green-50 rounded-lg p-6 border border-green-200">
                                        <div class="flex items-center justify-between mb-2">
                                            <h3 class="text-sm font-medium text-green-800">Revenus Prévus</h3>
                                            <i class="fas fa-euro-sign text-green-600"></i>
                                        </div>
                                        <p class="text-2xl font-bold text-green-600"><?= number_format($dashboardData['predictions']['revenusPrevus'], 0, ',', ' ') ?> €</p>
                                        <p class="text-xs text-green-700 mt-1">Estimation IA</p>
                                    </div>

                                    <div class="bg-green-50 rounded-lg p-6 border border-green-200">
                                        <div class="flex items-center justify-between mb-2">
                                            <h3 class="text-sm font-medium text-green-800">Satisfaction Prévue</h3>
                                            <i class="fas fa-star text-green-600"></i>
                                        </div>
                                        <p class="text-2xl font-bold text-green-600"><?= $dashboardData['predictions']['tauxSatisfactionPrevu'] ?>/5</p>
                                        <p class="text-xs text-green-700 mt-1">Tendance calculée</p>
                                    </div>

                                    <div class="bg-green-50 rounded-lg p-6 border border-green-200">
                                        <div class="flex items-center justify-between mb-2">
                                            <h3 class="text-sm font-medium text-green-800">Nouveaux Clients</h3>
                                            <i class="fas fa-users text-green-600"></i>
                                        </div>
                                        <p class="text-2xl font-bold text-green-600"><?= $dashboardData['predictions']['clientsPotentiels'] ?></p>
                                        <p class="text-xs text-green-700 mt-1">Prévision IA</p>
                                    </div>
                                </div>

                                <div class="bg-gray-50 rounded-lg p-6">
                                    <h3 class="text-lg font-semibold mb-4">Algorithmes de Prédiction</h3>
                                    <div class="space-y-4">
                                        <div class="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                            <h4 class="font-semibold text-blue-800">Projets & Revenus</h4>
                                            <p class="text-sm text-blue-700 mt-1">Analyse des tendances mensuelles avec moyenne mobile pondérée</p>
                                        </div>
                                        <div class="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                                            <h4 class="font-semibold text-purple-800">Satisfaction Client</h4>
                                            <p class="text-sm text-purple-700 mt-1">Basé sur l'évolution des notes des 30 derniers jours</p>
                                        </div>
                                        <div class="p-4 bg-green-50 border border-green-200 rounded-lg">
                                            <h4 class="font-semibold text-green-800">Acquisition Client</h4>
                                            <p class="text-sm text-green-700 mt-1">Analyse du taux de croissance des inscriptions récentes</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Visualisations -->
                            <div id="visualizations" class="tab-content p-6">
                                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                                    <!-- Graphique en camembert pour les projets -->
                                    <div class="bg-gray-50 rounded-lg p-6">
                                        <h3 class="text-lg font-semibold mb-4 flex items-center">
                                            <i class="fas fa-chart-pie mr-2 text-blue-500"></i>
                                            Répartition des Projets
                                        </h3>
                                        <div style="position: relative; height: 300px;">
                                            <canvas id="projetsDonutChart"></canvas>
                                        </div>
                                    </div>

                                    <!-- Graphique en barres pour les services -->
                                    <div class="bg-gray-50 rounded-lg p-6">
                                        <h3 class="text-lg font-semibold mb-4 flex items-center">
                                            <i class="fas fa-chart-bar mr-2 text-green-500"></i>
                                            Services Populaires
                                        </h3>
                                        <div style="position: relative; height: 300px;">
                                            <canvas id="servicesBarChart"></canvas>
                                        </div>
                                    </div>
                                </div>

                                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                                    <!-- Évolution mensuelle -->
                                    <div class="bg-gray-50 rounded-lg p-6">
                                        <h3 class="text-lg font-semibold mb-4 flex items-center">
                                            <i class="fas fa-chart-line mr-2 text-purple-500"></i>
                                            Évolution Mensuelle
                                        </h3>
                                        <div style="position: relative; height: 300px;">
                                            <canvas id="evolutionChart"></canvas>
                                        </div>
                                    </div>

                                    <!-- Distribution des notes -->
                                    <div class="bg-gray-50 rounded-lg p-6">
                                        <h3 class="text-lg font-semibold mb-4 flex items-center">
                                            <i class="fas fa-star mr-2 text-yellow-500"></i>
                                            Distribution des Notes
                                        </h3>
                                        <div style="position: relative; height: 300px;">
                                            <canvas id="notesChart"></canvas>
                                        </div>
                                    </div>
                                </div>

                                <!-- Graphique de prédictions -->
                                <div class="bg-gray-50 rounded-lg p-6">
                                    <h3 class="text-lg font-semibold mb-4 flex items-center">
                                        <i class="fas fa-brain mr-2 text-indigo-500"></i>
                                        Prédictions vs Réalité
                                    </h3>
                                    <div style="position: relative; height: 400px;">
                                        <canvas id="predictionsRadarChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
        // Gestion des onglets
        function showTab(tabName) {
            // Cacher tous les contenus
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Désactiver tous les boutons
            document.querySelectorAll('.tab-button').forEach(button => {
                button.classList.remove('active', 'border-blue-500', 'text-blue-600');
                button.classList.add('border-transparent', 'text-gray-500');
            });
            
            // Afficher le contenu sélectionné
            document.getElementById(tabName).classList.add('active');
            
            // Activer le bouton sélectionné
            event.target.classList.add('active', 'border-blue-500', 'text-blue-600');
            event.target.classList.remove('border-transparent', 'text-gray-500');
        }

        // Actualisation du dashboard
        function refreshDashboard() {
            const refreshBtn = document.getElementById('refreshBtn');
            const refreshIcon = document.getElementById('refreshIcon');
            
            // Désactiver le bouton et animer l'icône
            refreshBtn.disabled = true;
            refreshIcon.classList.add('animate-spin');
            
            fetch('dashboard.php?ajax=true')
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        location.reload(); // Simple reload pour cet exemple
                    } else {
                        alert('Erreur: ' + data.error);
                    }
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    alert('Erreur lors de l\'actualisation');
                })
                .finally(() => {
                    // Réactiver le bouton
                    refreshBtn.disabled = false;
                    refreshIcon.classList.remove('animate-spin');
                });
        }

        // Auto-refresh toutes les 5 minutes
        setInterval(refreshDashboard, 300000);

// Données pour les graphiques
const chartData = <?= json_encode($dashboardData) ?>;

// Couleurs
const chartColors = {
    primary: '#3b82f6',
    secondary: '#10b981', 
    warning: '#f59e0b',
    danger: '#ef4444',
    purple: '#8b5cf6'
};

// 1. Graphique en camembert pour les projets
function createProjectsChart() {
    const ctx = document.getElementById('projetsDonutChart');
    if (!ctx) return;

    const data = chartData.projetsParStatut;
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['En Attente', 'En Cours', 'Terminé', 'Livré'],
            datasets: [{
                data: [data.en_attente, data.en_cours, data.termine, data.livre],
                backgroundColor: [chartColors.warning, chartColors.primary, chartColors.secondary, chartColors.purple],
                borderWidth: 3,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, usePointStyle: true }
                }
            }
        }
    });
}

// 2. Graphique en barres pour les services
function createServicesChart() {
    const ctx = document.getElementById('servicesBarChart');
    if (!ctx) return;

    const services = chartData.servicesStatistiques || chartData.servicesPopulaires;
    
    if (services.length === 0) {
        // Afficher un message si pas de données
        ctx.getContext('2d').font = '16px Arial';
        ctx.getContext('2d').fillText('Aucune donnée disponible', 50, 150);
        return;
    }

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: services.map(s => s.nom),
            datasets: [{
                label: 'Projets',
                data: services.map(s => s.projets_total || s.commandes || 0),
                backgroundColor: chartColors.secondary,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { 
                legend: { display: false },
                title: {
                    display: true,
                    text: 'Données réelles de votre base'
                }
            },
            scales: { y: { beginAtZero: true } }
        }
    });
}

// 3. Graphique d'évolution (VRAIES DONNÉES)
function createEvolutionChart() {
    const ctx = document.getElementById('evolutionChart');
    if (!ctx) return;

    const evolution = chartData.evolutionMensuelle;
    
    if (evolution.length === 0) {
        ctx.getContext('2d').font = '16px Arial';
        ctx.getContext('2d').fillText('Aucune donnée historique', 50, 150);
        return;
    }

    const labels = evolution.map(e => {
        const date = new Date(e.mois + '-01');
        return date.toLocaleDateString('fr-FR', { month: 'short', year: 'numeric' });
    });

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Projets (réels)',
                data: evolution.map(e => e.projets),
                borderColor: chartColors.primary,
                backgroundColor: chartColors.primary + '20',
                fill: true,
                tension: 0.4
            }, {
                label: 'Revenus k€ (réels)',
                data: evolution.map(e => e.revenus / 1000),
                borderColor: chartColors.secondary,
                backgroundColor: chartColors.secondary + '20',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Évolution réelle sur 12 mois'
                }
            },
            scales: { y: { beginAtZero: true } }
        }
    });
}

// 4. Distribution des notes (VRAIES DONNÉES)
function createNotesChart() {
    const ctx = document.getElementById('notesChart');
    if (!ctx) return;

    const notesData = chartData.distributionNotes;
    const totalEvaluations = notesData.reduce((a, b) => a + b, 0);
    
    if (totalEvaluations === 0) {
        ctx.getContext('2d').font = '16px Arial';
        ctx.getContext('2d').fillText('Aucune évaluation disponible', 50, 150);
        return;
    }

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['1★', '2★', '3★', '4★', '5★'],
            datasets: [{
                label: 'Nombre d\'évaluations',
                data: notesData,
                backgroundColor: [chartColors.danger, '#ff8c00', chartColors.warning, '#32cd32', chartColors.secondary],
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { 
                legend: { display: false },
                title: {
                    display: true,
                    text: `Distribution réelle (${totalEvaluations} évaluations)`
                }
            },
            scales: { y: { beginAtZero: true } }
        }
    });
}

// 5. Graphique radar des prédictions
function createPredictionsChart() {
    const ctx = document.getElementById('predictionsRadarChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Projets', 'Revenus (k€)', 'Satisfaction', 'Clients'],
            datasets: [{
                label: 'Actuel',
                data: [
                    chartData.metrics.totalProjets,
                    chartData.metrics.chiffreAffaires / 1000,
                    chartData.metrics.satisfactionMoyenne,
                    chartData.metrics.totalClients
                ],
                borderColor: chartColors.primary,
                backgroundColor: chartColors.primary + '30',
                pointBackgroundColor: chartColors.primary
            }, {
                label: 'Prévu',
                data: [
                    chartData.predictions.projetsMoisProchain,
                    chartData.predictions.revenusPrevus / 1000,
                    chartData.predictions.tauxSatisfactionPrevu,
                    chartData.predictions.clientsPotentiels
                ],
                borderColor: chartColors.secondary,
                backgroundColor: chartColors.secondary + '30',
                pointBackgroundColor: chartColors.secondary
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: { 
                    beginAtZero: true,
                    grid: { color: '#e5e7eb' },
                    pointLabels: { font: { size: 12 } }
                }
            }
        }
    });
}

// Initialiser les graphiques quand l'onglet Visualisations est affiché
function initializeCharts() {
    setTimeout(() => {
        createProjectsChart();
        createServicesChart();
        createEvolutionChart();
        createNotesChart();
        createPredictionsChart();
    }, 100);
}

// Modifier la fonction showTab existante pour initialiser les graphiques
const originalShowTab = showTab;
showTab = function(tabName) {
    originalShowTab(tabName);
    if (tabName === 'visualizations') {
        initializeCharts();
    }
};
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
function getStatusColor($statut) {
    switch($statut) {
        case 'en_attente': return 'text-yellow-500';
        case 'en_cours': return 'text-blue-500';
        case 'termine': return 'text-green-500';
        case 'livre': return 'text-purple-500';
        default: return 'text-gray-500';
    }
}

function getStatusBgColor($statut) {
    switch($statut) {
        case 'en_attente': return 'bg-yellow-500';
        case 'en_cours': return 'bg-blue-500';
        case 'termine': return 'bg-green-500';
        case 'livre': return 'bg-purple-500';
        default: return 'bg-gray-500';
    }
}
?>