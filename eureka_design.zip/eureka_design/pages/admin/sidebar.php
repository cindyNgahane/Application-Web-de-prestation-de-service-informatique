<?php
// Vérification de l'authentification (sécurité)
if (!isset($_SESSION['user_id'])) {
    header('Location: admin/login.php');
    exit();
}
?>

<!-- Sidebar -->
<nav class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse" style="min-height: 100vh;">
    <div class="position-sticky pt-3">
        <!-- Logo et titre -->
        <div class="text-center mb-4">
            <a href="dashboard.php" class="d-flex align-items-center justify-content-center text-white text-decoration-none">
                <span class="fs-4">Eureka Design</span>
            </a>
            <hr class="text-secondary">
        </div>

        <!-- Menu de navigation -->
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?> text-white" href="dashboard.php">
                    <i class="bi bi-speedometer2 me-2"></i>Tableau de bord
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'projet.php' ? 'active' : '' ?> text-white" href="projet.php">
                    <i class="bi bi-folder me-2"></i>Projets
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'clients.php' ? 'active' : '' ?> text-white" href="clients.php">
                    <i class="bi bi-people me-2"></i>Clients
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'admin_services.php' ? 'active' : '' ?> text-white" href="admin_services.php">
                    <i class="bi bi-collection me-2"></i>Services
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'messadmin.php' ? 'active' : '' ?> text-white" href="messadmin.php">
                    <i class="bi bi-chat-dots me-2"></i>Messages
                    <span class="badge bg-danger ms-2">3</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'admin_evaluations.php' ? 'active' : '' ?> text-white" href="admin_evaluations.php">
                    <i class="bi bi-star me-2"></i>Évaluations
                </a>
            </li>
        </ul>

        <!-- Section administration -->
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Administration</span>
        </h6>
        <ul class="nav flex-column mb-2">
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'admin_utilisateurs.php' ? 'active' : '' ?> text-white" href="admin_utilisateurs.php">
                    <i class="bi bi-person-gear me-2"></i>Utilisateurs
                </a>
            </li>
        </ul>

        <!-- Déconnexion -->
        <div class="border-top mt-auto p-3">
            <a href="logout.php" class="btn btn-outline-light w-100">
                <i class="bi bi-box-arrow-right me-2"></i>Déconnexion
            </a>
        </div>
    </div>
</nav>