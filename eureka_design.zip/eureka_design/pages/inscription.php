
<?php
// Inclure la connexion
require_once "admin/databases.php";

// Vérifier si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = htmlspecialchars($_POST["nom"]);
    $email = htmlspecialchars($_POST["email"]);
    $numero = $_POST["numero"];
    $mot_de_passe = password_hash($_POST["mot_de_passe"], PASSWORD_DEFAULT); // Sécurisation du mot de passe
    

    // Préparer et exécuter la requête
    $sql = "INSERT INTO utilisateur (nom, email,numero , mot_de_passe) VALUES (?, ?,?, ?)";
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([$nom, $email,$numero, $mot_de_passe]);
        
        $message[]="Inscription reussie";
    } catch (PDOException $e) {
        echo "Erreur lors de l'inscription : " . $e->getMessage();
    }
}

//ot_de_passex=password_hash("ngahane123",PASSWORD_DEFAULT);
    //ho $mot_de_passex;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription | EUREKA DESIGN & KONSULTING</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/inscriptions.css">
</head>
<body>
    <?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
        ';
    }
}
?>
    <div class="auth-container">
        <div class="auth-left">
            <div class="auth-content">
                <a href="index.html" class="logo">
                    <img src="images/logo.jpg" alt="EUREKA Logo">
                    <span>EUREKA</span>
                </a>
                <h1>Bienvenue chez EUREKA</h1>
                <p>Créez votre compte pour accéder à nos services.</p>
                <div class="auth-features">
                    <div class="feature-item">
                        <i class="fas fa-project-diagram"></i>
                        <span>Suivi de projets en temps réel</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-comments"></i>
                        <span>Messagerie intégrée</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-chart-line"></i>
                        <span>Analyses personnalisées</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="auth-right">
            <div class="auth-form-container">
                <h2>Inscription</h2>
                <p>Remplissez le formulaire pour créer un compte</p>
                
                <form class="auth-form" id="signupForm" method="POST">
                    <div class="form-group">
                        <label for="signupName">Nom</label>
                        <input type="text" name="nom" id="signupName" placeholder="Votre nom" required>
                    </div>
                    <div class="form-group">
                        <label for="signupEmail">Email</label>
                        <input type="email" name="email" id="signupEmail" placeholder="votre@email.com" required>
                    </div>
                    <div class="form-group">
                        <label for="signupName">Telephone</label>
                        <input type="number" name="numero" id="telephone" placeholder="Votre numero de telephone" required>
                    </div>
                    <div class="form-group">
                        <label for="signupPassword">Mot de passe</label>
                        <div class="password-input">
                            <input type="password"name="mot_de_passe" id="signupPassword" placeholder="Votre mot de passe" required>
                            <button type="button" class="toggle-password">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">S'inscrire</button>
                     <a href="login.php"> se conneter</a>
                    <div class="auth-divider">
                        <span>ou</span>
                    </div>
                    
                    <div class="social-login">
                        <button type="button" class="btn btn-google">
                            <img src="images/google-icon.png" alt="Google">
                            Continuer avec Google
                        </button>
                        <button type="button" class="btn btn-facebook">
                            <i class="fab fa-facebook-f"></i>
                            Continuer avec Facebook
                        </button>
                    </div>
                    
                    <div class="auth-switch">
                        <p>Vous avez déjà un compte ? <a href="login.php">Se connecter</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="js/main.js"></script>
</body>
</html>