<?php
session_start();
require_once 'admin/databases.php';

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'client') {
    header('Location: ../login.php');
    exit();
}

$clientId = $_SESSION['user_id'];
$errors = [];
$success = false;

// Récupération des infos du client
$stmt = $pdo->prepare("SELECT * FROM utilisateur WHERE id_utilisateur = ?");
$stmt->execute([$clientId]);
$client = $stmt->fetch(PDO::FETCH_ASSOC);

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validation et traitement des données
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $ancien_mdp = $_POST['ancien_mdp'] ?? '';
    $nouveau_mdp = $_POST['nouveau_mdp'] ?? '';
    $confirmation_mdp = $_POST['confirmation_mdp'] ?? '';

    // Validation des champs obligatoires
    if (empty($nom) || empty($prenom) || empty($email)) {
        $errors[] = "Les champs nom, prénom et email sont obligatoires.";
    }

    // Validation de l'email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "L'adresse email n'est pas valide.";
    }

    // Vérification si l'email existe déjà
    $stmtEmail = $pdo->prepare("SELECT id_utilisateur FROM utilisateur WHERE email = ? AND id_utilisateur != ?");
    $stmtEmail->execute([$email, $clientId]);
    if ($stmtEmail->fetch()) {
        $errors[] = "Cette adresse email est déjà utilisée par un autre compte.";
    }

    // Traitement du mot de passe si fourni
    $updatePassword = false;
    if (!empty($nouveau_mdp)) {
        if (!password_verify($ancien_mdp, $client['mot_de_passe'])) {
            $errors[] = "L'ancien mot de passe est incorrect.";
        } elseif ($nouveau_mdp !== $confirmation_mdp) {
            $errors[] = "Les nouveaux mots de passe ne correspondent pas.";
        } elseif (strlen($nouveau_mdp) < 8) {
            $errors[] = "Le mot de passe doit contenir au moins 8 caractères.";
        } else {
            $updatePassword = true;
        }
    }

    // Traitement de l'image de profil
    $photo_profil = $client['photo_profil'];
    if (isset($_FILES['photo_profil']) && $_FILES['photo_profil']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/profiles/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $fileExt = pathinfo($_FILES['photo_profil']['name'], PATHINFO_EXTENSION);
        $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array(strtolower($fileExt), $allowedExt)) {
            $newFilename = uniqid('profile_') . '.' . $fileExt;
            $uploadPath = $uploadDir . $newFilename;

            if (move_uploaded_file($_FILES['photo_profil']['tmp_name'], $uploadPath)) {
                // Supprimer l'ancienne photo si ce n'est pas la photo par défaut
                if ($photo_profil !== 'default.jpg' && file_exists($uploadDir . $photo_profil)) {
                    unlink($uploadDir . $photo_profil);
                }
                $photo_profil = $newFilename;
            } else {
                $errors[] = "Erreur lors du téléchargement de la photo.";
            }
        } else {
            $errors[] = "Format de fichier non supporté. Utilisez JPG, PNG ou GIF.";
        }
    }

    // Mise à jour si aucune erreur
    if (empty($errors)) {
        try {
            if ($updatePassword) {
                $stmtUpdate = $pdo->prepare("UPDATE utilisateur 
                                           SET nom = ?, prenom = ?, email = ?, telephone = ?, 
                                               mot_de_passe = ?, photo_profil = ?
                                           WHERE id_utilisateur = ?");
                $hashedPassword = password_hash($nouveau_mdp, PASSWORD_DEFAULT);
                $stmtUpdate->execute([$nom, $prenom, $email, $telephone, $hashedPassword, $photo_profil, $clientId]);
            } else {
                $stmtUpdate = $pdo->prepare("UPDATE utilisateur 
                                           SET nom = ?, prenom = ?, email = ?, telephone = ?, 
                                               photo_profil = ?
                                           WHERE id_utilisateur = ?");
                $stmtUpdate->execute([$nom, $prenom, $email, $telephone, $photo_profil, $clientId]);
            }

            $success = true;
            // Mettre à jour les données de session
            $_SESSION['user_name'] = $prenom . ' ' . $nom;
            // Recharger les données du client
            $stmt->execute([$clientId]);
            $client = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la mise à jour: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Compte - Eureka Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .profile-pic {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            border: 5px solid #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .profile-pic-small {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <?php include 'header-client.php'; ?>

    <div class="container py-5">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body text-center">
                        <img src="../uploads/profiles/<?= htmlspecialchars($client['photo_profil']) ?>" 
                             class="profile-pic mb-3" 
                             alt="Photo de profil">
                        <h5><?= htmlspecialchars($client['prenom'] . ' ' . $client['nom']) ?></h5>
                        <p class="text-muted"><?= htmlspecialchars($client['email']) ?></p>
                        <hr>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active" href="mon-compte.php">
                                    <i class="bi bi-person"></i> Mon compte
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="projets.php">
                                    <i class="bi bi-folder"></i> Mes projets
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="messages.php">
                                    <i class="bi bi-envelope"></i> Messages
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h4>Mon compte</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                Votre compte a été mis à jour avec succès.
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?= htmlspecialchars($error) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form method="POST" enctype="multipart/form-data">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="prenom" class="form-label">Prénom</label>
                                        <input type="text" class="form-control" id="prenom" name="prenom" 
                                               value="<?= htmlspecialchars($client['prenom'] ?? '') ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="nom" class="form-label">Nom</label>
                                        <input type="text" class="form-control" id="nom" name="nom" 
                                               value="<?= htmlspecialchars($client['nom'] ?? '') ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" name="email" 
                                               value="<?= htmlspecialchars($client['email'] ?? '') ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="telephone" class="form-label">Téléphone</label>
                                        <input type="tel" class="form-control" id="telephone" name="telephone" 
                                               value="<?= htmlspecialchars($client['telephone'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="photo_profil" class="form-label">Photo de profil</label>
                                <input type="file" class="form-control" id="photo_profil" name="photo_profil" accept="image/*">
                                <small class="text-muted">Formats acceptés: JPG, PNG, GIF (max 2MB)</small>
                            </div>

                            <hr class="my-4">

                            <h5 class="mb-3">Changer le mot de passe</h5>
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="ancien_mdp" class="form-label">Ancien mot de passe</label>
                                        <input type="password" class="form-control" id="ancien_mdp" name="ancien_mdp">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="nouveau_mdp" class="form-label">Nouveau mot de passe</label>
                                        <input type="password" class="form-control" id="nouveau_mdp" name="nouveau_mdp">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="confirmation_mdp" class="form-label">Confirmation</label>
                                        <input type="password" class="form-control" id="confirmation_mdp" name="confirmation_mdp">
                                    </div>
                                </div>
                            </div>
                            <small class="text-muted">Laissez vide pour ne pas changer</small>

                            <div class="d-flex justify-content-end mt-4">
                                <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'footer-client.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Aperçu de l'image avant upload
        document.getElementById('photo_profil').addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.querySelector('.profile-pic').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>