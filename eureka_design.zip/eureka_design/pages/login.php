
<?php
session_start();
require_once "admin/databases.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $mot_de_passe = $_POST["mot_de_passe"];

    // Rechercher l'utilisateur uniquement par email
    $sql = "SELECT * FROM utilisateur WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $utilisateur = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($utilisateur && password_verify($mot_de_passe, $utilisateur["mot_de_passe"])) {
        // Connexion réussie
        $_SESSION["user_id"] = $utilisateur["id_utilisateur"];
        $_SESSION["nom"] = $utilisateur["nom"];
        $_SESSION["user_type"] = $utilisateur["type"];

        // Redirection automatique selon le rôle
        if ($utilisateur["type"]=="gestionnaire"){
            header("Location: admin/projet.php");
        } else {
            header("Location: projets.php");
        }
        exit;
    } else {
        echo "Email ou mot de passe incorrect.";
    }
}

    
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion | EUREKA DESIGN & KONSULTING</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-left">
            <div class="auth-content">
                <a href="index.html" class="logo">
                    <img src="images/logo.jpg" alt="EUREKA Logo">
                    <span>EUREKA</span>
                </a>
                <h1>Bienvenue à nouveau</h1>
                <p>Connectez-vous pour accéder à votre espace client et gérer vos projets.</p>
                <div class="auth-features">
                    <div class="feature-item">
                        <i class="fas fa-project-diagram"></i>
                        <span>Suivi de projets en temps réel</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-comments"></i>
                        <span>Messagerie intégrée</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-chart-line"></i>
                        <span>Analyses personnalisées</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="auth-right">
            <div class="auth-form-container">
                <h2>Connexion</h2>
                <p>Entrez vos identifiants pour accéder à votre compte</p>
                
                <form class="auth-form" id="loginForm"method="POST">
                    <div class="form-group">
                        <label for="loginEmail">Email</label>
                        <input type="email" id="loginEmail" placeholder="votre@email.com" required name="email">
                    </div>
                    <div class="form-group">
                        <label for="loginPassword">Mot de passe</label>
                        <div class="password-input">
                            <input type="password" id="loginPassword" placeholder="Votre mot de passe" required name="mot_de_passe">
                            <button type="button" class="toggle-password">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-options">
                            <div class="remember-me">
                                <input type="checkbox" id="rememberMe">
                                <label for="rememberMe">Se souvenir de moi</label>
                            </div>
                            <a href="forgot-password.html" class="forgot-password">Mot de passe oublié ?</a>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Se connecter</button>
                    
                    <div class="auth-divider">
                        <span>ou</span>
                    </div>
                    
                    <div class="social-login">
                        <button type="button" class="btn btn-google">
                            <img src="images/google-icon.png" alt="Google">
                            Continuer avec Google
                        </button>
                        <button type="button" class="btn btn-facebook">
                            <i class="fab fa-facebook-f"></i>
                            Continuer avec Facebook
                        </button>
                    </div>
                    
                    <div class="auth-switch">
                        <p>Vous n'avez pas de compte ? <a href="inscription.php">S'inscrire</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="js/auth.js"></script>
</body>
</html>